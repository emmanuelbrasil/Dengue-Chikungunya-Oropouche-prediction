suppressMessages(library(doParallel))
suppressMessages(library(parallel))
suppressMessages(library(labelled))
suppressMessages(library(tidyverse))
# suppressMessages(library(plotly))
# suppressMessages(library(scatterplot3d))
suppressMessages(library(randomForest))
# suppressMessages(library(cluster))
suppressMessages(library(rfUtilities))
suppressMessages(library(Boruta))
suppressMessages(library(ranger))
suppressMessages(library(rFerns))
suppressMessages(library(pdp))
suppressMessages(library(rms))
suppressMessages(library(DiagnosisMed))
suppressMessages(library(UncertainInterval))
suppressMessages(library(flextable))
suppressMessages(library(patchwork))

env_temp <- new.env()
load(paste0(data_path, "Imputed_data_", Sys.Date(), ".RData"), envir = env_temp)
# load(paste0("~/Projetos/Oropouche/dados/Imputed_data_2026-02-24.RData"), envir = env_temp)
bi <- env_temp$bi
data_path <- env_temp$data_path
result_path <- env_temp$result_path
script_path  <- env_temp$script_path
rm(env_temp)

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# rstudioapi::restartSession()

# Declaring predictors ----
predictors <- c(
  "SEMANA_NUM",
  "IDADE_ANOS_DT_NOTIFIC",
  "SEXO",
  "GESTANTE", #
  "RACA_COR",
  # "PCD", # this predictor has almost no variance
  # "MORADOR_RUA", # this predictor has almost no variance
  "ESCOLARIDADE",
  "ZONA",
  "DC_FEBRE",
  "DC_CEFALEIA",
  "DC_VOMITO",
  "DC_DOR_COSTAS",
  "DC_ARTRITE",
  "DC_PETEQUIAS",
  "DC_PROVA_LACO",
  "DC_MIALGIA",
  "DC_EXANTEMA",
  "DC_NAUSEAS",
  "DC_CONJUTIVITE",
  "DC_ARTRALGIA_INTENSA",
  "DC_LEUCOPENIA",
  "DC_DOR_RETROORBITAL",
  "DC_DIABETES",
  "DC_HEPATOPATIAS",
  "DC_HIPER_ARTERIAL",
  "DC_AUTO_IMUNES",
  "DC_HEMATOLOGICAS",
  "DC_RENAL_CRONICA",
  "DC_ACIDO_PEPTICA"
)
# length(predictors)

# bi <- bi %>% select(all_of(predictors))
# save(bi , file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))
# load(file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))

# Preparing for balance the forests ----

# Dengue ----

# table(bi %>%
#        filter(VALIDATION_3 == "Development") %>%
#        pull(CHIKUNGUNYA_01))

x_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  select(all_of(predictors))
y_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  pull(CHIKUNGUNYA)
#
x_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  select(all_of(predictors))
y_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  pull(CHIKUNGUNYA)
y_test_01 <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  pull(CHIKUNGUNYA_01)

size_ranger <- c("No" = (8128 / sum(y_train == "No")),"Yes" = (8128 / sum(y_train == "Yes")))
size_tune <- c("No" = 8128, "Yes" = 8128)
dens <- density(y_test_01)
weights <- 1 / approx(dens$x, dens$y, xout = y_test_01)$y
table(weights)
rm(bi)
gc()

# Tuning mtry ----
set.seed(1753109393)
Sys.time(); time_ini <- Sys.time()
rf.den.tuned <-
  tuneRF(x = x_train,
         y = y_train,
         # xtest = x_test,
         # ytest = y_test,
         proximity = FALSE,
         improve = 0.001,
         ntreeTry = 350,
         mtryStart = 15,
         stepFactor = 1.5,
         doBest = TRUE,
         plot = TRUE,
         corr.bias = TRUE,
         final.model = FALSE,
         parsimony = TRUE,
         keep.inbag = FALSE,
         localImp = FALSE,
         sampsize = size_tune,
         replace = TRUE,
         strata = y_train,
         seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
# x <- plot(rf.den.tuned)
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# the black is the overall error
# plot(rf.den.tuned)
# rf.den.tuned
# rf.den.tuned$mtry

# Selecting predictors ----
set.seed(1753109393)
Sys.time()
rf.class.chik <- Boruta(
  x = x_train,
  y = y_train,
  doTrace = 2,
  getImp = getImpRfZ,
  sample.fraction = size_ranger,
  num.trees = 350,
  num.threads = 4,
  maxRuns = 15,
  holdHistory = TRUE,
  keep.inbag = FALSE,
  mtry = rf.den.tuned$mtry,
  seed = 1753109393
)
Sys.time() ; rf.class.chik$timeTaken
# print(rf.class.chik)
rf.class.chik <- TentativeRoughFix(rf.class.chik)
predictors_selected <- getSelectedAttributes(rf.class.chik)

# Importance Permutations (shadow fatures) ----
tiff(paste0(result_path,"Importance_normzlized_Dengue_RF_class_",Sys.Date(),".tiff"),
     width = 480 * 12,
     height = 480 * 12,
     res = 72 * 12, compression = "lzw")
w <- rf.class.chik
colnames(w$ImpHistory) <- c(unname(unlist(var_label(x_train))),c("Max shadow feature", "Mean shadow feature", "Min shadow feature"))
opar <- par()
par(mar = c(5.1, 8.1, 4.1, 2.1))
plot(w,
     las = 2,
     cex.axis = 0.7,
     xlab = "Variable normalized permutation importance (shadow features iterations)",
     ylab = "",
     cex.lab = .9,
     horizontal = TRUE)
grid()
legend("bottomright",
       legend = c("Selected","Shadow features","Removed"),
       fill = c("green", "blue","red"),
       bty = "n",
       cex = .9)
suppressWarnings(par(opar)) ; rm(opar, w)
dev.off()

png(paste0(result_path,"Importance_normzlized_Dengue_RF_class_",Sys.Date(),".png"),
    width = 480 * 12,
    height = 480 * 12,
    res = 72 * 12)
w <- rf.class.chik
colnames(w$ImpHistory) <- c(unname(unlist(var_label(x_train))),c("Max shadow feature", "Mean shadow feature", "Min shadow feature"))
opar <- par()
par(mar = c(5.1, 8.1, 4.1, 2.1))
plot(w,
     las = 2,
     cex.axis = 0.7,
     xlab = "Variable normalized permutation importance (shadow features iterations)",
     ylab = "",
     cex.lab = .9,
     horizontal = TRUE)
grid()
legend("bottomright",
       legend = c("Selected","Shadow features","Removed"),
       fill = c("green", "blue","red"),
       bty = "n",
       cex = .9)
suppressWarnings(par(opar)) ; rm(opar, w)
dev.off()


# RF class model ----
Sys.time()
time_ini <- Sys.time()
dengue.class.model <- ranger(
  x = x_train[, predictors_selected],
  y = y_train,
  num.trees = 500,
  mtry = rf.den.tuned$mtry,
  importance = 'permutation',
  probability = TRUE,
  num.threads = 4,
  write.forest  = TRUE,
  sample.fraction = size_ranger,
  replace = TRUE,
  keep.inbag = FALSE,
  seed = 1753109393,
  oob.error = TRUE,
  save.memory = FALSE,
  verbose = TRUE
) ; time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

## Saving class models ----
save(dengue.class.model,
     file = paste0(data_path,"Dengue_rf_class_models_",Sys.Date(),".RData"))


# Decision limits ----

## Train dataset ----
# p <- predict(dengue.class.model,
#              data = x_test,
#              type = "response",
#              num.threads = 0)$predictions[,"Yes"]

p <-
  pmin(
    pmax(
      predict(dengue.class.model,
              data = x_train,
              type = "response",
              num.threads = 0)$predictions[,"Yes"],
      0.0000001),
    0.9999999)
storage.mode(p)  <- "double"
r <- if_else(y_train == "Yes", 1, 0)
storage.mode(r)  <- "double"

### Mixed densities ----
png(paste0(result_path,"Mixed_densities_Dengue_rf_class_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 4)
plotMD(ref = r, test = round(p,3), position.legend = "top", breaks = 40)
axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.3)
dev.off()

### TGROC ----
dengue.class.train.tgroc85 <- SS(ref = r, test = round(p,3))
z <- inc.limits(dengue.class.train.tgroc85)

dengue.class.train.tgroc85 <- SS(ref = r, test = round(p,3))
z <- inc.limits(dengue.class.train.tgroc85)

# dengue.class.train.tgroc85 <-
#   TGROC(
#     ref = r,
#     test = p,
#     t.max = 01,
#     t.min = 0,
#     precision = 0.01,
#     Prevalence = .03,
#     Inconclusive = 0.85)
# dengue.class.train.tgroc85

# plot(dengue.class.test.tgroc95,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE)

png(paste0(result_path,"TGROC_Dengue_rf_class_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)
# plot(dengue.class.train.tgroc85,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE,
#      xlab = "Model predicitons")
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)

print(
  dengue.class.train.tgroc85.plot <-
    ggplot(dengue.class.train.tgroc85$table,
           aes(x = test.values)) +
    annotate("rect", xmin = z$test.values[2], xmax = z$test.values[1], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric inconclusive limits at 0.85 :",
                      sprintf("%.3f", z$test.values[2]),
                      sprintf("%.3f", z$test.values[1]))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5))
)

dev.off()

### Uncertain-Interval ----

### TGROC plot ----
# dengue.class.train.tgroc.UI <- dengue.class.train.tgroc85
y <- ui.nonpar(ref = r, test = round(p,3),
               intersection = .5,
               direction = "<")
# dengue.class.train.tgroc.UI <- update.inconclusive.tgroc(dengue.class.train.tgroc85, y)


# tiff(paste0(result_path,"TGROC_UI_Dengue_rf_class_train_",Sys.Date(),".tiff"), width = 480*4, height = 480*4, res = 72 * 5, compression = "lzw")
#
# plot(dengue.class.train.tgroc.UI,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE,
#      xlab = "Model predicitons",
#      title.arg = list(cex.sub = 0.65, line = 4.5, col.sub = "transparent"))
# title(sub = paste0("Non-parametric uncertain interval limits at 0.55 accuracy: ",
#                    round(dengue.class.train.tgroc.UI$np.inconclusive[1,1],3),"-",
#                    round(dengue.class.train.tgroc.UI$np.inconclusive[2,1],3)),
#       cex.sub = 0.65,
#       line = 4)
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# dev.off()

png(paste0(result_path,"TGROC_UI_Dengue_rf_class_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

# plot(dengue.class.train.tgroc.UI,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE,
#      xlab = "Model predicitons",
#      title.arg = list(cex.sub = 0.65, line = 4.5, col.sub = "transparent"))
# title(sub = paste0("Non-parametric uncertain interval limits at 0.55 accuracy: ",
#                    round(dengue.class.train.tgroc.UI$np.inconclusive[1,1],3),"-",
#                    round(dengue.class.train.tgroc.UI$np.inconclusive[2,1],3)),
#       cex.sub = 0.65,
#       line = 4)
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)

print(
  dengue.class.train.tgrocUI.plot <-
    ggplot(dengue.class.train.tgroc85$table,
           aes(x = test.values)) +
    annotate("rect", xmin = y[1], xmax = y[2], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric uncertain interaval limits at 0.55 accuracy:",
                      sprintf("%.3f", y[1]),
                      sprintf("%.3f", y[2]))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5))
)

dev.off()

## Test dataset ----
# p <- predict(dengue.class.model,
#              data = x_test,
#              type = "response",
#              num.threads = 0)$predictions[,"Yes"]

p <-
  pmin(
    pmax(
      predict(dengue.class.model,
              data = x_test,
              type = "response",
              num.threads = 0)$predictions[,"Yes"],
      0.0000001),
    0.9999999)
storage.mode(p)  <- "double"
r <- if_else(y_test == "Yes", 1, 0)
storage.mode(r)  <- "double"
# head(r)
# head(p)

#### Mixed densities ----
png(paste0(result_path,"Mixed_densities_Dengue_rf_class_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 4)
plotMD(ref = r, test = round(p,3), position.legend = "topright", breaks = 40)
axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.3)
dev.off()

### TGROC ----
# dengue.class.test.tgroc85 <-
#   TGROC(
#     ref = r,
#     test = p,
#     t.max = 01,
#     t.min = 0,
#     precision = 0.01,
#     Prevalence = .03,
#     Inconclusive = 0.85,
#     reverse = FALSE)
# dengue.class.test.tgroc85

# plot(dengue.class.test.tgroc95,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE)

png(paste0(result_path,"TGROC_Dengue_rf_class_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)
# plot(dengue.class.test.tgroc85,
#      Plot = c("Non-parametric"),
#      Plot.CL = F,
#      xlab = "Model predicitons")
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)

print(
  dengue.class.test.tgroc85.plot <-
    ggplot(dengue.class.test.tgroc85$table,
           aes(x = test.values)) +
    annotate("rect", xmin = z$test.values[2], xmax = z$test.values[1], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric inconclusive limits at 0.85 :",
                      sprintf("%.3f", z$test.values[2]),
                      sprintf("%.3f", z$test.values[1]))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5))
)

dev.off()

### Uncertain-Interval ----
#### TGROC plot ----
# dengue.class.test.tgroc.UI <- dengue.class.test.tgroc85
y <- ui.nonpar(ref = r, test = round(p,3),
               intersection = .5,
               direction = "<")
# dengue.class.test.tgroc.UI <- update.inconclusive.tgroc(dengue.class.test.tgroc85, y)

# tiff(paste0(result_path,"TGROC_UI_Dengue_rf_class_test_",Sys.Date(),".tiff"), width = 480*4, height = 480*4, res = 72 * 5, compression = "lzw")
#
# plot(dengue.class.test.tgroc.UI,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE,
#      xlab = "Model predicitons",
#      title.arg = list(cex.sub = 0.65, line = 4.5, col.sub = "transparent"))
# title(sub = paste0("Non-parametric uncertain interval limits at 0.55 accuracy: ",
#                    round(dengue.class.test.tgroc.UI$np.inconclusive[1,1],3),"-",
#                    round(dengue.class.test.tgroc.UI$np.inconclusive[2,1],3)),
#       cex.sub = 0.65,
#       line = 4)
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# dev.off()

png(paste0(result_path,"TGROC_UI_Dengue_rf_class_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

# plot(dengue.class.test.tgroc.UI,
#      Plot = c("Non-parametric"),
#      Plot.CL = FALSE,
#      xlab = "Model predicitons",
#      title.arg = list(cex.sub = 0.65, line = 4.5, col.sub = "transparent"))
# title(sub = paste0("Non-parametric uncertain interval limits at 0.55 accuracy: ",
#                    round(dengue.class.test.tgroc.UI$np.inconclusive[1,1],3),"-",
#                    round(dengue.class.test.tgroc.UI$np.inconclusive[2,1],3)),
#       cex.sub = 0.65,
#       line = 4)
# axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
# axis(2, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)

print(
  dengue.class.test.tgrocUI.plot <-
    ggplot(dengue.class.test.tgroc85$table,
           aes(x = test.values)) +
    annotate("rect", xmin = y[1], xmax = y[2], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric uncertain interaval limits at 0.55 accuracy:",
                      sprintf("%.3f", y[1]),
                      sprintf("%.3f", y[2]))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5))

)

dev.off()

# Perfomance comparison  ----
## Train dataset ----
# table(y_train, useNA = "ifany")
train_class <- if_else(predict(dengue.class.model,
                               data = x_train,
                               type = "response",
                               num.threads = 0)$predictions[,"Yes"] >= 0.5,
                       "Yes","No", ptype = factor(levels = c("No","Yes")))
tab_train <- table(train_class, y_train)
storage.mode(tab_train) <- "double"

diag.rf.class.den.train <-
  diagnosis(tab = tab_train)$results %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3, na_str = "Na", nan_str = "Na") %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0, na_str = "---") %>%
  colformat_double(i = ~ Statistics == "Area under ROC curve:", digits = 3, na_str = "---") %>%
  autofit() %>%
  set_caption("Class random forest Dengue fever selected performance measures from the training dataset.") %>%
  add_footer_lines("cl = confidence limit; Na = not assigned; Inf = Infinite.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# diag.rf.class.den.train

## Test dataset ----
test_class <- if_else(predict(dengue.class.model,
                              data = x_test,
                              type = "response",
                              num.threads = 0)$predictions[,"Yes"] >= 0.5,
                      "Yes","No", ptype = factor(levels = c("No","Yes")))
tab_test <- table(test_class, y_test)
storage.mode(tab_test) <- "double"

diag.rf.class.den.test <-
  diagnosis(tab = tab_test)$results %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3, na_str = "Na", nan_str = "Na") %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0, na_str = "---") %>%
  colformat_double(i = ~ Statistics == "Area under ROC curve:", digits = 3, na_str = "---") %>%
  autofit() %>%
  set_caption("Class random forest Dengue fever selected performance measures from the test dataset.") %>%
  add_footer_lines("cl = confidence limit; Na = not assigned; Inf = Infinite.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# diag.rf.class.den.test

## Combined datasets ----
diag.rf.class.chik <-
  left_join(
    diagnosis(tab = tab_train)$results %>%
      rownames_to_column(var = "Statistics"),
    diagnosis(tab = tab_test)$results %>%
      rownames_to_column(var = "Statistics"),
    by = "Statistics", suffix = c("_train", "_test")
  ) %>%
  flextable() %>%
  set_header_labels(
    Estimate_train = "Estimate", lower.cl_train = "95% lower cl", upper.cl_train = "95% upper cl",
    Estimate_test = "Estimate", lower.cl_test = "95% lower cl", upper.cl_train = "95% upper cl"
  ) %>%
  add_header_row(
    values = c("", "Training dataset", "Test/Validation dataset"),
    colwidths = c(1, 3, 3)
  ) %>%
  align(i = 1, align = "center", part = "header") %>%
  colformat_double(digits = 3, na_str = "Na", nan_str = "Na") %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0, na_str = "---") %>%
  colformat_double(i = ~ Statistics == "Area under ROC curve:", digits = 3, na_str = "---") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  autofit() %>%
  set_caption("Classification random forest performance measures for Dengue fever prediction: Training vs. Validation.") %>%
  add_footer_lines("lower cl = lower confidence limit; upper cl = upper confidence limit; Na = not assigned.") %>%
  border_remove() %>%
  hline_top(part = "header", border = officer::fp_border(width = 2)) %>%
  hline_bottom(part = "body", border = officer::fp_border(width = 2)) %>%
  vline(j = 4, border = officer::fp_border(color = "gray90", width = 1), part = "all") %>%
  align(j = 2:7, align = "center", part = "all") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# diag.rf.class.chik

suppressWarnings(rm(test_class, train_class))

save_as_docx(
  values = list(diag.rf.class.den.test,
                diag.rf.class.den.train,
                diag.rf.class.chik) ,
  path = paste0(result_path,"Table_SeSp_class_Dengue_",Sys.Date(),".docx"),
)


## AUC R2 and mean error ----
#### Train set ----

performance.rf.class.chik <-
  val.prob(y = if_else(y_train == "Yes",1,0),
           p = pmin(pmax(predict(dengue.class.model,
                                 data = x_train,
                                 type = "response",
                                 num.threads = 0)$predictions[,"Yes"],
                         0.0000001),
                    0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]

#### Test set (and combined) ----
performance.rf.class.chik <-
  t(bind_rows(performance.rf.class.chik,
              val.prob(y = if_else(y_test == "Yes",1,0),
                       p = pmin(pmax(predict(dengue.class.model,
                                             data = x_test,
                                             type = "response",
                                             num.threads = 0)$predictions[,"Yes"],
                                     0.0000001),
                                0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]))
colnames(performance.rf.class.chik) <- c("Train/Development","Test/Validation")

performance.rf.class.chik <-
  performance.rf.class.chik %>%
  as.data.frame() %>%
  rownames_to_column("Statistics") %>%
  as_tibble() %>%
  flextable() %>%
  autofit() %>%
  set_caption("Classification random forest selected performance measures estimated from the predicted probabilities on different datasets.") %>%
  add_footer_lines("C (ROC) = c statistic or area under the ROC curve; Eavg = average error; Train = dataset split used in development; Test = dataset split used in exterval validation; E90 = percentile 90 of prediction error; Emax = maximum prediction error") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  align(j = 2:3, align = "center", part = "all") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# performance.rf.class.chik

save_as_docx(
  values = list(performance.rf.class.chik) ,
  path = paste0(result_path,"Performance_class_Dengue_",Sys.Date(),".docx"),
)


# Importance ----
## Total froam the ranger object
## Train dataset ----
tiff(paste0(result_path,"Importance_permutation_Dengue_rf_class_train_",Sys.Date(),".tiff"),
     width = 480 * 5,
     height = 480 * 6,
     res = 72 * 5, compression = "lzw")
print(
  plot_rf_importance(rf_model = dengue.class.model,
                     original_data = x_train,
                     title = "")
)
dev.off()

# importance_pvalues(dengue.class.model, method = "altmann")

png(paste0(result_path,"Importance_permutation_Dengue_rf_class_train_",Sys.Date(),".png"),
    width = 480 * 5,
    height = 480 * 6,
    res = 72 * 5)
print(
  plot_rf_importance(rf_model = dengue.class.model,
                     original_data = x_train,
                     title = "")
)
dev.off()

## Test dataset ----
tiff(paste0(result_path,"Importance_permutation_Dengue_rf_class_test_",Sys.Date(),".tiff"),
     width = 480 * 5,
     height = 480 * 6,
     res = 72 * 5, compression = "lzw")
print(
  plot_rf_importance(rf_model = dengue.class.model,
                     original_data = x_test,
                     title = "")
)
dev.off()

png(paste0(result_path,"Importance_permutation_Dengue_rf_class_test_",Sys.Date(),".png"),
    width = 480 * 5,
    height = 480 * 6,
    res = 72 * 5)
print(
  plot_rf_importance(rf_model = dengue.class.model,
                     original_data = x_test,
                     title = "")
)
dev.off()

# Local Importance ----

# vip(rf.class.chik, num_features = 20, geom = "point") +
#   theme_minimal() +
#   ggtitle("Import�ncia das Vari�veis (Ranger)")

# Partial dependency ----
## Train data ----
Sys.time() ; time_ini <- Sys.time()
dengue.class.dependence.train <-
  plot_all_partial_effects(model = dengue.class.model,
                           data = x_train,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

ggsave(filename = paste0(result_path,"Partial_dependence_Dengue_class_selected_train_",Sys.Date(),".png"),
       plot = dengue.class.dependence.train,
       width = 12,
       height = 8,
       dpi = 600)

## Test data ----
Sys.time() ; time_ini <- Sys.time()
dengue.class.dependence.test <-
  plot_all_partial_effects(model = dengue.class.model,
                           data = x_test,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

ggsave(filename = paste0(result_path,"Partial_dependence_Dengue_class_selected_test_",Sys.Date(),".png"),
       plot = dengue.class.dependence.test,
       width = 12,
       height = 8,
       dpi = 600)


suppressWarnings(
  rm(tab, test_class, train_class, diag.rf.class.den.week, x, time_end, time_end1, time_ini, size, diag.rf.class.den.test, diag.rf.class.den.train, z)
)
while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Dengue_RF_",Sys.Date(),".RData"))
