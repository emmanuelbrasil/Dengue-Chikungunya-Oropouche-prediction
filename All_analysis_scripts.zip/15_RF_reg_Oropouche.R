suppressMessages(library(parallel))
suppressMessages(library(doParallel))
suppressMessages(library(labelled))
suppressMessages(library(tidyverse))
# suppressMessages(library(plotly))
# suppressMessages(library(scatterplot3d))
suppressMessages(library(randomForest))
# suppressMessages(library(cluster))
suppressMessages(library(rfUtilities))
suppressMessages(library(Boruta))
suppressMessages(library(ranger))
suppressMessages(library(rFerns))
suppressMessages(library(pdp))
suppressMessages(library(rms))
suppressMessages(library(DiagnosisMed))
suppressMessages(library(UncertainInterval))
suppressMessages(library(givitiR))
suppressMessages(library(flextable))
suppressMessages(library(patchwork))

env_temp <- new.env()
load(paste0(data_path, "Imputed_data_", Sys.Date(), ".RData"), envir = env_temp)
# load(paste0("~/Projetos/Oropouche/dados/Imputed_data_2026-03-18.RData"), envir = env_temp)
bi <- env_temp$bi
data_path <- env_temp$data_path
result_path <- env_temp$result_path
script_path  <- env_temp$script_path
rm(env_temp)

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Declaring predictors ----
predictors <- c(
  "SEMANA_NUM",
  "IDADE_ANOS_DT_NOTIFIC",
  "SEXO",
  "GESTANTE", #
  "RACA_COR",
  # "PCD", # this predictor has almost no variance
  # "MORADOR_RUA", # this predictor has almost no variance
  "ESCOLARIDADE",
  "ZONA",
  "DC_FEBRE",
  "DC_CEFALEIA",
  "DC_VOMITO",
  "DC_DOR_COSTAS",
  "DC_ARTRITE",
  "DC_PETEQUIAS",
  "DC_PROVA_LACO",
  "DC_MIALGIA",
  "DC_EXANTEMA",
  "DC_NAUSEAS",
  "DC_CONJUTIVITE",
  "DC_ARTRALGIA_INTENSA",
  "DC_LEUCOPENIA",
  "DC_DOR_RETROORBITAL",
  "DC_DIABETES",
  "DC_HEPATOPATIAS",
  "DC_HIPER_ARTERIAL",
  "DC_AUTO_IMUNES",
  "DC_HEMATOLOGICAS",
  "DC_RENAL_CRONICA",
  "DC_ACIDO_PEPTICA"
)
# length(predictors)

# bi <- bi %>% select(all_of(predictors))
# save(bi , file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))
# load(file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))

# Preparing for balance the forests ----

# Oropouche ----

# table(bi %>%
#        filter(VALIDATION_3 == "Development") %>%
#        pull(OROPOUCHE_01))

x_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  select(all_of(predictors))
y_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  pull(OROPOUCHE_01)
#
x_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  select(all_of(predictors))
y_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  pull(OROPOUCHE_01)

dens <- density(y_train)
weights <- 1 / approx(dens$x, dens$y, xout = y_train)$y
size <- 16250
fraction <- size/nrow(x_train)

rm(bi)
gc()

# Tuning mtry ----
set.seed(1753109393)
Sys.time(); time_ini <- Sys.time()
rf.oro.tuned <-
  tuneRF(x = x_train,
         y = y_train,
         # xtest = x_test,
         # ytest = y_test,
         proximity = FALSE,
         improve = 0.001,
         ntreeTry = 350,
         mtryStart = 15,
         stepFactor = 1.5,
         doBest = TRUE,
         plot = TRUE,
         corr.bias = TRUE,
         final.model = FALSE,
         parsimony = TRUE,
         keep.inbag = FALSE,
         localImp = FALSE,
         sampsize = size,
         classwt = weights,
         replace = TRUE,
         strata = y_train,
         seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
# x <- plot(rf.oro.tuned)
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# the black is the overall error
# plot(rf.oro.tuned)
# rf.oro.tuned
# rf.oro.tuned$mtry

# Selecting predictors ----
set.seed(1753109393)
Sys.time()
rf.reg.oro <- Boruta(
  x = x_train,
  y = y_train,
  doTrace = 2,
  getImp = getImpRfZ,
  sample.fraction = fraction,
  case.weights = weights,
  num.trees = 350,
  num.threads = 4,
  maxRuns = 15,
  holdHistory = TRUE,
  keep.inbag = FALSE,
  mtry = rf.oro.tuned$mtry,
  seed = 1753109393
)
Sys.time() ; rf.reg.oro$timeTaken
# print(rf.reg.oro)
rf.reg.oro <- TentativeRoughFix(rf.reg.oro)
predictors_selected <- getSelectedAttributes(rf.reg.oro)

# Importance Permutations (shadow fatures) ----
tiff(paste0(result_path,"Importance_normzlized_Oropouche_RF_reg_",Sys.Date(),".tiff"),
     width = 480 * 12,
     height = 480 * 12,
     res = 72 * 12, compression = "lzw")
w <- rf.reg.oro
colnames(w$ImpHistory) <- c(unname(unlist(var_label(x_train))),c("Max shadow feature", "Mean shadow feature", "Min shadow feature"))
opar <- par()
par(mar = c(5.1, 8.1, 4.1, 2.1))
plot(w,
     las = 2,
     cex.axis = 0.7,
     xlab = "Variable normalized permutation importance (shadow features iterations)",
     ylab = "",
     cex.lab = .9,
     horizontal = TRUE)
grid()
legend("bottomright",
       legend = c("Selected","Shadow features","Removed"),
       fill = c("green", "blue","red"),
       bty = "n",
       cex = .9)
suppressWarnings(par(opar)) ; rm(opar, w)
dev.off()

png(paste0(result_path,"Importance_normzlized_Oropouche_RF_reg_",Sys.Date(),".png"),
    width = 480 * 12,
    height = 480 * 12,
    res = 72 * 12)
w <- rf.reg.oro
colnames(w$ImpHistory) <- c(unname(unlist(var_label(x_train))),c("Max shadow feature", "Mean shadow feature", "Min shadow feature"))
opar <- par()
par(mar = c(5.1, 8.1, 4.1, 2.1))
plot(w,
     las = 2,
     cex.axis = 0.7,
     xlab = "Variable normalized permutation importance (shadow features iterations)",
     ylab = "",
     cex.lab = .9,
     horizontal = TRUE)
grid()
legend("bottomright",
       legend = c("Selected","Shadow features","Removed"),
       fill = c("green", "blue","red"),
       bty = "n",
       cex = .9)
suppressWarnings(par(opar)) ; rm(opar, w)
dev.off()


# RF reg model ----
Sys.time()
time_ini <- Sys.time()
oropouche.reg.model <- ranger(
  x = x_train[, predictors_selected],
  y = y_train,
  num.trees = 350,
  mtry = rf.oro.tuned$mtry,
  importance = 'permutation',
  # probability = TRUE,
  num.threads = 4,
  write.forest  = TRUE,
  sample.fraction = fraction,
  case.weights = weights,
  replace = TRUE,
  keep.inbag = FALSE,
  seed = 1753109393,
  oob.error = TRUE,
  save.memory = FALSE,
  verbose = TRUE
) ; time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

## Saving reg models ----
save(oropouche.reg.model,
     file = paste0(data_path,"Oropouche_rf_reg_models_",Sys.Date(),".RData"))

# Prediction (Train and Test) ----
# p <- predict(oropouche.reg.model,
#              data = x_test,
#              type = "response",
#              num.threads = 0)

p_train <-
  pmin(
    pmax(
      round(predict(oropouche.reg.model,
                    data = x_train,
                    type = "response",
                    num.threads = 0)$predictions, 3),
      0.001),
    0.999)

p_test <-
  pmin(
    pmax(
      round(
        predict(oropouche.reg.model,
                data = x_test,
                type = "response",
                num.threads = 0)$predictions,
        3),
      0.001),
    0.999)

## AUC R2 and mean error ----
### Original predictions ----

performance.rf.reg.oro <-
  t(bind_rows(val.prob(y = y_train,
                       p = p_train)[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")],
              val.prob(y = y_test,
                       p = p_test)[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]))
colnames(performance.rf.reg.oro) <- c("Train/Development","Test/Validation")
performance.rf.reg.oro <-
  performance.rf.reg.oro %>%
  as_tibble(rownames = "Statistics")


### Scaled predictions ----
# Platt Scaling (Log�stic) ---
oropouche.reg.plat.model <- glm(y ~ prob,
                            data = tibble(y = y_test, prob = p_test),
                            family = binomial)
p_train_scaled <-
  round(
    predict(oropouche.reg.plat.model,
            newdata = tibble(prob = p_train),
            type = "response")
    ,3)


p_test_scaled <-
  round(
    predict(oropouche.reg.plat.model,
            newdata = tibble(prob = p_test),
            type = "response"),
    3)

# Isotonic Regression ---
# oropouche.reg.iso.model <- as.stepfun(isoreg(p_test, y_test))
# val.prob(y = y_test,
#          p = oropouche.reg.iso.model(p_test)
#          )[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]
# title(main = "Isotonic")
#
# val.prob(y = y_train,
#          p = oropouche.reg.iso.model(p_train)
# )[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]
# title(main = "Isotonic")

performance.rf.reg.oro <-
  bind_cols(
    performance.rf.reg.oro,
    "Scaled - Train" = val.prob(y = y_train,
                                p = p_train_scaled,
                                g = 10,
                                pl = FALSE
    )[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")],
    "Scaled - Test" = val.prob(y = y_test,
                               p = p_test_scaled,
                               g = 10,
                               pl = FALSE
    )[c("C (ROC)","R2","Intercept","Slope","Eavg","E90","Emax")]
  )

save(performance.rf.reg.oro, file = paste0(data_path,"Oropouche_peformance_",Sys.Date(),".RData"))

## Combined Flextable ----
performance.rf.reg.oro <-
  performance.rf.reg.oro %>%
  flextable() %>%
  colformat_double(digits = 3) %>%
  autofit() %>%
  set_caption("Random forest regression selected performance measures estimated from the predicted probabilities scaled predicted probabilities of Oropouche fever on different datasets.") %>%
  add_footer_lines("C (ROC) = c statistic or area under the ROC curve; Eavg = average error; Train = dataset split used in development; Test = dataset split used in exterval validation; E90 = percentile 90 of prediction error; Emax = maximum prediction error. Scaled predictions were obtained from Plat (logistic) method") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  align(j = 2:5, align = "center", part = "all") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# performance.rf.reg.oro

save_as_docx(
  values = list(performance.rf.reg.oro) ,
  path = paste0(result_path,"Performance_reg_Oropouche_",Sys.Date(),".docx"),
)

## Calibration belt ----
oropouche.reg.model.train.cb <-
  givitiCalibrationBelt(
    o = y_train,
    e = p_train,
    devel = "internal")

oropouche.reg.model.test.cb <-
  givitiCalibrationBelt(
    o = y_test,
    e = p_test,
    devel = "external")

oropouche.reg.model.train.plat.cb <-
  givitiCalibrationBelt(
    o = y_train,
    e = p_train_scaled,
    devel = "internal")

oropouche.reg.model.test.plat.cb <-
  givitiCalibrationBelt(
    o = y_test,
    e = p_test_scaled,
    devel = "external")

save(oropouche.reg.model.train.plat.cb,
     oropouche.reg.model.test.plat.cb,
     file = paste0(data_path,"Oropouche_rf_reg_calibration_",Sys.Date(),".RData"))

png(paste0(result_path,"Oropouche_rf_reg_belt_",Sys.Date(),".png"),
    width = 480*8, height = 480*8, res = 72 * 6)

par(mfrow = c(2,2))
plot(oropouche.reg.model.train.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Train dataset")

plot(oropouche.reg.model.test.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Test dataset")

plot(oropouche.reg.model.train.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Scaled - train dataset")

plot(oropouche.reg.model.test.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Scaled - test dataset")

dev.off()

# Decision limits (scaled only)----

## Train dataset ----

# storage.mode(p)  <- "double"
# r <- if_else(y_train == "Yes", 1, 0)
# storage.mode(r)  <- "double"

minor_breaks <- seq(0, 1, by = 0.025)
breaks_labels <- ifelse(round(minor_breaks * 100) %% 5 == 0,
                        format(minor_breaks, nsmall = 2),"")

### Uncertain-Interval ----
ui_train <-
  ui.nonpar(ref = y_train,
            test = p_train_scaled,
            # intersection = .5,
            direction = "<")

### Mixed densities ----
png(paste0(result_path,"Mixed_densities_Oropouche_rf_reg_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 4)

print(
oropouche.reg.train.mix.dens <-
  ggplot(tibble(p = p_train_scaled,
                class = as.factor(y_train)),
       aes(x = p_train_scaled, fill = class, colour = class)) +
  geom_histogram(aes(y = after_stat(density)),
                 binwidth = 0.005,
                 alpha = 0.6,
                 position = "identity",
                 color = "white") +
  geom_density(linewidth = 0.8, alpha = .35) +
  annotate("rect", xmin = ui_train["cp.l"], xmax = ui_train["cp.h"], ymin = 0, ymax = Inf,
           fill = "gray", alpha = 0.20) +
  geom_vline(xintercept =  ui_train["intersection"], color = "black", linewidth = 0.8) +
  scale_fill_manual(
    labels = c("0" = "without Oropouche", "1" = "with Oropouche"),
    values = c("0" = "lightblue", "1" = "pink")) +
  scale_color_manual(
    labels = c("0" = "without Oropouche", "1" = "with Oropouche"),
    values = c("0" = "lightblue", "1" = "pink")) +
  scale_x_continuous(
    name = "Model predictions",
    breaks = minor_breaks,
    labels = breaks_labels
  ) +
  labs(y = "Density",
       # title = "Train dataset - scaled predictions",
       caption = paste0("Mixed-distribution intersection at: ", round(ui_train["intersection"], 3),
                        "\n Non-parametric uncertain interaval limits at 0.55 accuracy: ",
                      sprintf("%.3f", ui_train["cp.l"]),"-",
                      sprintf("%.3f", ui_train["cp.h"]))) +
  coord_cartesian(ylim = c(0, 15)) +
  theme_light() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "top",
    legend.title = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.ticks.length = unit(0.2, "cm"),
    axis.ticks = element_line(colour = "black"),
    plot.caption = element_text(hjust = 0.5, size = 9, face = "italic")
  )
)
dev.off()


### TGROC inconclusive ----
oropouche.reg.train.tgroc <- SS(ref = y_train, test = p_train_scaled)
#
inc.int <- inc.value(oropouche.reg.train.tgroc)
z_train <- inc.limits(oropouche.reg.train.tgroc, inc.int)

png(paste0(result_path,"TGROC_Oropouche_rf_reg_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

print(
  oropouche.reg.train.tgroc.plot <-
    ggplot(oropouche.reg.train.tgroc$table %>%
             select(test.values, Sensitivity, Specificity),
           aes(x = test.values)) +
    annotate("rect", xmin = z_train$test.values[1], xmax = z_train$test.values[2], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric inconclusive limits at ",
                      inc.int, ":",
                      sprintf("%.3f", z_train$test.values[1]),"-",
                      sprintf("%.3f", z_train$test.values[2]),
                      "\n Sensitivity equals Specificity at:",
                      Se.equals.Sp(oropouche.reg.train.tgroc)$test.values)
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    scale_x_continuous(
      # limits = c(0, 1),
      breaks = minor_breaks,
      labels = breaks_labels
    ) +
    # scale_y_continuous(
    #   # limits = c(0, 1),
    #   breaks = minor_breaks,
    #   labels = breaks_labels
    # ) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          axis.ticks = element_line(colour = "black"),
          axis.ticks.length = unit(0.15, "cm"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5, size = 9, face = "italic"))
)
dev.off()

### TGROC plot UI ----
png(paste0(result_path,"TGROC_UI_Oropouche_rf_reg_train_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

print(
  oropouche.reg.train.tgrocUI.plot <-
    ggplot(oropouche.reg.train.tgroc$table %>%
             select(test.values, Sensitivity, Specificity),
           aes(x = test.values)) +
    annotate("rect", xmin = ui_train["cp.l"], xmax = ui_train["cp.h"], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric uncertain interaval limits at 0.55 accuracy:",
                      sprintf("%.3f", ui_train["cp.l"]),"-",
                      sprintf("%.3f", ui_train["cp.h"]),
                      "\n Mixed-distribution intersection at: ", round(ui_train["intersection"],3))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    scale_x_continuous(
      # limits = c(0, 1),
      breaks = minor_breaks,
      labels = breaks_labels
    ) +
    # scale_y_continuous(
    #   limits = c(0, 1),
    #   breaks = minor_breaks,
    #   labels = breaks_labels
    # ) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          axis.ticks = element_line(colour = "black"),
          axis.ticks.length = unit(0.15, "cm"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5, size = 9, face = "italic"))
)

dev.off()

## Test dataset ----
# storage.mode(p)  <- "double"
# r <- if_else(y_test == "Yes", 1, 0)
# storage.mode(r)  <- "double"
# head(r)
# head(p)

### Uncertain-Interval ----
ui_test <-
  ui.nonpar(ref = y_test,
            test = p_test_scaled,
            # intersection = .5,
            direction = "<")

### Mixed densities ----
png(paste0(result_path,"Mixed_densities_Oropouche_rf_reg_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 4)

print(
  oropouche.reg.test.mix.dens <-
    ggplot(tibble(p = p_test_scaled,
                  class = as.factor(y_test)),
           aes(x = p_test_scaled, fill = class, colour = class)) +
    geom_histogram(aes(y = after_stat(density)),
                   binwidth = 0.005,
                   alpha = 0.6,
                   position = "identity",
                   color = "white") +
    geom_density(linewidth = 0.8, alpha = .35) +
    annotate("rect", xmin = ui_test["cp.l"], xmax = ui_test["cp.h"], ymin = 0, ymax = Inf,
             fill = "gray", alpha = 0.20) +
    geom_vline(xintercept =  ui_test["intersection"], color = "black", linewidth = 0.8) +
    scale_fill_manual(
      labels = c("0" = "without Oropouche", "1" = "with Oropouche"),
      values = c("0" = "lightblue", "1" = "pink")) +
    scale_color_manual(
      labels = c("0" = "without Oropouche", "1" = "with Oropouche"),
      values = c("0" = "lightblue", "1" = "pink")) +
    scale_x_continuous(
      name = "Model predictions",
      breaks = minor_breaks,
      labels = breaks_labels
    ) +
    labs(y = "Density",
         # title = "Test dataset",
         caption = paste0("Mixed-distribution intersection at: ", round(ui_test["intersection"], 3),
                          "\n Non-parametric uncertain interaval limits at 0.55 accuracy: ",
                          sprintf("%.3f", ui_test["cp.l"]),"-",
                          sprintf("%.3f", ui_test["cp.h"]))) +
    coord_cartesian(ylim = c(0, 15)) +
    theme_light() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      legend.position = "top",
      legend.title = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "bold"),
      axis.ticks.length = unit(0.2, "cm"),
      axis.ticks = element_line(colour = "black"),
      plot.caption = element_text(hjust = 0.5, size = 9, face = "italic")
    )
)
dev.off()


### TGROC inconclusive ----
oropouche.reg.test.tgroc <- SS(ref = y_test, test = p_test_scaled)
#
inc.int <- inc.value(oropouche.reg.test.tgroc)
z_test <- inc.limits(oropouche.reg.test.tgroc, inc.int)

png(paste0(result_path,"TGROC_Oropouche_rf_reg_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

print(
  oropouche.reg.test.tgroc.plot <-
    ggplot(oropouche.reg.test.tgroc$table %>%
             select(test.values, Sensitivity, Specificity),
           aes(x = test.values)) +
    annotate("rect", xmin = z_test$test.values[1], xmax = z_test$test.values[2], ymin = 0, ymax = 1,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric inconclusive limits at ",
                      inc.int, ":",
                      sprintf("%.3f", z_test$test.values[1]),"-",
                      sprintf("%.3f", z_test$test.values[2]),
                      "\n Sensitivity equals Specificity at:",
                      Se.equals.Sp(oropouche.reg.test.tgroc)$test.values)
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    scale_x_continuous(
      # limits = c(0, 1),
      breaks = minor_breaks,
      labels = breaks_labels
    ) +
    # scale_y_continuous(
    #   limits = c(0, 1),
    #   breaks = minor_breaks,
    #   labels = breaks_labels
    # ) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          axis.ticks = element_line(colour = "black"),
          axis.ticks.length = unit(0.15, "cm"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5, size = 9, face = "italic"))
)
dev.off()

### TGROC plot UI ----


png(paste0(result_path,"TGROC_UI_Oropouche_rf_reg_test_",Sys.Date(),".png"),
    width = 480*4,
    height = 480*4,
    res = 72 * 5)

print(
  oropouche.reg.test.tgrocUI.plot <-
    ggplot(oropouche.reg.test.tgroc$table %>%
             select(test.values, Sensitivity, Specificity),
           aes(x = test.values)) +
    annotate("rect", xmin = ui_test["cp.l"], xmax = ui_test["cp.h"], ymin = 0, ymax = Inf,
             fill = "gray", alpha = 0.3) +
    geom_line(aes(y = Sensitivity, colour = "Sensitivity"), linewidth = 1) +
    geom_line(aes(y = Specificity, colour = "Specificity"), linewidth = 1) +
    labs(
      x = "Model predictions",
      y = "Sensitivity & Specificity",
      caption = paste("Non-parametric uncertain interaval limits at 0.55 accuracy:",
                      sprintf("%.3f", ui_test["cp.l"]),"-",
                      sprintf("%.3f", ui_test["cp.h"]),
                      "\n Mixed-distribution intersection at: ", round(ui_test["intersection"],3))
    )+
    scale_color_manual(values = c("Sensitivity" = "blue", "Specificity" = "red")) +
    scale_x_continuous(
      # limits = c(0, 1),
      breaks = minor_breaks,
      labels = breaks_labels
    ) +
    # scale_y_continuous(
    #   limits = c(0, 1),
    #   breaks = minor_breaks,
    #   labels = breaks_labels
    # ) +
    theme_light() +
    theme(legend.position = "top",
          legend.box = "horizontal",
          legend.title = element_blank(),
          legend.background = element_rect(colour = 'white', fill = 'white'),
          axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          axis.ticks = element_line(colour = "black"),
          axis.ticks.length = unit(0.15, "cm"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          plot.caption = element_text(hjust = 0.5, size = 9, face = "italic"))
)

dev.off()

### Saving all plots ----
oropouche.limits.plots <- (oropouche.reg.train.mix.dens +
                           oropouche.reg.test.mix.dens +
                           oropouche.reg.train.tgrocUI.plot +
                           oropouche.reg.test.tgrocUI.plot +
                           oropouche.reg.train.tgroc.plot +
                           oropouche.reg.test.tgroc.plot) +
  plot_layout(ncol = 2, nrow = 3) +
  # plot_layout(guides = 'collect') +
  plot_annotation(# title = "An�lise de Desempenho e Calibra��o - Oropouche",
                  # subtitle = "Compara��o entre diferentes modelos e datasets",
                  tag_levels = 'A',
                  caption = "A: Mixed Densities (train - scaled); B: Mixed Densities (test - scaled); \n C: TGROC (train - scaled) with uncertain interval;  D: TGROC (test - scaled) with uncertain interval; \n E: TGROC (train - scaled) with inconclusive limits;  F: TGROC (test - scaled) with inconclusive limits."
                  ) &
  theme(plot.tag = element_text(face = 'bold', size = 14))

# print(oropouche.limits.plots)

# Para salvar em alta qualidade:
ggsave(paste0(result_path,"All_plots_Oropouche_rf_reg_limits_",Sys.Date(),".png"),
       plot = oropouche.limits.plots,
       width = 12,
       height = 16,
       dpi = 600)

## Performance with baniry limit
bin_limit <- Se.equals.Sp(oropouche.reg.test.tgroc)$test.values
tab_train <-
  table(
    if_else(p_train_scaled >= bin_limit, 1, 0),
    y_train)
tab_test <-
  table(
    if_else(p_test_scaled >= bin_limit, 1, 0),
    y_test)
storage.mode(tab_train) <- "double"
storage.mode(tab_test) <- "double"

diag.rf.reg.oro <-
  left_join(
    diagnosis(tab = tab_train)$results %>%
      rownames_to_column(var = "Statistics"),
    diagnosis(tab = tab_test)$results %>%
      rownames_to_column(var = "Statistics"),
    by = "Statistics", suffix = c("_train", "_test")
  ) %>%
  flextable() %>%
  set_header_labels(
    Estimate_train = "Estimate", lower.cl_train = "95% lower cl", upper.cl_train = "95% upper cl",
    Estimate_test = "Estimate", lower.cl_test = "95% lower cl", upper.cl_test = "95% upper cl"
  ) %>%
  add_header_row(
    values = c("", "Training dataset", "Test dataset"),
    colwidths = c(1, 3, 3)
  ) %>%
  align(i = 1, align = "center", part = "header") %>%
  colformat_double(digits = 3, na_str = "Na", nan_str = "Na") %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0, na_str = "---") %>%
  colformat_double(i = ~ Statistics == "Area under ROC curve:", digits = 3, na_str = "---") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  autofit() %>%
  set_caption("Regression random forest performance measures for Oropouche fever with scaled predictions: Training vs. Validation.") %>%
  add_footer_lines("lower cl = lower confidence limit; upper cl = upper confidence limit; Na = not assigned; Inf = Infinite. Decision limit set as 0.03 (from the sensitivity equals specificity from the test dataset)") %>%
  border_remove() %>%
  hline_top(part = "header", border = officer::fp_border(width = 2)) %>%
  hline_bottom(part = "body", border = officer::fp_border(width = 2)) %>%
  vline(j = 4, border = officer::fp_border(color = "gray90", width = 1), part = "all") %>%
  align(j = 2:7, align = "center", part = "all") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# diag.rf.reg.oro

save_as_docx(
  values = list(diag.rf.reg.oro) ,
  path = paste0(result_path,"Table_SeSp_creg_Oropouche_",Sys.Date(),".docx"),
)

# Partial dependency ----
## Train data ----
Sys.time() ; time_ini <- Sys.time()
oropouche.reg.dependence.train <-
  plot_all_partial_effects(model = oropouche.reg.model,
                           data = x_train,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_reg_selected_train_",Sys.Date(),".png"),
       plot = oropouche.reg.dependence.train,
       width = 12,
       height = 8,
       dpi = 600)

## Test data ----
Sys.time() ; time_ini <- Sys.time()
oropouche.reg.dependence.test <-
  plot_all_partial_effects(model = oropouche.reg.model,
                           data = x_test,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
time_end <- Sys.time(); difftime(time_end, time_ini, units = "mins")

ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_reg_selected_test_",Sys.Date(),".png"),
       plot = oropouche.reg.dependence.test,
       width = 12,
       height = 8,
       dpi = 600)

# Importance ----
## Total froam the ranger object
## Train dataset ----
# tiff(paste0(result_path,"Importance_permutation_Oropouche_rf_reg_train_",Sys.Date(),".tiff"),
#      width = 480 * 5,
#      height = 480 * 6,
#      res = 72 * 5, compression = "lzw")
# print(
#   plot_rf_importance(rf_model = oropouche.reg.model,
#                      original_data = x_train,
#                      title = "")
# )
# dev.off()

# importance_pvalues(oropouche.reg.model, method = "altmann")

png(paste0(result_path,"Importance_permutation_Oropouche_rf_reg_train_",Sys.Date(),".png"),
    width = 480 * 5,
    height = 480 * 6,
    res = 72 * 5)
print(
  plot_rf_importance(rf_model = oropouche.reg.model,
                     original_data = x_train,
                     title = "")
)
dev.off()

## Test dataset ----
# tiff(paste0(result_path,"Importance_permutation_Oropouche_rf_reg_test_",Sys.Date(),".tiff"),
#      width = 480 * 5,
#      height = 480 * 6,
#      res = 72 * 5, compression = "lzw")
# print(
#   plot_rf_importance(rf_model = oropouche.reg.model,
#                      original_data = x_test,
#                      title = "")
# )
# dev.off()

png(paste0(result_path,"Importance_permutation_Oropouche_rf_reg_test_",Sys.Date(),".png"),
    width = 480 * 5,
    height = 480 * 6,
    res = 72 * 5)
print(
  plot_rf_importance(rf_model = oropouche.reg.model,
                     original_data = x_test,
                     title = "")
)
dev.off()

suppressWarnings(
  rm(tab, test_class, train_class, diag.rf.class.oro.week, x, time_end, time_end1, time_ini, size, diag.rf.class.oro.test, diag.rf.class.oro.train, z, z_test, z_train, dens, bin_limits, breaks_labels, fraction, inc.int, minor_breaks, oropouche,reg.iso.model, p, size_ranger, tab_test, tab_train, weights, ui_test, ui_train, y, bin_limit, oropouche.reg.iso.model, oropouche.reg.plat.model.cb)
)

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save(oropouche.reg.model,
     oropouche.reg.plat.model,
     predictors_selected,
     oropouche.reg.test.tgroc,
     file = paste0(data_path,"Oropouche_rf_reg_models_",Sys.Date(),".RData"))

save.image(paste0(data_path,"Oropouche_RF_reg_",Sys.Date(),".RData"))
# load(paste0("~/Projetos/Oropouche/dados/Oropouche_RF_reg_2026-03-19.RData"))
