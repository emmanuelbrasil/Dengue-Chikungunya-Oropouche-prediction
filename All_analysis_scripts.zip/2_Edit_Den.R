# install.packages("aweek")
suppressMessages(library(tidyverse))
suppressMessages(library(tsibble))
# suppressMessages(library(table1, lib.loc = "/usr/local/lib/R/site-library"))


load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Dengue ----
#In the dengue notification form:
#C before variables stands for clinical and laboratory investigation
#DC before variables stands for clinical diagnosis
#DL before variables stands for laboratory diagnosis
#H before variables stands for hospitalization data
#AG before variables stands for alarm and severity

# Editing data ----
den <-
  den %>%
    rename(MORADOR_RUA = MOARADOR_RUA,
           AG_METRORAGIA_VOLUMOSA = AG_METORRAGIA_COLUMOSA) %>%
    mutate(O_DATASET = "Dengue",
           DATA_NOTIFICACAO = dmy(DATA_NOTIFICACAO),
           SEMANA_NOTIFICACAO = yearweek(DATA_NOTIFICACAO,
                                          week_start = 7),
           DATA_DIAGNOSTICO = dmy(DATA_DIAGNOSTICO), # In�cio dos sintomas
           SEMANA_DIAGNOSTICO = yearweek(DATA_DIAGNOSTICO,
                                          week_start = 7),
           CNS_valid = is_cns(CARTAO_SUS),
           IDADE_CAT = cut(IDADE_ANOS_DT_NOTIFIC,
                           include.lowest = TRUE,
                           breaks = c(0,1,12,18,25,35,45,55,65,75,85,95)),
           SEXO = factor(SEXO,
             levels = c("F","M","I"),
             labels = c("Female", "Male","Ignored")),
           GESTANTE = factor(GESTANTE,
             levels = c(
               "1 -1� trimestre",
               "2 -2� trimestre",
               "3 -3� trimestre",
               "4 -Idade gestacional ignorada",
               "5 -N�o",
               "6 -N�o se aplica",
               "9 -Ignorado"),
             labels = c(
               "1st trimester",
               "2nd trimester",
               "3rd trimester",
               "Gestational age unknown",
               "No",
               "Not applicable",
               "Ignored/Unknown")),
           RACA_COR = factor(RACA_COR,
             levels = c(
               "1 -Branca", "2 -Preta", "3 -Amarela", "4 -Parda",
               "5 -Indigena", "9 -Ignorado"),
             labels = c(
               "White", "Black", "Yellow", "Brown",
               "Indigenous", "Ignored/Unknown")),
           ETNIA = factor(ETNIA,
             levels = c("1 -Tupiniquim", "2 -Guarani", "9 -Ignorado"),
             labels = c("Tupiniquim", "Guarani", "Ignored/Unknown")),
           PCD = factor(PCD,
             levels = c("1 -Sim", "2 -N�o"),
             labels = c("Yes", "No")),
           MORADOR_RUA = factor(MORADOR_RUA,
             levels = c("1 -Sim", "2 -N�o"),
             labels = c("Yes", "No")),
           ESCOLARIDADE = factor(ESCOLARIDADE,
             levels = c(
               "0 -Analfabeto",
               "1 -1� a 4� s�rie incompleta do EF (antigo prim�rio ou 1� grau)",
               "2 -4� s�rie completa do EF (antigo prim�rio ou 1� grau)",
               "3 -5� � 8� s�rie incompleta do EF (antigo gin�sio ou 1� grau)",
               "4 -Ensino fundamental completo (antigo gin�sio ou 1� grau) ",
               "5 -Ensino m�dio incompleto (antigo colegial ou 2� grau )",
               "6 -Ensino m�dio completo (antigo colegial ou 2� grau ) ",
               "7 -Educa��o superior incompleta ",
               "8 -Educa��o superior completa",
               "9 -Ignorado",
               "10 -N�o se aplica"),
             labels = c(
               "Illiterate",
               "Elementary School Incomplete",
               "Elementary School Complete",
               "Middle School Incomplete",
               "Middle School Complete",
               "High School Incomplete",
               "High School Complete",
               "Higher Education Incomplete",
               "Higher Education Complete",
               "Ignored/Unknown",
               "Not applicable")),
           ZONA = factor(ZONA,
                         levels = c("1 -Urbana","2 -Rural","3 -Periurbana","9 -Ignorado"),
                         labels = c("Urban","Rural","Peri-urban","Unknown")),
           C_CLASSIFIC = factor(C_CLASSIFIC,
                                levels = c("5","10","11","12","13"),
                                labels = c("Not Dengue",
                                           "Dengue",
                                           "Dengue with alarm",
                                           "Severe Dengue",
                                           "Chikungunya")),
           C_CRIT_CONF_DESC = factor(C_CRIT_CONF_DESC,
                                     levels = c("1","2","3"),
                                     labels = c("Laboratory","Clinical-epideiological","Not concluded")),
           C_AUTOCTONE = factor(C_AUTOCTONE,
                                levels = c("2","1","3"),
                                labels = c("No","Yes","Unknown")),
           C_EVOLUC_CASO = factor(C_EVOLUC_CASO,
                                  levels = c("1","2","3","4","9"),
                                  labels = c("Recovered",
                                             "Death (arbovirus)",
                                             "Death (other causes)",
                                             "Death (investigating)",
                                             "Ignored")),
           # C_DT_OBITO = dmy(C_DT_OBITO),
           # SEMANA_OBITO = yearweek(C_DT_OBITO,
           #                               week_start = 7),
           DC_FEBRE = factor(DC_FEBRE,
                             levels = c("2","1"),
                             labels = c("No","Yes")),
           DC_CEFALEIA = factor(DC_CEFALEIA,
                             levels = c("2","1"),
                             labels = c("No","Yes")),
           DC_VOMITO = factor(DC_VOMITO,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_DOR_COSTAS = factor(DC_DOR_COSTAS,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_ARTRITE = factor(DC_ARTRITE,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_PETEQUIAS = factor(DC_PETEQUIAS,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_PROVA_LACO = factor(DC_PROVA_LACO,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_MIALGIA = factor(DC_MIALGIA,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_EXANTEMA = factor(DC_EXANTEMA,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_NAUSEAS = factor(DC_NAUSEAS,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_CONJUTIVITE = factor(DC_CONJUTIVITE,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_ARTRALGIA_INTENSA = factor(DC_ARTRALGIA_INTENSA,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_LEUCOPENIA = factor(DC_LEUCOPENIA,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_DOR_RETROORBITAL = factor(DC_DOR_RETROORBITAL,
                                levels = c("2","1"),
                                labels = c("No","Yes")),
           DC_DIABETES = factor(DC_DIABETES,
                                levels = c("2","1","9"),
                                labels = c("No","Yes","Ignored")),
           DC_HEPATOPATIAS = factor(DC_HEPATOPATIAS,
                                    levels = c("2","1","9"),
                                    labels = c("No","Yes","Ignored")),
           DC_HIPER_ARTERIAL = factor(DC_HIPER_ARTERIAL,
                                      levels = c("2","1","9"),
                                      labels = c("No","Yes","Ignored")),
           DC_AUTO_IMUNES = factor(DC_AUTO_IMUNES,
                                   levels = c("2","1","9"),
                                   labels = c("No","Yes","Ignored")),
           DC_HEMATOLOGICAS = factor(DC_HEMATOLOGICAS,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           DC_RENAL_CRONICA = factor(DC_RENAL_CRONICA,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           DC_ACIDO_PEPTICA = factor(DC_ACIDO_PEPTICA,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           DL_S1 = factor(DL_S1,
                          levels = c("2","1","3","4","5"),
                          labels = c("Negative",
                                     "Positive",
                                     "Inconclusive",
                                     "Not performed",
                                     "Waiting results")),
           DL_IGM_DENGUE_RESULT = factor(DL_IGM_DENGUE_RESULT,
                                         levels = c("2","1","3","4"),
                                         labels = c("Negative",
                                                    "Positive",
                                                    "Inconclusive",
                                                    "Not performed")),
           DL_NS1_RESULTADO = factor(DL_NS1_RESULTADO,
                                     levels = c("2","1","3","4"),
                                     labels = c("Negative",
                                                "Positive",
                                                "Inconclusive",
                                                "Not performed")),
           DL_I_RESULT = factor(DL_I_RESULT,
                                levels = c("2","1","3","4"),
                                labels = c("Negative",
                                           "Positive",
                                           "Inconclusive",
                                           "Not performed")),
           DL_RTPCR_DT_COLETA = dmy(DL_RTPCR_DT_COLETA),
           DL_RTPCR_RESULT = factor(DL_RTPCR_RESULT,
                                levels = c("2","1","3","4"),
                                labels = c("Negative",
                                           "Positive",
                                           "Inconclusive",
                                           "Not performed")),
           DL_RTPCR_SOROTIPO = factor(DL_RTPCR_SOROTIPO,
                                    levels = c("1","2","3","4"),
                                    labels = c("DENV-1",
                                               "DENV-2",
                                               "DENV-3",
                                               "DENV-4")),
           DL_HISTOPATOLOGIA = factor(DL_HISTOPATOLOGIA,
                                      levels = c("1","2","3","4"),
                                      labels = c("Dengue compatible",
                                                 "Dengue not compatible",
                                                 "Inconclusive",
                                                 "Not performed")),
           DL_IMUNOHISTOQUIMICA = factor(DL_IMUNOHISTOQUIMICA,
                                      levels = c("2","1","3","4"),
                                      labels = c("Negative",
                                                 "Positive",
                                                 "Inconclusive",
                                                 "Not performed")),
           DENGUE_LAB_DIAG = if_else(DL_NS1_RESULTADO == "Positive" |
                                     DL_I_RESULT == "Positive" |
                                     DL_RTPCR_RESULT  == "Positive" |
                                     DL_HISTOPATOLOGIA == "Dengue compatible" |
                                     DL_IMUNOHISTOQUIMICA   == "Positive", "Yes", "No",
                                     ptype = factor(levels = c("No","Yes"))),
           DENGUE = if_else((C_CLASSIFIC == "Dengue" |
                             C_CLASSIFIC == "Dengue with alarm" |
                             C_CLASSIFIC == "Severe Dengue") |
                            (is.na(C_CLASSIFIC) &
                             DENGUE_LAB_DIAG == "Yes"),
                            "Yes", "No"),
           C_CLASSIFIC = if_else(is.na(C_CLASSIFIC) &
                                 DENGUE_LAB_DIAG == "Yes",
                                 "Dengue", C_CLASSIFIC),
           C_CLASSIFIC = fct_relevel(C_CLASSIFIC,"Not Dengue"),
           DENGUE = if_else(is.na(DENGUE) &
                            DENGUE_LAB_DIAG == "Yes",
                            "Yes", DENGUE),
           CHIKUNGUNYA = if_else(C_CLASSIFIC == "Chikungunya", "Yes", "No"),
           H_HOSPITALIZACAO = factor(H_HOSPITALIZACAO,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           H_DT_INTERNACAO = dmy(H_DT_INTERNACAO),
           SEMANA_INTERNACAO = yearweek(H_DT_INTERNACAO,
                                         week_start = 7),
           C_APRESENTACAO_CLINICA = factor(C_APRESENTACAO_CLINICA,
                                           levels = c(1,2),
                                           labels = c("Acute","Chronic")),
           AG_HIPOTENSAO = factor(AG_HIPOTENSAO,
                                  levels = c("2","1","9"),
                                  labels = c("No","Yes","Ignored")),
           AG_PLAQUETAS = factor(AG_PLAQUETAS,
                                  levels = c("2","1","9"),
                                  labels = c("No","Yes","Ignored")),
           AG_VOMITOS_PERSISTENTES = factor(AG_VOMITOS_PERSISTENTES,
                                            levels = c("2","1","9"),
                                            labels = c("No","Yes","Ignored")),
           AG_DOR_ABDOMINAL = factor(AG_DOR_ABDOMINAL,
                                    levels = c("2","1","9"),
                                    labels = c("No","Yes","Ignored")),
           AG_LETARGIA_IRR = factor(AG_LETARGIA_IRR,
                                    levels = c("2","1","9"),
                                    labels = c("No","Yes","Ignored")),
           AG_SANG_MUCOSA = factor(AG_SANG_MUCOSA,
                                   levels = c("2","1","9"),
                                   labels = c("No","Yes","Ignored")),
           AG_HEMATOCRITO = factor(AG_HEMATOCRITO,
                                   levels = c("2","1","9"),
                                   labels = c("No","Yes","Ignored")),
           AG_HEPATOMEGALIA = factor(AG_HEPATOMEGALIA,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           AG_ACUMULO_LIQUIDOS = factor(AG_ACUMULO_LIQUIDOS,
                                        levels = c("2","1","9"),
                                        labels = c("No","Yes","Ignored")),
           AG_DT_INICIO_ALARMES = dmy(AG_DT_INICIO_ALARMES),
           SEMANA_INICIO_ALARMES = yearweek(AG_DT_INICIO_ALARMES,
                                             week_start = 7),
           AG_PULSO = factor(AG_PULSO,
                             levels = c("2","1","9"),
                             labels = c("No","Yes","Ignored")),
           AG_PA_CONVERGENTE = factor(AG_PA_CONVERGENTE,
                                      levels = c("2","1","9"),
                                      labels = c("No","Yes","Ignored")),
           AG_TEMPO_CAPILAR = factor(AG_TEMPO_CAPILAR,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           AG_AC_LIQUIDOS = factor(AG_AC_LIQUIDOS,
                                   levels = c("2","1","9"),
                                   labels = c("No","Yes","Ignored")),
           AG_TAQUICARDIA = factor(AG_TAQUICARDIA,
                                   levels = c("2","1","9"),
                                   labels = c("No","Yes","Ignored")),
           AG_EXTREMIDADES_FRIAS = factor(AG_EXTREMIDADES_FRIAS,
                                          levels = c("2","1","9"),
                                          labels = c("No","Yes","Ignored")),
           AG_HIPOTENSAO_ARTERIAL = factor(AG_HIPOTENSAO_ARTERIAL,
                                           levels = c("2","1","9"),
                                           labels = c("No","Yes","Ignored")),
           AG_HEMATEMESE = factor(AG_HEMATEMESE,
                                  levels = c("2","1","9"),
                                  labels = c("No","Yes","Ignored")),
           AG_MELENA = factor(AG_MELENA,
                              levels = c("2","1","9"),
                              labels = c("No","Yes","Ignored")),
           AG_METRORAGIA_VOLUMOSA = factor(AG_METRORAGIA_VOLUMOSA,
                                           levels = c("2","1","9"),
                                           labels = c("No","Yes","Ignored")),
           AG_SANGRAMENTO_SNC = factor(AG_SANGRAMENTO_SNC,
                                       levels = c("2","1","9"),
                                       labels = c("No","Yes","Ignored")),
           AG_AST_ALT = factor(AG_AST_ALT,
                               levels = c("2","1","9"),
                               labels = c("No","Yes","Ignored")),
           AG_MIOCARDITE = factor(AG_MIOCARDITE,
                                  levels = c("2","1","9"),
                                  labels = c("No","Yes","Ignored")),
           AG_ALTER_CONSCIENCIA = factor(AG_ALTER_CONSCIENCIA,
                                         levels = c("2","1","9"),
                                         labels = c("No","Yes","Ignored")),
           AG_OUTROS_ORGAOS = factor(AG_OUTROS_ORGAOS,
                                     levels = c("2","1","9"),
                                     labels = c("No","Yes","Ignored")),
           AG_DT_INI_GRAVIDADE = dmy(AG_DT_INI_GRAVIDADE),
           SEMANA_INI_GRAVIDADE = yearweek(AG_DT_INI_GRAVIDADE,
                                             week_start = 7)) %>%
  select(-DL_S2, -DL_PRNT)

# table(den$DENGUE, den$C_CLASSIFIC, useNA ="always")
# table(den$CHIKUNGUNYA, den$C_CLASSIFIC, useNA ="always")
# table(den$CHIKUNGUNYA, den$DENGUE, useNA ="always")

# Samller dataset test analysis ----
# den_minor <-
#   den %>%
#   slice_sample(n = 30000)


# GAL degue data ----
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`
den_gal <-
  den_gal %>%
  select(`N�m. Notifica��o Sinan`,
         `Data Notifica��o Sinan`,
         `CNS do Paciente`,
         Paciente,
         `Data de Nascimento`,
         `Nome da M�e`,
         `Descri��o Finalidade`,
         `Data da Solicita��o`,
         `Data da Coleta`,
         `Nome da Pesquisa`,
         Metodologia,
         Kit,
         Fabricante,
         `1� Campo Resultado`) %>%
  mutate(NUM_NOTIFICACAO = as.numeric(str_replace_all(`N�m. Notifica��o Sinan`, "[^0-9]", "")),
         DATA_NOTIFICACAO = `Data Notifica��o Sinan`,
         CARTAO_SUS = as.numeric(str_replace_all(`CNS do Paciente`, "[^0-9]", "")),
         CNS_valid = is_cns(CARTAO_SUS),
         `Data da Solicita��o` = dmy(`Data da Solicita��o`),
         `Data da Coleta` = dmy(`Data da Coleta`),
         GAL_DEN_RTPCR_RESULT = factor(`1� Campo Resultado`,
                                  levels = c("Resultado: N�o Detect�vel",
                                             "Resultado: Detect�vel"),
                                  labels = c("Negative",
                                             "Positive"))
         ) %>%
  select(-`N�m. Notifica��o Sinan`,
         -`Data Notifica��o Sinan`,
         -`CNS do Paciente`,
         -`1� Campo Resultado`)

# addmargins(table(den_gal$`1� Campo Resultado`, den_gal$GAL_DEN_RTPCR_RESULT))
# addmargins(table(yg$`1� Campo Resultado`, yg$GAL_DEN_RTPCR_RESULT))


# den_gal %>%
#   filter(is.na(DATA_NOTIFICACAO)) %>%
#   pull(`Data da Coleta`)

# head(den_gal2$`Data da Solicita��o`, 20)
# table(den_gal2$`1� Campo Resultado`)
# table(den_gal2$GAL_RTPCR_RESULT)
# table(is.na(den_gal2$`Data da Coleta`))
# table(is.na(den_gal2$`Data da Solicita��o`))
# table(is.na(den_gal2$`N�m. Notifica��o Sinan`))
# table(is.na(den_gal2$NUM_NOTIFICACAO))
# table(den_gal$`N�m. Notifica��o Sinan`)
# table(den_gal$Metodologia)
# table(is.na(den_gal$`Data Notifica��o Sinan`))
# class(den_gal$`Data Notifica��o Sinan`)
# head(den_gal2$DATA_NOTIFICACAO)
# table(is.na(den_gal$`Data de Nascimento`))
#
# grep("DT", names(den), value = TRUE)
# class(den_gal2$`Data Notifica��o Sinan`)
# class(den$DL_RTPCR_DT_COLETA)
# summary(den_gal$`Data Notifica��o Sinan`)

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))
