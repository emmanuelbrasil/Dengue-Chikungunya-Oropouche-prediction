# suppressMessages(library(readr))
suppressMessages(library(tidyverse))
# default options to import unique ID in all datasets
# col_spec <- cols(
#   CARTAO_SUS = col_character(),
#   .default = col_guess()
# )

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# guess_encoding(paste0(data_path, "Dengue_01012023_30062025.csv"))
den <- readr::read_delim(
  file = paste0(data_path, "Dengue_01012023_30062025.csv"),
  delim = ";",
  locale = locale(
    decimal_mark = ",",
    grouping_mark = ".",
    encoding = "ISO-8859-1"
  ),
  # col_types = col_spec,
  show_col_types = FALSE
)
# print(vroom::problems(den),n = 200)

# Import Chikungunya data ----
# guess_encoding(paste0(data_path,"Chikungunya_01012023_30062025.csv"))
chik <- readr::read_delim(
  file = paste0(data_path,"Chikungunya_01012023_30062025.csv"),
  delim = ";",
  locale = locale(
    decimal_mark = ",",
    grouping_mark = ".",
    encoding = "ISO-8859-1"
  ),
  show_col_types = FALSE
)
# print(vroom::problems(chik),n = 200)

# Import Zika Oropouche data ----
# guess_encoding(paste0(data_path,"Zika_Oropouche_01012023_30062025.csv"))
zik <- readr::read_delim(
  file = paste0(data_path,"Zika_Oropouche_01012023_30062025.csv"),
  delim = ";",
  locale = locale(
    decimal_mark = ",",
    grouping_mark = ".",
    encoding = "ISO-8859-1"
  ),
  show_col_types = FALSE
)
# vroom::problems(zik)

# Main ID to link all record is CARTAO_SUS

# Import GAL data ----
# guess_encoding(paste0(data_path,"Zika_Oropouche_01012023_30062025.csv"))
gal_path <- paste0(data_path,"BANCO DE DADOS GAL/")

gal_files <- list.files(
  path = gal_path,
  pattern = "\\.csv$",
  full.names = TRUE,
  recursive = TRUE,
  include.dirs = FALSE
)

## Dengue GAL files ----
den_gal_files <- gal_files[grep("DENGUE", gal_files)]

den_gal <-
  den_gal_files %>%
  purrr::set_names() %>%
  map(
    ~read_delim(
      file = .x,
      delim = ";",
      escape_double = FALSE,
      trim_ws = TRUE,
      col_types = cols(.default = "c"),
      locale = locale(
        decimal_mark = ",",
        grouping_mark = ".",
        encoding = "ISO-8859-1"
      ),
      show_col_types = FALSE
    )) %>%
  list_rbind(names_to = "source_file") %>%
  type_convert(locale = locale(decimal_mark = ",", grouping_mark = ".")) %>%
  mutate(source_file = basename(source_file)) %>%
  suppressMessages()

# glimpse(den_gal)

### Colunas de interesse
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`

# table(den_gal$source_file)

# prop.table(table(den_gal$`1� Campo Resultado`))
# table(den_gal$`Descri��o Finalidade`)
# table(den_gal$`Nome da Pesquisa`)
# table(den_gal$Metodologia)
# table(den_gal$Kit)
# table(den_gal$Fabricante)

## Chikungunya GAL files ----
chik_gal_files <- gal_files[grep("CHIKUNGUNYA", gal_files)]

chik_gal <-
  chik_gal_files %>%
  purrr::set_names() %>%
  map(
    ~read_delim(
      file = .x,
      delim = ";",
      escape_double = FALSE,
      trim_ws = TRUE,
      col_types = cols(.default = "c"),
      locale = locale(
        decimal_mark = ",",
        grouping_mark = ".",
        encoding = "ISO-8859-1"
      ),
      show_col_types = FALSE
    )) %>%
  list_rbind(names_to = "source_file") %>%
  type_convert(locale = locale(decimal_mark = ",", grouping_mark = ".")) %>%
  mutate(source_file = basename(source_file)) %>%
  suppressMessages()

# glimpse(chik_gal)

### Colunas de interesse
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`

# table(chik_gal$source_file)
# prop.table(table(chik_gal$`1� Campo Resultado`))
# table(chik_gal$`Descri��o Finalidade`)
# table(chik_gal$`Nome da Pesquisa`)
# table(chik_gal$Metodologia)
# table(chik_gal$Kit)
# table(chik_gal$Fabricante)

## Zika GAL files ----
zika_gal_files <- gal_files[grep("ZIKA", gal_files)]

zika_gal <-
  zika_gal_files %>%
  purrr::set_names() %>%
  map(
    ~read_delim(
      file = .x,
      delim = ";",
      escape_double = FALSE,
      trim_ws = TRUE,
      col_types = cols(.default = "c"),
      locale = locale(
        decimal_mark = ",",
        grouping_mark = ".",
        encoding = "ISO-8859-1"
      ),
      show_col_types = FALSE
    )) %>%
  list_rbind(names_to = "source_file") %>%
  type_convert(locale = locale(decimal_mark = ",", grouping_mark = ".")) %>%
  mutate(source_file = basename(source_file)) %>%
  suppressMessages()

# glimpse(chik_gal)

### Colunas de interesse
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`

# table(zika_gal$source_file)
# prop.table(table(zika_gal$`1� Campo Resultado`))
# table(zika_gal$`Descri��o Finalidade`)
# table(zika_gal$`Nome da Pesquisa`)
# table(zika_gal$Metodologia)
# table(zika_gal$Kit)
# table(zika_gal$Fabricante)

## Oropouche GAL files ----
oro_gal_files <- gal_files[grep("OROPOUCHE", gal_files)]

oro_gal <-
  oro_gal_files %>%
  purrr::set_names() %>%
  map(
    ~read_delim(
      file = .x,
      delim = ";",
      escape_double = FALSE,
      trim_ws = TRUE,
      col_types = cols(.default = "c"),
      locale = locale(
        decimal_mark = ",",
        grouping_mark = ".",
        encoding = "ISO-8859-1"
      ),
      show_col_types = FALSE
    )) %>%
  list_rbind(names_to = "source_file") %>%
  type_convert(locale = locale(decimal_mark = ",", grouping_mark = ".")) %>%
  mutate(source_file = basename(source_file)) %>%
  suppressMessages()

# glimpse(oro_gal)

### Colunas de interesse
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`

# table(oro_gal$source_file)
# prop.table(table(oro_gal$`1� Campo Resultado`))
# table(oro_gal$`Descri��o Finalidade`)
# table(oro_gal$`Nome da Pesquisa`)
# table(oro_gal$Metodologia)
# table(oro_gal$Kit)
# table(oro_gal$Fabricante)
# grep("Data", names(oro_gal), value = TRUE)

# if(exists("den")) {
#   message(">>> Sucesso: Objeto 'den' localizado. Salvando...")
#   # Salva apenas o objeto den (e outros que voc� queira, ex: chik, zik)
#   save(den, file = paste0(data_path, "Signs_symptoms_", Sys.Date(), ".RData"))
# } else {
#   stop(">>> ERRO CR�TICO: O objeto 'den' n�o existe ao final do Script 1!")
# }

rm(gal_path, gal_files, den_gal_files, chik_gal_files, zika_gal_files, oro_gal_files)

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))
