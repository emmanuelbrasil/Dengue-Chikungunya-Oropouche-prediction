suppressMessages(library(tidyverse))
suppressMessages(library(tsibble))
suppressMessages(library(patchwork))

load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# table(is.na(den_gal$`Data da Coleta`))

# Dengue ----
ts_den_gal <-
  den_gal %>%
  mutate(MES_COLETA = yearmonth(`Data da Coleta`, week_start = 7),
         DENGUE = if_else(GAL_DEN_RTPCR_RESULT == "Positive", 1, 0)) %>%
  select(MES_COLETA, DENGUE) %>%
  group_by(MES_COLETA) %>%
  summarize(
    Requested = n(),
    Positive = sum(DENGUE)) %>%
  ungroup() %>%
  tsibble(index = MES_COLETA) %>%
  fill_gaps("Requested" = 0,
            "Positive" = 0,
            .full = TRUE) %>%
  mutate(`Dengue positive` = round((Positive / Requested) * 100, 1))

ts_den_gal_plot <-
  ggplot(ts_den_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Requested"),
                fill = "Requested"),
            alpha = .25) +
  geom_area(aes(y = get("Positive"),
                fill = "Positive"),
            alpha = .40) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Central laboratory samples for Dengue")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                   date_breaks = "4 month") # date_labels = "%W\n%Y"

# png(paste0(result_path,"Time_series_GAL_Dengue_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_den_gal_plot)
# dev.off()

ts_den_gal_percent_plot <-
  ggplot(ts_den_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Dengue positive")),
            alpha = .45,
            fill = "lightgreen") +
  geom_hline(yintercept = 10,
             linetype = "dashed",
             color = "red",
             linewidth = 0.8) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Posititvity for Dengue testing (%)")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                    date_breaks = "4 month") # date_labels = "%W\n%Y"


# png(paste0(result_path,"Time_series_GAL_Dengue_positivity_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_den_gal_percent_plot)
# dev.off()

ts_den_gal_comb_plot <- ts_den_gal_plot / ts_den_gal_percent_plot

# 5. Salvar o resultado final
png(paste0(result_path, "Combined_dengue_GAL_plots_", Sys.Date(), ".png"),
    width = 480*8, height = 480*8, res = 72 * 8) # Aumentei o height para caber os dois
print(ts_den_gal_comb_plot)
dev.off()

# Chikungunya ----
ts_chik_gal <-
  chik_gal %>%
  mutate(MES_COLETA = yearmonth(`Data da Coleta`, week_start = 7),
         CHIKUNGUNYA = if_else(GAL_CHIK_RTPCR_RESULT == "Positive", 1, 0)) %>%
  select(MES_COLETA, CHIKUNGUNYA) %>%
  group_by(MES_COLETA) %>%
  summarize(
    Requested = n(),
    Positive = sum(CHIKUNGUNYA)) %>%
  ungroup() %>%
  tsibble(index = MES_COLETA) %>%
  fill_gaps("Requested" = 0,
            "Positive" = 0,
            .full = TRUE) %>%
  mutate(`Chikungunya positive` = round((Positive / Requested) * 100, 1))

ts_chik_gal_plot <-
  ggplot(ts_chik_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Requested"),
                fill = "Requested"),
            alpha = .25) +
  geom_area(aes(y = get("Positive"),
                fill = "Positive"),
            alpha = .40) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Central laboratory samples for Chikungunya")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                    date_breaks = "4 month") # date_labels = "%W\n%Y"

# png(paste0(result_path,"Time_series_GAL_Chikungunya_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_chik_gal_plot)
# dev.off()

ts_chik_gal_percent_plot <-
  ggplot(ts_chik_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Chikungunya positive")),
            alpha = .45,
            fill = "lightgreen") +
  geom_hline(yintercept = 10,
             linetype = "dashed",
             color = "red",
             linewidth = 0.8) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Posititvity for Chikungunya testing (%)")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                    date_breaks = "4 month") # date_labels = "%W\n%Y"


# png(paste0(result_path,"Time_series_GAL_Chikungunya_positivity_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_chik_gal_percent_plot)
# dev.off()

ts_chik_gal_comb_plot <- ts_chik_gal_plot / ts_chik_gal_percent_plot

# 5. Salvar o resultado final
png(paste0(result_path, "Combined_chikungunya_GAL_plots_", Sys.Date(), ".png"),
    width = 480*8, height = 480*8, res = 72 * 8) # Aumentei o height para caber os dois
print(ts_chik_gal_comb_plot)
dev.off()

# Oropouche ----
ts_oro_gal <-
  oro_gal %>%
  mutate(MES_COLETA = yearmonth(`Data da Coleta`, week_start = 7),
         OROPOUCHE = if_else(GAL_ORO_RTPCR_RESULT == "Positive", 1, 0)) %>%
  select(MES_COLETA, OROPOUCHE) %>%
  group_by(MES_COLETA) %>%
  summarize(
    Requested = n(),
    Positive = sum(OROPOUCHE)) %>%
  ungroup() %>%
  tsibble(index = MES_COLETA) %>%
  fill_gaps("Requested" = 0,
            "Positive" = 0,
            .full = TRUE) %>%
  mutate(`Oropouche positive` = round((Positive / Requested) * 100, 1))

ts_oro_gal_plot <-
  ggplot(ts_oro_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Requested"),
                fill = "Requested"),
            alpha = .25) +
  geom_area(aes(y = get("Positive"),
                fill = "Positive"),
            alpha = .40) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Central laboratory samples for Oropouche")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                    date_breaks = "4 month") # date_labels = "%W\n%Y"

# png(paste0(result_path,"Time_series_GAL_Oropouche_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_oro_gal_plot)
# dev.off()

ts_oro_gal_percent_plot <-
  ggplot(ts_oro_gal, aes(x = MES_COLETA)) +
  geom_area(aes(y = get("Oropouche positive")),
            alpha = .45,
            fill = "lightgreen") +
  geom_hline(yintercept = 10,
             linetype = "dashed",
             color = "red",
             linewidth = 0.8) +
  xlab("Epidemiological month calendar") +
  ylab(paste0("Posititvity for Oropouche testing (%)")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearmonth(date_minor_breaks = "1 month",
                    date_breaks = "4 month") # date_labels = "%W\n%Y"


# png(paste0(result_path,"Time_series_GAL_Oropouche_positivity_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
# print(ts_oro_gal_percent_plot)
# dev.off()

ts_oro_gal_comb_plot <- ts_oro_gal_plot / ts_oro_gal_percent_plot

# 5. Salvar o resultado final
png(paste0(result_path, "Combined_Oropouche_GAL_plots_", Sys.Date(), ".png"),
    width = 480*8, height = 480*8, res = 72 * 8)
print(ts_oro_gal_comb_plot)
dev.off()

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"GAL_time_series_plots_",Sys.Date(),".RData"))