suppressMessages(library(tidyverse))
suppressMessages(library(tsibble))

load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Zika ----

# Edit ----
zik <-
  zik %>%
  rename(MORADOR_RUA = MOARADOR_RUA) %>%
  mutate(
    O_DATASET = "Zika",
    DATA_NOTIFICACAO = dmy(DATA_NOTIFICACAO),
    SEMANA_NOTIFICACAO = yearweek(DATA_NOTIFICACAO,
                                   week_start = 7),
    DATA_DIAGNOSTICO = dmy(DATA_DIAGNOSTICO),
    SEMANA_DIAGNOSTICO = yearweek(DATA_DIAGNOSTICO,
                                   week_start = 7),
    CNS_valid = is_cns(CARTAO_SUS),
    IDADE_CAT = cut(IDADE_ANOS_DT_NOTIFIC,
                    include.lowest = TRUE,
                    breaks = c(0,1,12,18,25,35,45,55,65,75,85,95)),
    SEXO = factor(SEXO,
                  levels = c("F","M","I"),
                  labels = c("Female", "Male","Ignored")),
    GESTANTE = factor(GESTANTE,
                      levels = c(
                        "1 -1� trimestre",
                        "2 -2� trimestre",
                        "3 -3� trimestre",
                        "4 -Idade gestacional ignorada",
                        "5 -N�o",
                        "6 -N�o se aplica",
                        "9 -Ignorado"),
                      labels = c(
                        "1st trimester",
                        "2nd trimester",
                        "3rd trimester",
                        "Gestational age unknown",
                        "No",
                        "Not applicable",
                        "Ignored/Unknown")),
    RACA_COR = factor(RACA_COR,
                      levels = c(
                        "1 -Branca", "2 -Preta", "3 -Amarela", "4 -Parda",
                        "5 -Indigena", "9 -Ignorado"),
                      labels = c(
                        "White", "Black", "Yellow", "Brown",
                        "Indigenous", "Ignored/Unknown")),
    ETNIA = factor(ETNIA,
                   levels = c("1 -Tupiniquim", "2 -Guarani", "9 -Ignorado"),
                   labels = c("Tupiniquim", "Guarani", "Ignored/Unknown")),
    PCD = factor(PCD,
                 levels = c("1 -Sim", "2 -N�o"),
                 labels = c("Yes", "No")),
    MORADOR_RUA = factor(MORADOR_RUA,
                         levels = c("1 -Sim", "2 -N�o"),
                         labels = c("Yes", "No")),
    ESCOLARIDADE = factor(ESCOLARIDADE,
                          levels = c(
                            "0 -Analfabeto",
                            "1 -1� a 4� s�rie incompleta do EF (antigo prim�rio ou 1� grau)",
                            "2 -4� s�rie completa do EF (antigo prim�rio ou 1� grau)",
                            "3 -5� � 8� s�rie incompleta do EF (antigo gin�sio ou 1� grau)",
                            "4 -Ensino fundamental completo (antigo gin�sio ou 1� grau) ",
                            "5 -Ensino m�dio incompleto (antigo colegial ou 2� grau )",
                            "6 -Ensino m�dio completo (antigo colegial ou 2� grau ) ",
                            "7 -Educa��o superior incompleta ",
                            "8 -Educa��o superior completa",
                            "9 -Ignorado",
                            "10 -N�o se aplica"),
                          labels = c(
                            "Illiterate",
                            "Elementary School Incomplete",
                            "Elementary School Complete",
                            "Middle School Incomplete",
                            "Middle School Complete",
                            "High School Incomplete",
                            "High School Complete",
                            "Higher Education Incomplete",
                            "Higher Education Complete",
                            "Ignored/Unknown",
                            "Not applicable")),
    ZONA = factor(ZONA,
                  levels = c("1 -Urbana","2 -Rural","3 -Periurbana","9 -Ignorado"),
                  labels = c("Urban","Rural","Peri-urban","Unknown")),
    CLASSIF_FINAL = factor(CLASSIF_FINAL,
                         levels = c("1 -Confirmado", "2 -Descartado"),
                         labels = c("Confirmed",
                                    "Discarded")),
    C_CLASSIFIC = case_when(
      DESCRICAO == "Oropouche" & CLASSIF_FINAL == "Confirmed" ~ "Oropouche",
      DESCRICAO == "Zika v�rus - Casos agudos" & CLASSIF_FINAL == "Confirmed" ~ "Zika",
      CLASSIF_FINAL == "Discarded" ~ "Discarded",
      .ptype = factor(levels = c("Discarded","Zika","Oropouche"))),
    ZIKA = if_else(C_CLASSIFIC == "Zika", "Yes", "No"),
    OROPOUCHE = if_else(C_CLASSIFIC == "Oropouche", "Yes", "No"),
    CRIT_CONF_DESC = factor(CRIT_CONF_DESC,
                              levels = c("1 -Laboratorial","2 -Clinico-Epidemiologico"),
                              labels = c("Laboratory","Clinical-epideiological")),
    AUTOCTONE = factor(AUTOCTONE,
                         levels = c("2 -N�o","1 -Sim","3 -Inderteminado"),
                         labels = c("No","Yes","Unknown")),
    EVOLUC_CASO = factor(EVOLUC_CASO,
                           levels = c("1 -Cura",
                                      "2 -�bito pelo agravo notificado",
                                      "3 -�bito por outras causas",
                                      "9 -Ignorado"),
                           labels = c("Recovered",
                                      "Death (arbovirus)",
                                      "Death (other causes)",
                                      "Ignored")))

# table(zik$OROPOUCHE, useNA = "always")
# table(zik$OROPOUCHE, zik$C_CLASSIFIC, useNA = "always")
# table(zik$ZIKA, zik$C_CLASSIFIC, useNA = "always")
# table(zik$OROPOUCHE, zik$ZIKA, useNA = "always")

# Smaller dataset to test analysis ----
# zik_minor <-
#   zik %>%
#   slice_sample(n = 1000)

# GAL Zika data ----
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`
zika_gal <-
  zika_gal %>%
  select(`N�m. Notifica��o Sinan`,
         `Data Notifica��o Sinan`,
         `CNS do Paciente`,
         Paciente,
         `Data de Nascimento`,
         `Nome da M�e`,
         `Descri��o Finalidade`,
         `Data da Solicita��o`,
         `Data da Coleta`,
         `Nome da Pesquisa`,
         Metodologia,
         Kit,
         Fabricante,
         `1� Campo Resultado`) %>%
  mutate(NUM_NOTIFICACAO = as.numeric(str_replace_all(`N�m. Notifica��o Sinan`, "[^0-9]", "")),
         DATA_NOTIFICACAO = `Data Notifica��o Sinan`,
         CARTAO_SUS = as.numeric(str_replace_all(`CNS do Paciente`, "[^0-9]", "")),
         CNS_valid = is_cns(CARTAO_SUS),
         `Data da Solicita��o` = dmy(`Data da Solicita��o`),
         `Data da Coleta` = dmy(`Data da Coleta`),
         GAL_ZIKA_RTPCR_RESULT = factor(`1� Campo Resultado`,
                                        levels = c("Resultado: N�o Detect�vel",
                                                   "Resultado: Detect�vel"),
                                        labels = c("Negative",
                                                   "Positive"))
  ) %>%
  select(-`N�m. Notifica��o Sinan`,
         -`Data Notifica��o Sinan`,
         -`CNS do Paciente`,
         -`1� Campo Resultado`)


# table(zika_gal$`1� Campo Resultado`)
# table(zika_gal$Metodologia)
# table(zika_gal$GAL_ZIKA_RTPCR_RESULT)

# GAL Oropouche data ----
### `N�m. Notifica��o Sinan`
### `Data Notifica��o Sinan`
### `CNS do Paciente`
### `Descri��o Finalidade`
### Data da Solicita��o
### `Data da Coleta`
### `Nome da Pesquisa`
### Metodologia
### Kit
### Fabricante
### `1� Campo Resultado`
oro_gal <-
  oro_gal %>%
  select(`N�m. Notifica��o Sinan`,
         `Data Notifica��o Sinan`,
         `CNS do Paciente`,
         Paciente,
         `Data de Nascimento`,
         `Nome da M�e`,
         `Descri��o Finalidade`,
         `Data da Solicita��o`,
         `Data da Coleta`,
         `Nome da Pesquisa`,
         Metodologia,
         Kit,
         Fabricante,
         `1� Campo Resultado`) %>%
  mutate(NUM_NOTIFICACAO = as.numeric(str_replace_all(`N�m. Notifica��o Sinan`, "[^0-9]", "")),
         DATA_NOTIFICACAO = `Data Notifica��o Sinan`,
         CARTAO_SUS = as.numeric(str_replace_all(`CNS do Paciente`, "[^0-9]", "")),
         CNS_valid = is_cns(CARTAO_SUS),
         `Data da Solicita��o` = dmy(`Data da Solicita��o`),
         `Data da Coleta` = dmy(`Data da Coleta`),
         GAL_ORO_RTPCR_RESULT = factor(`1� Campo Resultado`,
                                        levels = c("Resultado: N�o Detect�vel",
                                                   "Resultado: Detect�vel"),
                                        labels = c("Negative",
                                                   "Positive"))
  ) %>%
  select(-`N�m. Notifica��o Sinan`,
         -`Data Notifica��o Sinan`,
         -`CNS do Paciente`,
         -`1� Campo Resultado`)


# table(oro_gal$`4� Campo Resultado`)
# table(oro_gal$`3� Campo Resultado`)
# table(oro_gal$`2� Campo Resultado`)
# table(oro_gal$`1� Campo Resultado`)
# table(oro_gal$GAL_CHIK_RTPCR_RESULT)
# table(oro_gal$Metodologia)


while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))
