# file.copy(from = "C:/Users/emman/OneDrive/Oropouche/Analise/",
#           to = "D:/Banco/Oropouche/",
#           overwrite = TRUE,
#           recursive = TRUE,
#           copy.mode = TRUE,
#           copy.date = TRUE)

# detaching allpackages, clearing grpah windows and enviroment
while(search()[2] != "tools:rstudio") detach(2)
rm(list = ls())
graphics.off()

# setting default paths
script_path <- "~/Projetos/Oropouche/scripts/"
data_path <- "~/Projetos/Oropouche/dados/"
result_path <- "~/Projetos/Oropouche/resultados/"

# script_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/scripts/"
# data_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/dados/"
# result_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/resultados/"

# script_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/scripts/"
# data_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/dados/"
# result_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/resultados/"

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Call import datasets
source(paste0(script_path,"1_Import.R"), encoding = "ISO-8859-1")

# Call Edit Dengue Dataset
source(paste0(script_path,"2_Edit_Den.R"), encoding = "ISO-8859-1")

# Call Edit Chik Dataset
source(paste0(script_path,"3_Edit_Chik.R"), encoding = "ISO-8859-1")

# Call Edit Zika Dataset
source(paste0(script_path,"4_Edit_Zik.R"), encoding = "ISO-8859-1")

# Call Edit Time series GAL tests
source(paste0(script_path,"5_GAL_time_series_plots.R"), encoding = "ISO-8859-1")

# Call Set labels
source(paste0(script_path,"6_Labels.R"), encoding = "ISO-8859-1")

# Call crude tables
source(paste0(script_path,"7_Tables.R"), encoding = "ISO-8859-1")

# Call Flowdiagram
source(paste0(script_path,"8_Fluxogram_replicates_join.R"), encoding = "ISO-8859-1")

# Call final dataset edit
source(paste0(script_path,"9_Edit_final.R"), encoding = "ISO-8859-1")

# Call labels for final dataset
source(paste0(script_path,"10_Labels_final.R"), encoding = "ISO-8859-1")

# Call time series of confirmed cases on final dataset
source(paste0(script_path,"11_Time_series_plots.R"), encoding = "ISO-8859-1")

# Call tables on final
source(paste0(script_path,"12_Tables2.R"), encoding = "ISO-8859-1")

# Call missing diagnosis and imputations on final dataset
source(paste0(script_path,"13_Imputations.R"), encoding = "ISO-8859-1")

# Call RF models for Oropouche
source(paste0(script_path,"15_RF_reg_Oropouche.R"), encoding = "ISO-8859-1")

# Call RF models for Cikungunya
source(paste0(script_path,"17_RF_reg_Chikungunya.R"), encoding = "ISO-8859-1")

# Call RF models for Dengue
source(paste0(script_path,"19_RF_reg_Dengue.R"), encoding = "ISO-8859-1")

# Call RF models for Zika
source(paste0(script_path,"20_RF_reg_Zika.R"), encoding = "ISO-8859-1")

# Call additional analysis
source(paste0(script_path,"21_Additional.R"), encoding = "ISO-8859-1")
