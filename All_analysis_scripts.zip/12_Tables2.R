suppressMessages(library(tidyverse))
suppressMessages(library(flextable))
# suppressMessages(library(table1, lib.loc = .libPaths()[1]))
suppressMessages(library(table1, lib.loc = "/usr/local/lib/R/site-library"))

load(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Dengue ----
Table_Dengue <-
  table1(~ IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           # DL_IGM_DENGUE_RESULT +
           # DL_NS1_RESULTADO +
           # DL_I_RESULT +
           # DL_RTPCR_RESULT +
           # DL_RTPCR_SOROTIPO +
           # DL_HISTOPATOLOGIA +
           # DL_IMUNOHISTOQUIMICA +
           C_CRIT_CONF_DESC +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO +
           AG_HIPOTENSAO +
           AG_PLAQUETAS +
           AG_VOMITOS_PERSISTENTES +
           AG_DOR_ABDOMINAL +
           AG_LETARGIA_IRR +
           AG_SANG_MUCOSA +
           AG_HEMATOCRITO +
           AG_HEPATOMEGALIA +
           AG_ACUMULO_LIQUIDOS +
           AG_PULSO +
           AG_PA_CONVERGENTE +
           AG_TEMPO_CAPILAR +
           AG_AC_LIQUIDOS +
           AG_TAQUICARDIA +
           AG_EXTREMIDADES_FRIAS +
           AG_HIPOTENSAO_ARTERIAL +
           AG_HEMATEMESE +
           AG_MELENA +
           AG_METRORAGIA_VOLUMOSA +
           AG_SANGRAMENTO_SNC +
           AG_AST_ALT +
           AG_MIOCARDITE +
           AG_ALTER_CONSCIENCIA +
           AG_OUTROS_ORGAOS | VALIDATION_3 * DENGUE,
         data = a,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by Dengue diagnostic investigation outcome in each dataset split.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation; CNS = central nervous system; AST = aspartate aminotransferase; ALT = alanine aminotransferase; RT-PCR = reverse transcription polymerase chain reaction.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_Dengue

# bm_render_cat(a$SEXO)

save_as_docx(
  values = list(Table_Dengue) ,
  path = paste0(result_path,"Table_Dengue_final_data_",Sys.Date(),".docx"),
)

# Dengue severe columns ----
Table_Dengue_severity <-
  table1(~ IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           # DL_IGM_DENGUE_RESULT +
           # DL_NS1_RESULTADO +
           # DL_I_RESULT +
           # DL_RTPCR_RESULT +
           # DL_RTPCR_SOROTIPO +
           # DL_HISTOPATOLOGIA +
           # DL_IMUNOHISTOQUIMICA +
           C_CRIT_CONF_DESC +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO +
           AG_HIPOTENSAO +
           AG_PLAQUETAS +
           AG_VOMITOS_PERSISTENTES +
           AG_DOR_ABDOMINAL +
           AG_LETARGIA_IRR +
           AG_SANG_MUCOSA +
           AG_HEMATOCRITO +
           AG_HEPATOMEGALIA +
           AG_ACUMULO_LIQUIDOS +
           AG_PULSO +
           AG_PA_CONVERGENTE +
           AG_TEMPO_CAPILAR +
           AG_AC_LIQUIDOS +
           AG_TAQUICARDIA +
           AG_EXTREMIDADES_FRIAS +
           AG_HIPOTENSAO_ARTERIAL +
           AG_HEMATEMESE +
           AG_MELENA +
           AG_METRORAGIA_VOLUMOSA +
           AG_SANGRAMENTO_SNC +
           AG_AST_ALT +
           AG_MIOCARDITE +
           AG_ALTER_CONSCIENCIA +
           AG_OUTROS_ORGAOS | DENGUE_SEVERITY,
         data = a,
         # groups = list("", "Dengue", ""),
         # groupspan = c(1, 3, 1),
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by Dengue severity diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation; CNS = central nervous system; AST = aspartate aminotransferase; ALT = alanine aminotransferase; RT-PCR = reverse transcription polymerase chain reaction.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_Dengue_severity

save_as_docx(
  values = list(Table_Dengue_severity) ,
  path = paste0(result_path,"Table_Dengue_severity_final_data_",Sys.Date(),".docx"),
)


# Chikungunya ----
Table_Chikungunya <-
  table1(~ IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           # DL_S1 +
           # DL_S2 +
           # DL_PRNT +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO +
           C_APRESENTACAO_CLINICA| VALIDATION_3 * CHIKUNGUNYA,
         data = a,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by Chikungunya diagnostic investigation outcome in each dataset split.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_Chikungunya

save_as_docx(
  values = list(Table_Chikungunya) ,
  path = paste0(result_path,"Table_Chikungunya_final_data_",Sys.Date(),".docx"),
)

# Zika ----
Table_Zika <-
  table1(~ IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO|  VALIDATION_3* ZIKA,
         data = a,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by Zika diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation in each dataset split.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_Zika

save_as_docx(
  values = list(Table_Zika) ,
  path = paste0(result_path,"Table_Zika_final_data_",Sys.Date(),".docx"),
)

# Oropouche ----
Table_Oropouche <-
  table1(~ IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO| VALIDATION_3 * OROPOUCHE,
         data = a,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by Oropouche diagnostic investigation outcome in each dataset split.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_Oropouche

save_as_docx(
  values = list(Table_Oropouche) ,
  path = paste0(result_path,"Table_Oropouche_final_data_",Sys.Date(),".docx"),
)


# Arboviruses ----

strata <- c(
  list("Discarded" = a %>% filter(DENGUE == "No" &
                                  CHIKUNGUNYA == "No" &
                                  ZIKA == "No" &
                                  OROPOUCHE == "No")),
  list("Dengue" = a %>% filter(DENGUE == "Yes")),
  list("Chikungunya" = a %>% filter(CHIKUNGUNYA == "Yes")),
  list("Zika" = a %>% filter(ZIKA == "Yes")),
  list("Oropouche" = a %>% filter(OROPOUCHE == "Yes")))
labels <- list(
  variables = list(IDADE_ANOS_DT_NOTIFIC = "Age at notification",
                   IDADE_CAT = "Age at notification",
                   SEXO = "Sex at notification",
                   GESTANTE = "Pregnancy",
                   RACA_COR = "Race or skin color",
                   ETNIA = "Indigenous etnicity",
                   PCD = "Person with special needs",
                   MORADOR_RUA = "Homeless",
                   ESCOLARIDADE = "Education",
                   ZONA = "Home address",
                   DC_FEBRE = "Fever",
                   DC_CEFALEIA = "Headache",
                   DC_VOMITO = "Vomiting",
                   DC_DOR_COSTAS = "Back pain",
                   DC_ARTRITE = "Arthritis",
                   DC_PETEQUIAS = "Petechiae",
                   DC_PROVA_LACO = "Tourniquet test",
                   DC_MIALGIA = "Myalgia",
                   DC_EXANTEMA = "Rash",
                   DC_NAUSEAS = "Nausea",
                   DC_CONJUTIVITE = "Conjunctivitis",
                   DC_ARTRALGIA_INTENSA = "Intense arthralgia",
                   DC_LEUCOPENIA = "Leukopenia",
                   DC_DOR_RETROORBITAL = "Retro-orbital pain",
                   DC_DIABETES = "Diabetes",
                   DC_HEPATOPATIAS = "Hepatopathies",
                   DC_HIPER_ARTERIAL = "Arterial hypertension",
                   DC_AUTO_IMUNES = "Autoimmune diseases",
                   DC_HEMATOLOGICAS = "Hematological diseases",
                   DC_RENAL_CRONICA = "Chronic kidney disease",
                   DC_ACIDO_PEPTICA = "Peptic acid disease",
                   H_HOSPITALIZACAO = "Hospitalization"))

Table_all <-
  table1(strata, labels,
         # overall = FALSE,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Final dataset variables (including epidemiological, clinical at presentations) counts and frequencies by all arboviruses diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# Table_all

save_as_docx(
  values = list(Table_all) ,
  path = paste0(result_path,"Table_all_final_data_",Sys.Date(),".docx"),
)

rm(strata, labels)

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))

# rm(Table_all, Table_Chikungunya, Table_Dengue, Table_Dengue_severity, Table_Oropouche, Table_Zika)
