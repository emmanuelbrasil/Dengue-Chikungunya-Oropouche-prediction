suppressMessages(library(tidyverse))
suppressMessages(library(tsibble))

load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Keeping just the final dataset and paths
rm(list = setdiff(ls(), c("a", ls()[str_detect(ls(), "_path")])))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# save.image(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))
# load(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))

# table(a$CO_INFECCAO, a$DC_FEBRE, useNA = "always")
# It looks like 764 lines from the Zika Oropouche dataset did not match
# neither in the Chik nor Dengue dataset
# Discarded 334; Oropouche 385; Zika  45; Total 764

a <- a %>%
# a_min <- a %>%
#   slice_sample(n = 3000) %>%
  rename(
    CARTAO_SUS = CARTAO_SUS.DEN,
    DL_RTPCR_RESULT = DL_RTPCR_RESULT.DEN,
    DL_RTPCR_SOROTIPO = DL_RTPCR_SOROTIPO.DEN,
    AG_HIPOTENSAO = AG_HIPOTENSAO.DEN,
    AG_PLAQUETAS = AG_PLAQUETAS.DEN,
    AG_VOMITOS_PERSISTENTES = AG_VOMITOS_PERSISTENTES.DEN,
    AG_DOR_ABDOMINAL = AG_DOR_ABDOMINAL.DEN,
    AG_LETARGIA_IRR = AG_LETARGIA_IRR.DEN,
    AG_SANG_MUCOSA = AG_SANG_MUCOSA.DEN,
    AG_HEMATOCRITO = AG_HEMATOCRITO.DEN,
    AG_HEPATOMEGALIA = AG_HEPATOMEGALIA.DEN,
    AG_ACUMULO_LIQUIDOS = AG_ACUMULO_LIQUIDOS.DEN,
    AG_PULSO = AG_PULSO.DEN,
    AG_PA_CONVERGENTE = AG_PA_CONVERGENTE.DEN,
    AG_TEMPO_CAPILAR = AG_TEMPO_CAPILAR.DEN,
    AG_AC_LIQUIDOS = AG_AC_LIQUIDOS.DEN,
    AG_TAQUICARDIA = AG_TAQUICARDIA.DEN,
    AG_EXTREMIDADES_FRIAS = AG_EXTREMIDADES_FRIAS.DEN,
    AG_HIPOTENSAO_ARTERIAL = AG_HIPOTENSAO_ARTERIAL.DEN,
    AG_HEMATEMESE = AG_HEMATEMESE.DEN,
    AG_MELENA = AG_MELENA.DEN,
    AG_METRORAGIA_VOLUMOSA = AG_METRORAGIA_VOLUMOSA.DEN,
    AG_SANGRAMENTO_SNC = AG_SANGRAMENTO_SNC.DEN,
    AG_AST_ALT = AG_AST_ALT.DEN,
    AG_MIOCARDITE = AG_MIOCARDITE.DEN,
    AG_ALTER_CONSCIENCIA = AG_ALTER_CONSCIENCIA.DEN,
    AG_OUTROS_ORGAOS = AG_OUTROS_ORGAOS.DEN,
    ) %>%
  mutate(O_DATASET = case_when(
           is.na(O_DATASET) ~ O_DATASET.CHIK,
           is.na(O_DATASET) ~ O_DATASET.ZIK,
           .default = O_DATASET),
         DC_FEBRE = if_else(is.na(DC_FEBRE.DEN), DC_FEBRE.CZO, DC_FEBRE.DEN),
         DC_CEFALEIA = if_else(is.na(DC_CEFALEIA.DEN), DC_CEFALEIA.CZO, DC_CEFALEIA.DEN),
         DC_VOMITO = if_else(is.na(DC_VOMITO.DEN), DC_VOMITO.CZO, DC_VOMITO.DEN),
         DC_DOR_COSTAS = if_else(is.na(DC_DOR_COSTAS.DEN), DC_DOR_COSTAS.CZO, DC_DOR_COSTAS.DEN),
         DC_ARTRITE = if_else(is.na(DC_ARTRITE.DEN), DC_ARTRITE.CZO, DC_ARTRITE.DEN),
         DC_PETEQUIAS = if_else(is.na(DC_PETEQUIAS.DEN), DC_PETEQUIAS.CZO, DC_PETEQUIAS.DEN),
         DC_PROVA_LACO = if_else(is.na(DC_PROVA_LACO.DEN), DC_PROVA_LACO.CZO, DC_PROVA_LACO.DEN),
         DC_MIALGIA = if_else(is.na(DC_MIALGIA.DEN), DC_MIALGIA.CZO, DC_MIALGIA.DEN),
         DC_EXANTEMA = if_else(is.na(DC_EXANTEMA.DEN), DC_EXANTEMA.CZO, DC_EXANTEMA.DEN),
         DC_NAUSEAS = if_else(is.na(DC_NAUSEAS.DEN), DC_NAUSEAS.CZO, DC_NAUSEAS.DEN),
         DC_CONJUTIVITE = if_else(is.na(DC_CONJUTIVITE.DEN), DC_CONJUTIVITE.CZO, DC_CONJUTIVITE.DEN),
         DC_ARTRALGIA_INTENSA = if_else(is.na(DC_ARTRALGIA_INTENSA.DEN), DC_ARTRALGIA_INTENSA.CZO, DC_ARTRALGIA_INTENSA.DEN),
         DC_LEUCOPENIA = if_else(is.na(DC_LEUCOPENIA.DEN), DC_LEUCOPENIA.CZO, DC_LEUCOPENIA.DEN),
         DC_DOR_RETROORBITAL = if_else(is.na(DC_DOR_RETROORBITAL.DEN), DC_DOR_RETROORBITAL.CZO, DC_DOR_RETROORBITAL.DEN),

         DC_DIABETES = if_else(is.na(DC_DIABETES.DEN), DC_DIABETES.CZO, DC_DIABETES.DEN),
         DC_HEPATOPATIAS = if_else(is.na(DC_HEPATOPATIAS.DEN), DC_HEPATOPATIAS.CZO, DC_HEPATOPATIAS.DEN),
         DC_HIPER_ARTERIAL = if_else(is.na(DC_HIPER_ARTERIAL.DEN), DC_HIPER_ARTERIAL.CZO, DC_HIPER_ARTERIAL.DEN),
         DC_AUTO_IMUNES = if_else(is.na(DC_AUTO_IMUNES.DEN), DC_AUTO_IMUNES.CZO, DC_AUTO_IMUNES.DEN),
         DC_HEMATOLOGICAS = if_else(is.na(DC_HEMATOLOGICAS.DEN), DC_HEMATOLOGICAS.CZO, DC_HEMATOLOGICAS.DEN),
         DC_RENAL_CRONICA = if_else(is.na(DC_RENAL_CRONICA.DEN), DC_RENAL_CRONICA.CZO, DC_RENAL_CRONICA.DEN),
         DC_ACIDO_PEPTICA = if_else(is.na(DC_ACIDO_PEPTICA.DEN), DC_ACIDO_PEPTICA.CZO, DC_ACIDO_PEPTICA.DEN),

         DL_IGM_DENGUE_RESULT = if_else(is.na(DL_IGM_DENGUE_RESULT.DEN), DL_IGM_DENGUE_RESULT.CZO, DL_IGM_DENGUE_RESULT.DEN),
         DL_NS1_RESULTADO = if_else(is.na(DL_NS1_RESULTADO.DEN), DL_NS1_RESULTADO.CZO, DL_NS1_RESULTADO.DEN),
         DL_I_RESULT = if_else(is.na(DL_I_RESULT.DEN), DL_I_RESULT.CZO, DL_I_RESULT.DEN),
         DL_HISTOPATOLOGIA = if_else(is.na(DL_HISTOPATOLOGIA.DEN), DL_HISTOPATOLOGIA.CZO, DL_HISTOPATOLOGIA.DEN),
         DL_IMUNOHISTOQUIMICA = if_else(is.na(DL_IMUNOHISTOQUIMICA.DEN), DL_IMUNOHISTOQUIMICA.CZO, DL_IMUNOHISTOQUIMICA.DEN),

         C_CRIT_CONF_DESC = if_else(is.na(C_CRIT_CONF_DESC.DEN), C_CRIT_CONF_DESC.CZO, C_CRIT_CONF_DESC.DEN),
         C_EVOLUC_CASO = if_else(is.na(C_EVOLUC_CASO.DEN), C_EVOLUC_CASO.CZO, C_EVOLUC_CASO.DEN),
         H_HOSPITALIZACAO = if_else(is.na(H_HOSPITALIZACAO.DEN), H_HOSPITALIZACAO.CZO, H_HOSPITALIZACAO.DEN),
         C_AUTOCTONE = if_else(is.na(C_AUTOCTONE.DEN), C_AUTOCTONE.CZO, C_AUTOCTONE.DEN),
         C_APRESENTACAO_CLINICA = if_else(is.na(C_APRESENTACAO_CLINICA.DEN), C_APRESENTACAO_CLINICA.CZO, C_APRESENTACAO_CLINICA.DEN),
         C_APRESENTACAO_CLINICA = if_else(is.na(C_APRESENTACAO_CLINICA) & CHIKUNGUNYA == "No", "Acute", C_APRESENTACAO_CLINICA,
                                          ptype = factor(levels = c("Acute", "Chronic"))),
         DATA_DIAGNOSTICO = if_else(is.na(DATA_DIAGNOSTICO.DEN), DATA_DIAGNOSTICO.CZO, DATA_DIAGNOSTICO.DEN),
         SEMANA_DIAGNOSTICO = yearweek(DATA_DIAGNOSTICO, week_start = 7),
         AG_DT_INICIO_ALARMES = if_else(is.na(AG_DT_INICIO_ALARMES.DEN), AG_DT_INICIO_ALARMES.CZO, AG_DT_INICIO_ALARMES.DEN),
         SEMANA_INI_GRAVIDADE = if_else(is.na(SEMANA_INI_GRAVIDADE.DEN), SEMANA_INI_GRAVIDADE.CZO, SEMANA_INI_GRAVIDADE.DEN),
         H_DT_INTERNACAO = if_else(is.na(H_DT_INTERNACAO.DEN), H_DT_INTERNACAO.CZO, H_DT_INTERNACAO.DEN),
         SEMANA_INTERNACAO = if_else(is.na(SEMANA_INTERNACAO.DEN), SEMANA_INTERNACAO.CZO, SEMANA_INTERNACAO.DEN),
         AG_DT_INI_GRAVIDADE = if_else(is.na(AG_DT_INI_GRAVIDADE.DEN), AG_DT_INI_GRAVIDADE.CZO, AG_DT_INI_GRAVIDADE.DEN),
         DENGUE_SEVERITY = case_when(
           DENGUE == "Yes" & AG_PULSO == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_PA_CONVERGENTE == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_TEMPO_CAPILAR == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_AC_LIQUIDOS == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_TAQUICARDIA == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_EXTREMIDADES_FRIAS == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_HIPOTENSAO_ARTERIAL == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_HEMATEMESE == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_MELENA == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_METRORAGIA_VOLUMOSA == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_SANGRAMENTO_SNC == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_AST_ALT == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_MIOCARDITE == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_ALTER_CONSCIENCIA == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_OUTROS_ORGAOS == "Yes" ~ "Severe Dengue",
           DENGUE == "Yes" & AG_HIPOTENSAO == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_PLAQUETAS == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_VOMITOS_PERSISTENTES == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_DOR_ABDOMINAL == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_LETARGIA_IRR == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_SANG_MUCOSA == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_HEMATOCRITO == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_HEPATOMEGALIA == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" & AG_ACUMULO_LIQUIDOS == "Yes" ~ "Dengue with alert",
           DENGUE == "Yes" ~ "Dengue fever",
           DENGUE == "No" ~ "Not Dengue",
           .ptype = factor(levels = c("Not Dengue","Dengue fever","Dengue with alert","Severe Dengue"))
         ),
         DL_S1 = if_else(is.na(DL_S1.CZO), DL_S1.DEN, DL_S1.CZO),
         # spliting data into sets for Train and validation

         VALIDATION_1 = if_else(SEMANA_DIAGNOSTICO < yearweek("2024-W16", week_start = 7), "Train","Test",
                                ptype = factor(levels = c("Train", "Test"))),
         VALIDATION_2 = if_else(SEMANA_DIAGNOSTICO < yearweek("2025-W01", week_start = 7), "Train","Test",
                                ptype = factor(levels = c("Train", "Test"))),
        DENGUE_01 = if_else(DENGUE == "Yes", 1, 0),
        CHIKUNGUNYA_01 = if_else(CHIKUNGUNYA == "Yes", 1, 0),
        ZIKA_01 = if_else(ZIKA == "Yes", 1, 0),
        OROPOUCHE_01 = if_else(OROPOUCHE == "Yes", 1, 0),
  ) %>%
  select(CARTAO_SUS, IDADE_ANOS_DT_NOTIFIC, IDADE_CAT,
         SEXO, GESTANTE, RACA_COR, ETNIA, PCD, MORADOR_RUA, ESCOLARIDADE, ZONA,

         DC_FEBRE,                     DC_CEFALEIA,                  DC_VOMITO,
         DC_DOR_COSTAS,                DC_ARTRITE,                   DC_PETEQUIAS,                 DC_PROVA_LACO,
         DC_MIALGIA,                   DC_EXANTEMA,                  DC_NAUSEAS,                   DC_CONJUTIVITE,
         DC_ARTRALGIA_INTENSA,         DC_LEUCOPENIA,                DC_DOR_RETROORBITAL,          DC_DIABETES,
         DC_HEPATOPATIAS,              DC_HIPER_ARTERIAL,            DC_AUTO_IMUNES,               DC_HEMATOLOGICAS,
         DC_RENAL_CRONICA,             DC_ACIDO_PEPTICA,

         AG_HIPOTENSAO, AG_PLAQUETAS, AG_VOMITOS_PERSISTENTES, AG_DOR_ABDOMINAL, AG_LETARGIA_IRR,
         AG_SANG_MUCOSA, AG_HEMATOCRITO, AG_HEPATOMEGALIA, AG_ACUMULO_LIQUIDOS, AG_PULSO,
         AG_PA_CONVERGENTE, AG_TEMPO_CAPILAR, AG_AC_LIQUIDOS, AG_TAQUICARDIA, AG_EXTREMIDADES_FRIAS,
         AG_HIPOTENSAO_ARTERIAL, AG_HEMATEMESE, AG_MELENA, AG_METRORAGIA_VOLUMOSA, AG_SANGRAMENTO_SNC,
         AG_AST_ALT, AG_MIOCARDITE, AG_ALTER_CONSCIENCIA, AG_OUTROS_ORGAOS,

         SEMANA_DIAGNOSTICO, DENGUE,CHIKUNGUNYA,ZIKA,OROPOUCHE, DENGUE_01, CHIKUNGUNYA_01, ZIKA_01, OROPOUCHE_01,
         C_CLASSIFIC, DENGUE_LAB_DIAG, CO_INFECCAO, C_CRIT_CONF_DESC, H_HOSPITALIZACAO, C_EVOLUC_CASO,
         C_AUTOCTONE, C_APRESENTACAO_CLINICA, DENGUE_SEVERITY, VALIDATION_1, VALIDATION_2, GAL_CHIK_RTPCR_RESULT, GAL_DEN_RTPCR_RESULT, GAL_ORO_RTPCR_RESULT
  ) %>%
  mutate(
    GESTANTE = fct_collapse(
      GESTANTE,
      Yes = c("1st trimester","2nd trimester","3rd trimester","Gestational age unknown"),
      No = c("No","Not applicable")),
    GESTANTE = if_else(SEXO == "Male", "No", GESTANTE,
                       ptype = factor(levels = c("No","Yes","Ignored/Unknown"))),
    RACA_COR = fct_collapse(
      RACA_COR,
      Black = c("Black","Brown")),
    ETNIA = if_else(RACA_COR != "Indigenous", "Not applicable",ETNIA,
                    ptype = factor(levels = c("Tupiniquim","Guarani","Ignored/Unknown","Not applicable"))),
    ESCOLARIDADE = fct_collapse(
      ESCOLARIDADE,
      Illiterate = c("Illiterate","Elementary School Incomplete"),
      `Elementary School Complete`  = c("Elementary School Complete","Middle School Incomplete"),
      `Middle School Complete`  = c("Middle School Complete", "High School Incomplete"),
      `High School Complete` = c("Higher Education Incomplete", "High School Complete"),
      `Ignored/Unknown` = c("Ignored/Unknown","Not applicable")),
    SEMANA_NUM = epiweek(SEMANA_DIAGNOSTICO)
    )
set.seed(1753109393)
a$VALIDATION_3 <- factor(sample(x = c("Train","Test"),
                                size = nrow(a),
                                prob = c(2/3,1/3),
                                replace = TRUE),
                         levels = c("Train","Test"))

# class(a$ETNIA)
# table(a$ESCOLARIDADE, useNA = "always")
# table(a$SEMANA_DIAGNOSTICO < yearweek("2025-W01", week_start = 7))
# prop.table(table(a_min$DENGUE_01, a_min$VALIDATION, useNA = "always"),2)
# prop.table(table(a_min$CHIKUNGUNYA_01, a_min$VALIDATION, useNA = "always"),2)
# table(a_min$ZIKA_01, a_min$VALIDATION, useNA = "always")
# table(a_min$OROPOUCHE_01, a_min$VALIDATION, useNA = "always")

# spliting data into sets for development and validation
# according to calendat dates of cases
# quantile(a$DATA_DIAGNOSTICO, prob = c(.55, .78), na.rm = T, type = 1)
# table(is.na(a$DATA_DIAGNOSTICO))

# a %>%
#   select(-ends_with(".DEN"), -ends_with(".CZO"))

# table(a2$C_EVOLUC_CASO, useNA = "always")
# table(a2$C_EVOLUC_CASO, useNA = "always")

# table(a$GAL_CHIK_RTPCR_RESULT, useNA = "always")
# table(a$GAL_DEN_RTPCR_RESULT, useNA = "always")
# table(a$GAL_ORO_RTPCR_RESULT, useNA = "always")
#
# table(a$C_CRIT_CONF_DESC, a$GAL_DEN_RTPCR_RESULT, useNA = "always")
# table(a$DENGUE_LAB_DIAG, a$GAL_DEN_RTPCR_RESULT, useNA = "always")
# table(a$CHIKUNGUNYA, a$GAL_CHIK_RTPCR_RESULT, useNA = "always")
# table(a$OROPOUCHE, a$GAL_ORO_RTPCR_RESULT, useNA = "always")

# table(a$GAL_DEN_RTPCR_RESULT, a$GAL_CHIK_RTPCR_RESULT, useNA = "always")
# prop.table(table(a$GAL_DEN_RTPCR_RESULT, a$GAL_CHIK_RTPCR_RESULT),2)

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") {detach(2)}

save.image(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))
