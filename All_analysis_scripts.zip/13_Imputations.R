# install.packages("rfUtilities")
suppressMessages(library(tidyverse))
suppressMessages(library(Hmisc))
# suppressMessages(library(randomForest))
suppressMessages(library(mice))
# suppressMessages(library(micemd))
suppressMessages(library(future))
suppressMessages(library(ranger))
suppressMessages(library(missForestPredict))
# suppressMessages(library(rfUtilities))
# suppressMessages(library(flextable))

load(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

rm(Table_all, Table_Chikungunya, Table_Dengue, Table_Dengue_severity, Table_Oropouche, Table_Zika)

# Data selection ----
# this is just to facilitate the removal of uninformative categories and temporary storage of labels
vars <- c("SEMANA_NUM","IDADE_ANOS_DT_NOTIFIC","SEXO", "GESTANTE", "RACA_COR",
          "ETNIA", "PCD", "MORADOR_RUA", "ESCOLARIDADE", "ZONA","DC_FEBRE",
          "DC_CEFALEIA", "DC_VOMITO", "DC_DOR_COSTAS", "DC_ARTRITE", "DC_PETEQUIAS",
          "DC_PROVA_LACO", "DC_MIALGIA", "DC_EXANTEMA", "DC_NAUSEAS", "DC_CONJUTIVITE",
          "DC_ARTRALGIA_INTENSA", "DC_LEUCOPENIA", "DC_DOR_RETROORBITAL", "DC_DIABETES",
          "DC_HEPATOPATIAS", "DC_HIPER_ARTERIAL", "DC_AUTO_IMUNES", "DC_HEMATOLOGICAS",
          "DC_RENAL_CRONICA", "DC_ACIDO_PEPTICA")

# Storing lablels temporarilly
stored_labels <- labelled::var_label(a[,vars])

# Editing for imputations
# table(b$OROPOUCHE)

b <-
  a %>%
  # bind_rows(
  #   a %>% filter(OROPOUCHE_01 == 1 & VALIDATION_3 == "Train") %>% sample_n(1000),
  #   a %>% filter(OROPOUCHE_01 == 1 & VALIDATION_3 == "Test") %>% sample_n(1000),
  #   a %>% filter(OROPOUCHE_01 == 0  & VALIDATION_3 == "Train") %>% sample_n(2500),
  #   a %>% filter(OROPOUCHE_01 == 0  & VALIDATION_3 == "Test") %>% sample_n(2500)
  # ) %>%
  select(CARTAO_SUS, IDADE_ANOS_DT_NOTIFIC, SEXO,
         GESTANTE, RACA_COR, ETNIA, PCD, MORADOR_RUA, ESCOLARIDADE, ZONA,

         DC_FEBRE,                     DC_CEFALEIA,                  DC_VOMITO,
         DC_DOR_COSTAS,                DC_ARTRITE,                   DC_PETEQUIAS,                 DC_PROVA_LACO,
         DC_MIALGIA,                   DC_EXANTEMA,                  DC_NAUSEAS,                   DC_CONJUTIVITE,
         DC_ARTRALGIA_INTENSA,         DC_LEUCOPENIA,                DC_DOR_RETROORBITAL,          DC_DIABETES,
         DC_HEPATOPATIAS,              DC_HIPER_ARTERIAL,            DC_AUTO_IMUNES,               DC_HEMATOLOGICAS,
         DC_RENAL_CRONICA,             DC_ACIDO_PEPTICA,

         AG_HIPOTENSAO, AG_PLAQUETAS, AG_VOMITOS_PERSISTENTES, AG_DOR_ABDOMINAL, AG_LETARGIA_IRR,
         AG_SANG_MUCOSA, AG_HEMATOCRITO, AG_HEPATOMEGALIA, AG_ACUMULO_LIQUIDOS, AG_PULSO,
         AG_PA_CONVERGENTE, AG_TEMPO_CAPILAR, AG_AC_LIQUIDOS, AG_TAQUICARDIA, AG_EXTREMIDADES_FRIAS,
         AG_HIPOTENSAO_ARTERIAL, AG_HEMATEMESE, AG_MELENA, AG_METRORAGIA_VOLUMOSA, AG_SANGRAMENTO_SNC,
         AG_AST_ALT, AG_MIOCARDITE, AG_ALTER_CONSCIENCIA, AG_OUTROS_ORGAOS,

         SEMANA_NUM, DENGUE,CHIKUNGUNYA,ZIKA,OROPOUCHE, DENGUE_01, CHIKUNGUNYA_01, ZIKA_01, OROPOUCHE_01,
         DENGUE_LAB_DIAG, CO_INFECCAO, C_CRIT_CONF_DESC, C_EVOLUC_CASO,
         C_AUTOCTONE, C_APRESENTACAO_CLINICA, DENGUE_SEVERITY,
         VALIDATION_1, VALIDATION_2, VALIDATION_3) %>%
  mutate(CARTAO_SUS = as.numeric(CARTAO_SUS),
         # SEMANA_DIAGNOSTICO = as.numeric(SEMANA_DIAGNOSTICO),
         across(
           .cols = all_of(setdiff(vars, c("IDADE_ANOS_DT_NOTIFIC","SEMANA_NUM"))),
           .fns = ~ fct_recode(.,
                             NULL = "Ignored",
                             NULL = "Ignored/Unknown",
                             NULL = "Unknown")))
labelled::var_label(b[vars]) <- stored_labels

# An atempt to clear the Enviroment memory
rm(a)

# sapply(b, class)
# head(a$SEMANA_DIAGNOSTICO)
# table(b$RACA_COR, useNA = "always")

## Signs and Symptoms NAs ----
png(paste0(result_path,"Missing_diagnosis_ss_",Sys.Date(),".png"), width = 480*12, height = 480*12, res = 72*8)
par(mfrow = c(1,2))
x <- naclus(b %>% select(IDADE_ANOS_DT_NOTIFIC, SEXO, GESTANTE, RACA_COR, ETNIA, PCD, MORADOR_RUA, ESCOLARIDADE, ZONA,

                         DC_FEBRE,                     DC_CEFALEIA,                  DC_VOMITO,
                         DC_DOR_COSTAS,                DC_ARTRITE,                   DC_PETEQUIAS,                 DC_PROVA_LACO,
                         DC_MIALGIA,                   DC_EXANTEMA,                  DC_NAUSEAS,                   DC_CONJUTIVITE,
                         DC_ARTRALGIA_INTENSA,         DC_LEUCOPENIA,                DC_DOR_RETROORBITAL,          DC_DIABETES,
                         DC_HEPATOPATIAS,              DC_HIPER_ARTERIAL,            DC_AUTO_IMUNES,               DC_HEMATOLOGICAS,
                         DC_RENAL_CRONICA,             DC_ACIDO_PEPTICA,

                         SEMANA_NUM, DENGUE,CHIKUNGUNYA,ZIKA,OROPOUCHE, DENGUE_01, CHIKUNGUNYA_01, ZIKA_01, OROPOUCHE_01,
                         DENGUE_LAB_DIAG, CO_INFECCAO, C_CRIT_CONF_DESC, C_EVOLUC_CASO,
                         C_AUTOCTONE, C_APRESENTACAO_CLINICA, DENGUE_SEVERITY, VALIDATION_1, VALIDATION_2))
colnames(x$sim) <- unname(label(b[,colnames(x$sim)]))
naplot(x, which = "na per obs", col = "red", cex.main = .99)
naplot(x, which = "na per var", col = "red", cex.main = .99)
dev.off()

png(paste0(result_path,"Missing_in_comom_",Sys.Date(),".png"), width = 480*12, height = 480*6, res = 72*8)
plot(x, ylab = "Fraction of NA in common", cex.main = 1.5)
dev.off(); rm(x)

## Comorbidities NAs ----

png(paste0(result_path,"Missing_severe_",Sys.Date(),".png"), width = 480*16, height = 480*8, res = 72*8)
par(mfrow = c(1,2))
x <- naclus(b %>% select(AG_HIPOTENSAO, AG_PLAQUETAS, AG_VOMITOS_PERSISTENTES, AG_DOR_ABDOMINAL, AG_LETARGIA_IRR,
                         AG_SANG_MUCOSA, AG_HEMATOCRITO, AG_HEPATOMEGALIA, AG_ACUMULO_LIQUIDOS, AG_PULSO,
                         AG_PA_CONVERGENTE, AG_TEMPO_CAPILAR, AG_AC_LIQUIDOS, AG_TAQUICARDIA, AG_EXTREMIDADES_FRIAS,
                         AG_HIPOTENSAO_ARTERIAL, AG_HEMATEMESE, AG_MELENA, AG_METRORAGIA_VOLUMOSA, AG_SANGRAMENTO_SNC,
                         AG_AST_ALT, AG_MIOCARDITE, AG_ALTER_CONSCIENCIA, AG_OUTROS_ORGAOS,))
colnames(x$sim) <- unname(label(b[,colnames(x$sim)]))
naplot(x, which = "na per obs", col = "red", cex.main = .99)
naplot(x, which = "na per var", col = "red", cex.main = .99)
dev.off();rm(x)



# Imputation ----
# save(b, file = paste0(data_path,"Data_to_be_imputed_",Sys.Date(),".RData"))

# b_1 <- b %>% select(CARTAO_SUS,
#                     OROPOUCHE_01,
#                     DENGUE_01,
#                     CHIKUNGUNYA_01,
#                     ZIKA_01,
#                     C_APRESENTACAO_CLINICA,
#                     CO_INFECCAO,
#                     DENGUE_LAB_DIAG,
#                     DENGUE_SEVERITY)
# rm(b_1)

# Selcting variable to impute either redundant or with > 80% missing (conditional missing)
b_2 <- b %>% select(-CARTAO_SUS,
                    -OROPOUCHE_01,
                    -DENGUE_01,
                    -CHIKUNGUNYA_01,
                    -ZIKA_01,
                    -C_APRESENTACAO_CLINICA,
                    -CO_INFECCAO,
                    -DENGUE_LAB_DIAG,
                    -DENGUE_SEVERITY,
                    -AG_HIPOTENSAO,
                    -AG_PLAQUETAS,
                    -AG_VOMITOS_PERSISTENTES,
                    -AG_DOR_ABDOMINAL,
                    -AG_LETARGIA_IRR,
                    -AG_SANG_MUCOSA,
                    -AG_HEMATOCRITO,
                    -AG_HEPATOMEGALIA,
                    -AG_ACUMULO_LIQUIDOS,
                    -AG_PULSO,
                    -AG_PA_CONVERGENTE,
                    -AG_TEMPO_CAPILAR,
                    -AG_AC_LIQUIDOS,
                    -AG_TAQUICARDIA,
                    -AG_EXTREMIDADES_FRIAS,
                    -AG_HIPOTENSAO_ARTERIAL,
                    -AG_HEMATEMESE,
                    -AG_MELENA,
                    -AG_METRORAGIA_VOLUMOSA,
                    -AG_SANGRAMENTO_SNC,
                    -AG_AST_ALT,
                    -AG_MIOCARDITE,
                    -AG_ALTER_CONSCIENCIA,
                    -AG_OUTROS_ORGAOS)
## rfImpute ----
# set.seed(1753109393)
# b_den <- rfImpute(DENGUE ~ ., b_2,
#                    ntree = 350,
#                    corr.bias = TRUE,
#                    mtry = 10,
#                    replace  = FALSE)

## mice ----
# (Predictive Mean Matching)
# gc()
# plan(multisession, workers = 2)
# time_ini <- Sys.time()
# b_mice <- futuremice(
#   data = b_2, # %>% slice_sample(n = 10000),
#   m = 2,
#   maxit = 5,
#   visitSequence = "monotone",
#   # n.core = 2,
#   method = "cart",
#   # seed = 1753109393,
#   parallelseed = 1753109393
# ) ; time_end <- Sys.time() ; difftime(time_end, time_ini, units = "mins")
# # print(b_den_mice$time)
# # b_den_mice <- b_den
# # plot(b_den_mice)
# # densityplot(b_den_mice)
# bi <- complete(b_den_mice, action = 2)
# bi <- bind_cols(b_1, bi)
# bi <- bi[,names(b)]
# labelled::var_label(bi[vars]) <- stored_labels
# save(bi, file = paste0(data_path,"Dengue_imputed_data_",Sys.Date(),".RData"))
# rm(b, b_1, b_2)


## recipes ----
# library(recipes)
# set.seed(1753109393)
# train <-
#   bind_rows(
#     b_2 %>%
#       filter(OROPOUCHE == "Yes")%>%
#       slice_sample(n = 10000),
#     b_2 %>%
#       filter(DENGUE == "Yes") %>%
#       slice_sample(n = 10000),
#     b_2 %>%
#       filter(CHIKUNGUNYA == "Yes") %>%
#       slice_sample(n = 10000),
#     b_2 %>%
#       filter(DENGUE != "Yes",
#              CHIKUNGUNYA != "Yes",
#              OROPOUCHE != "Yes",
#              ZIKA != "Yes") %>%
#       slice_sample(n = 10000),
#   )
# set.seed(1753109393)
# rec_imput <-
#   recipe(~ ., data = train) %>%
#   step_impute_bag(all_predictors()) # Usa �rvores (Bagging) para imputar
#
# set.seed(1753109393)
# fit_impute <- prep(rec_imput, training = train)
#
# set.seed(1753109393)
# bi <- bake(fit_impute, new_data = b_2)
# bi <- bind_cols(b_1, bi)
# bi <- bi[,names(b)]
# labelled::var_label(bi[vars]) <- stored_labels
# save(bi, file = paste0(data_path,"Dengue_imputed_data_",Sys.Date(),".RData"))
# rm(b, b_1, b_2)


##  missforest ----
# library(missForestPredict)
# > table(is.na(b))
#
# FALSE     TRUE
# 22252127 11 956 593
# table(b$DENGUE == "No" & b$CHIKUNGUNYA == "No" & b$ZIKA == "Yes" & b$OROPOUCHE == "No")

conditions <- list(
  c1 = quote(DENGUE == "Yes" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "No"),
  c2 = quote(DENGUE == "No" & CHIKUNGUNYA == "Yes" & ZIKA == "No" & OROPOUCHE == "No"),
  c3 = quote(DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "Yes" & OROPOUCHE == "No"),
  c4 = quote(DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "Yes"),
  c5 = quote(DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "No")
)

b_2 <- b_2 %>% mutate(row_id = row_number())
ids_train <- lapply(conditions, function(cond) {
  b_2 %>%
    filter(!!cond) %>%
    slice_sample(n = 3000) %>%
    pull(row_id)
}) %>% unlist()

b_2 <-
  b_2 %>%
  mutate(IMP_TRAIN = row_id %in% ids_train) %>%
  select(-row_id)

# b_2 %>%
#   filter(IMP_TRAIN) %>%
#   summarise(across(everything(), ~ mean(is.na(.)))) %>%
#   tidyr::pivot_longer(everything()) %>%
#   filter(value > 0.80) %>% #
#   pull(name)

# table(b_2$IMP_TRAIN)
# table(b_2$DENGUE)
# b_2 %>%
#   filter(IMP_TRAIN) %>%
#   select(CHIKUNGUNYA) %>%
#   table()

gc()
set.seed(1753109393)
time_ini <- Sys.time()
fit_impute <-
  missForestPredict::missForest(
    xmis = b_2 %>%
      filter(IMP_TRAIN) %>%
      select(-IMP_TRAIN),
    initialization = "median/mode",
    save_models = TRUE,
    # ntree = 350,
    # corr.bias = TRUE,
    # mtry = 10,
    replace  = TRUE,
    proximity = FALSE,
    maxiter = 15,
    num.threads = parallel::detectCores())
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
gc()
bi <- missForestPredict::missForestPredict(fit_impute, newdata = b)
time_end2 <- Sys.time() ; difftime(time_end2, time_ini, units = "mins") # aproximately 9 min
fit_impute$ximp <- NULL
# save(bi, file = paste0(data_path,"Dengue_imputed_data_",Sys.Date(),".RData"))
# table(is.na(bi %>% select(names(b_2 %>% select(-IMP_TRAIN)))))

bi <- bi %>% select(-C_APRESENTACAO_CLINICA,
                    -CO_INFECCAO,
                    -DENGUE_LAB_DIAG,
                    -DENGUE_SEVERITY,
                    -AG_HIPOTENSAO,
                    -AG_PLAQUETAS,
                    -AG_VOMITOS_PERSISTENTES,
                    -AG_DOR_ABDOMINAL,
                    -AG_LETARGIA_IRR,
                    -AG_SANG_MUCOSA,
                    -AG_HEMATOCRITO,
                    -AG_HEPATOMEGALIA,
                    -AG_ACUMULO_LIQUIDOS,
                    -AG_PULSO,
                    -AG_PA_CONVERGENTE,
                    -AG_TEMPO_CAPILAR,
                    -AG_AC_LIQUIDOS,
                    -AG_TAQUICARDIA,
                    -AG_EXTREMIDADES_FRIAS,
                    -AG_HIPOTENSAO_ARTERIAL,
                    -AG_HEMATEMESE,
                    -AG_MELENA,
                    -AG_METRORAGIA_VOLUMOSA,
                    -AG_SANGRAMENTO_SNC,
                    -AG_AST_ALT,
                    -AG_MIOCARDITE,
                    -AG_ALTER_CONSCIENCIA,
                    -AG_OUTROS_ORGAOS)

suppressWarnings(
  rm(vars, stored_labels, b_1,b_2, time_ini, time_end, time_end1, time_end2, conditions, b, ids_train, predictors, size)
)

write.csv(bi, paste0(data_path,"Imputed_data_",Sys.Date(),".csv"))

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Imputed_data_",Sys.Date(),".RData"))
# load(paste0(data_path,"Imputed_data_",Sys.Date(),".RData"))

# rm(list = grep("data_path", ls(), value = TRUE, invert = TRUE))


