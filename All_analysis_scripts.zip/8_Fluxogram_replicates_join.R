# install.packages("DiagrammeR")
# install.packages("DiagrammeRsvg")
# install.packages("magrittr")
# install.packages("rsvg")
suppressMessages(library(tidyverse))
suppressMessages(library(DiagrammeR))
suppressMessages(library(DiagrammeRsvg))
suppressMessages(library(magrittr))
suppressMessages(library(rsvg))
# suppressMessages(library(labelled))

load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Dengue ----
# y <- den_minor
y <- den
y_n <- nrow(y)
fp <- list(paste0("Total Dengue notifications \n extracted from SINAN database: ", format(y_n, big.mark = ",")))

##Filtering from march 2023 or later -----
y <-
  y %>%
  filter(DATA_DIAGNOSTICO > "2023-03-01")

fp[[2]] <- paste0("Case incidence before March 2023: ", format(y_n - nrow(y), big.mark = ",") )
y_n <- nrow(y)

## Filtering NA CNS -----
y <-
  y %>%
    filter(!is.na(CARTAO_SUS))
# table(is.na(y$CARTAO_SUS))

fp[[2]] <- paste0(fp[[2]], "\n Notifications without CNS number: ", format(y_n - nrow(y), big.mark = ",") )
y_n <- nrow(y)

##Filtering invalid CNS -----
y <-
  y %>%
  filter(CNS_valid == TRUE)

fp[[2]] <- paste0(fp[[2]], "\n Notifications with invalid CNS number: ", format(y_n - nrow(y), big.mark = ",") )
y_n <- nrow(y)

##Filtering absence outcome -----
y <-
  y %>%
  filter(!is.na(DENGUE) | !is.na(CHIKUNGUNYA))

fp[[2]] <- paste0(fp[[2]], "\n Notifications without investigation outcome: ", format(y_n - nrow(y), big.mark = ",") )
y_n <- nrow(y)

##  Removingn replicates ----
# table(duplicated(den$NUM_NOTIFICACAO))
y <- replicates_dates(df = y,
                      id_col = "CARTAO_SUS",
                      date_col = "DATA_DIAGNOSTICO")

# y %>%
#   select(CARTAO_SUS, NUM_NOTIFICACAO, DATA_DIAGNOSTICO, DATA_NOTIFICACAO) %>%
#   group_by(CARTAO_SUS, DATA_NOTIFICACAO) %>%
#   filter(n() > 1) %>%
#   arrange(CARTAO_SUS)

replicated <- y %>%
  filter(CARTAO_SUS %in% y$CARTAO_SUS[duplicated(y$CARTAO_SUS) &
                                        y$CNS_valid == TRUE &
                                        y$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(DENGUE =
           case_when(
             any(DENGUE == "Yes") ~ "Yes",
             .default = "No")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)
y <-
  y %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
y <- bind_rows(y, replicated) %>%
  arrange(CARTAO_SUS, DATA_DIAGNOSTICO)
rm(replicated)
#   y %>%
#     filter(CARTAO_SUS %in% c(705805485283134, 700007612517803)) %>%
#     select(CARTAO_SUS, DATA_DIAGNOSTICO, C_CLASSIFIC, DENGUE, IS_REPLICATE)

fp[[2]] <- paste0(fp[[2]], "\n Replicated notifications removed: ", format(y_n - nrow(y), big.mark = ",") )
fp[[3]] <- format( nrow(y), big.mark = ",")

# Dengue GAL ----
yg <- den_gal
yg_n <- nrow(yg)
fp[[21]] <- list(
              paste0("Total Dengue entries in \n Laboratory Environment Manager: ",
                     format(yg_n, big.mark = ",")))

##Filtering from march 2023 or later -----
yg <-
  yg %>%
  filter(`Data da Solicita��o` > "2023-03-01")

fp[[22]] <- paste0("Dengue test request before March 2023: ", format(yg_n - nrow(yg), big.mark = ",") )
yg_n <- nrow(yg)

## Filtering NA Notification number valid CNS -----
### h� muitos n�meros de notifica��o com valores insperados.
### pra Dngue o n�mero de notifica��o everia sempre ter 7 d�gitos
yg <-
  yg %>%
  filter((!is.na(NUM_NOTIFICACAO) & as.character(NUM_NOTIFICACAO) != 7) | (CNS_valid & !is.na(DATA_NOTIFICACAO)))

fp[[22]] <- paste0(fp[[22]], "\n Entries without or invalid notification ID, \n nor valid CNS plus notification date: ", format(yg_n - nrow(yg), big.mark = ",") )
yg_n <- nrow(yg)

##  Removingn replicates ----
# If any entry is replicated then positive results are kept
yg <- replicates_dates(yg,
                       id_col = "CARTAO_SUS",
                       date_col = "DATA_NOTIFICACAO")

replicated <- yg %>%
  filter(CARTAO_SUS %in% yg$CARTAO_SUS[duplicated(yg$CARTAO_SUS) &
                                        yg$CNS_valid == TRUE &
                                        yg$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(GAL_DEN_RTPCR_RESULT =
           case_when(
             any(GAL_DEN_RTPCR_RESULT == "Positive") ~ "Positive",
             .default = "Negative")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)
yg <-
  yg %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
yg <- bind_rows(yg, replicated) %>%
  arrange(CARTAO_SUS, DATA_NOTIFICACAO)
rm(replicated)


fp[[22]] <- paste0(fp[[22]], "\n Replicated Dengue laboratory entries removed: ", format(yg_n - nrow(yg), big.mark = ",") )
fp[[23]] <- format( nrow(yg), big.mark = ",")

# H� n�mero de notifica��es repetecos mas aparentemente s�o segundas, terceiras amostras (reteste?)
# Inclusive resultados positivos repetidos da mesma notifica��o.
# yg %>%
#   filter(NUM_NOTIFICACAO %in% unique(lab_clean_num$NUM_NOTIFICACAO[duplicated(lab_clean_num$NUM_NOTIFICACAO)])) %>%
#   arrange(NUM_NOTIFICACAO, GAL_DEN_RTPCR_RESULT, `Data da Solicita��o`) %>%
#   select(NUM_NOTIFICACAO, `Data da Solicita��o`, DATA_NOTIFICACAO, GAL_DEN_RTPCR_RESULT) %>%
#   print(n = 300)


# Matching Dengue + GAL dengue data ----

## Dengue with matches in GAL
### Create a unique key for the matches
ygal_matches <- tag_best_match_lab(df_notif = y, # dengue
                                   df_lab = yg, # GAL dengue
                                   id_cns = "CARTAO_SUS",
                                   id_num = "NUM_NOTIFICACAO",
                                   date_ref = "DATA_NOTIFICACAO",
                                   res_col = "GAL_DEN_RTPCR_RESULT",
                                   days_limit = 14)

fp[[24]] <- paste0("Matches between Dengue notifications and \n the Dengue laboratory datasets: ", format(nrow(ygal_matches), big.mark = ","))

# Binding the test result and the KEY by the best match in dengue notification
# nrow(y)
# Fazendo primeiro pelo numero da notifica��o
y <- y %>%
  left_join(ygal_matches %>%
              filter(match_type == "BY_NUM") %>%
              select(NUM_NOTIFICACAO, KEY, RESULTADO_FINAL),
            by = "NUM_NOTIFICACAO",
            suffix =c(".NOT",".MAT")) %>%
  rename(GAL_DEN_RTPCR_RESULT = RESULTADO_FINAL)
# table(y$GAL_DEN_RTPCR_RESULT)

# If any is left, binding by CNS and date combination
if(any(ygal_matches$match_type == "BY_DATE")) {
  y <- y %>%
    left_join(ygal_matches %>%
                filter(match_type == "BY_DATE") %>%
                select(CARTAO_SUS, DATA_NOTIFICACAO, KEY, RESULTADO_FINAL),
              by = c("CARTAO_SUS","DATA_NOTIFICACAO"),
              suffix =c(".NOT",".MAT"))%>%
    mutate(KEY = coalesce(KEY.NOT, KEY.MAT),
           GAL_DEN_RTPCR_RESULT = coalesce(GAL_DEN_RTPCR_RESULT, RESULTADO_FINAL)) %>%
    select(-KEY.NOT, -KEY.MAT, -RESULTADO_FINAL, -KEY)
}
# table(y$RESULTADO_FINAL)
# table(y$GAL_DEN_RTPCR_RESULT)

# ygal_matches %>%
  # filter(DATA_NOTIFICACAO == "2025-01-23") %>%
  # filter(NUM_NOTIFICACAO == "64011659") %>%
  # filter(CARTAO_SUS == "704503398826116") %>%
  # select(CARTAO_SUS,NUM_NOTIFICACAO,DATA_NOTIFICACAO, KEY)
  # 704503398826116 2025-01-23

# Chikungunya ----
w <- chik
w_n <- nrow(w)
fp[[4]] <- list(paste0("Total Chikungunya notifications \n extracted from SINAN database: ", format(w_n, big.mark = ",")))

##Filtering from march 2023 or later -----
w <-
  w %>%
  filter(DATA_DIAGNOSTICO > "2023-03-01")

fp[[5]] <- paste0("Case incidence before March 2023: ", format(w_n - nrow(w), big.mark = ",") )
w_n <- nrow(w)

## Filtering NA CNS -----
w <-
  w %>%
  filter(!is.na(CARTAO_SUS))

fp[[5]] <- paste0(fp[[5]], "\n Notifications without CNS number: ", format(w_n - nrow(w), big.mark = ",") )
w_n <- nrow(w)

##Filtering invalid CNS -----
w <-
  w %>%
  filter(CNS_valid == TRUE)

fp[[5]] <- paste0(fp[[5]], "\n Notifications with invalid CNS number: ", format(w_n - nrow(w), big.mark = ",") )
w_n <- nrow(w)

##Filtering absence outcome CNS -----
w <-
  w %>%
  filter(!is.na(DENGUE) | !is.na(CHIKUNGUNYA))

fp[[5]] <- paste0(fp[[5]], "\n Notifications without investigation outcome: ", format(w_n - nrow(w), big.mark = ",") )
w_n <- nrow(w)

##  Removingn replicates ----
w <- replicates_dates(w)
replicated <- w %>%
  filter(CARTAO_SUS %in% w$CARTAO_SUS[duplicated(w$CARTAO_SUS) &
                                        w$CNS_valid == TRUE &
                                        w$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(CHIKUNGUNYA =
           if_else(any(CHIKUNGUNYA == "Yes"), "Yes", "No"),
         DENGUE =
           if_else(any(DENGUE == "Yes"), "Yes", "No")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)

w <-
  w %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
w <- bind_rows(w, replicated) %>%
  arrange(CARTAO_SUS, DATA_DIAGNOSTICO)
rm(replicated)

fp[[5]] <- paste0(fp[[5]], "\n Replicated notifications removed: ",format(w_n - nrow(w), big.mark = ",") )
fp[[6]] <- format(nrow(w), big.mark = ",")

# Chikungunya GAL ----

wg <- chik_gal
wg_n <- nrow(wg)
fp[[25]] <- list(
  paste0("Total Chikungunya entries in \n Laboratory Environment Manager: ",
         format(wg_n, big.mark = ",")))

##Filtering from march 2023 or later -----
wg <-
  wg %>%
  filter(`Data da Solicita��o` > "2023-03-01")

fp[[26]] <- paste0("Chikungunya test request before March 2023: ", format(wg_n - nrow(wg), big.mark = ",") )
wg_n <- nrow(wg)

## Filtering NA Notification number valid CNS -----
### h� muitos n�meros de notifica��o com valores insperados.
### pra Dngue o n�mero de notifica��o everia sempre ter 7 d�gitos
wg <-
  wg %>%
  filter((!is.na(NUM_NOTIFICACAO) & as.character(NUM_NOTIFICACAO) != 7) | (CNS_valid & !is.na(DATA_NOTIFICACAO)))

fp[[26]] <- paste0(fp[[26]], "\n Entries without or invalid notification ID, \n nor valid CNS plus notification date: ", format(wg_n - nrow(wg), big.mark = ",") )
wg_n <- nrow(wg)

##  Removingn replicates ----
# If any entry is replicated then positive results are kept
wg <- replicates_dates(wg,
                       id_col = "CARTAO_SUS",
                       date_col = "DATA_NOTIFICACAO")

replicated <- wg %>%
  filter(CARTAO_SUS %in% wg$CARTAO_SUS[duplicated(wg$CARTAO_SUS) &
                                         wg$CNS_valid == TRUE &
                                         wg$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(GAL_CHIK_RTPCR_RESULT =
           case_when(
             any(GAL_CHIK_RTPCR_RESULT == "Positive") ~ "Positive",
             .default = "Negative")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)
wg <-
  wg %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
wg <- bind_rows(wg, replicated) %>%
  arrange(CARTAO_SUS, DATA_NOTIFICACAO)
rm(replicated)
# names(wg)

fp[[26]] <- paste0(fp[[26]], "\n Replicated Chikungunya laboratory entries removed: ", format(wg_n - nrow(wg), big.mark = ",") )
fp[[27]] <- format( nrow(wg), big.mark = ",")

# H� n�mero de notifica��es repetecos mas aparentemente s�o segundas, terceiras amostras (reteste?)
# Inclusive resultados positivos repetidos da mesma notifica��o.
# wg %>%
#   filter(NUM_NOTIFICACAO %in% unique(lab_clean_num$NUM_NOTIFICACAO[duplicated(lab_clean_num$NUM_NOTIFICACAO)])) %>%
#   arrange(NUM_NOTIFICACAO, GAL_DEN_RTPCR_RESULT, `Data da Solicita��o`) %>%
#   select(NUM_NOTIFICACAO, `Data da Solicita��o`, DATA_NOTIFICACAO, GAL_DEN_RTPCR_RESULT) %>%
#   print(n = 300)


# Matching Chik GAL + Chik data ----
# table(nchar(w$NUM_NOTIFICACAO) == 7)
# nrow(w)
# table(nchar(wg$NUM_NOTIFICACAO) == 7)
# table(is.na(wg$NUM_NOTIFICACAO))
# table(wg$NUM_NOTIFICACAO == "")
# table(w$NUM_NOTIFICACAO %in% wg$NUM_NOTIFICACAO[nchar(wg$NUM_NOTIFICACAO) == 7])

## Chikungunya with matches in GAL
### Create a unique key for the matches
wgal_matches <- tag_best_match_lab(df_notif = w, # Chikungunya
                                   df_lab = wg, # GAL Chikungunya
                                   id_cns = "CARTAO_SUS",
                                   id_num = "NUM_NOTIFICACAO",
                                   date_ref = "DATA_NOTIFICACAO",
                                   res_col = "GAL_CHIK_RTPCR_RESULT",
                                   days_limit = 14)

fp[[28]] <- paste0("Matches between Chikungunya notifications and \n the Chikungunya laboratory datasets: ", format(nrow(wgal_matches), big.mark = ","))

# Binding the test result and the KEY by the best match in Chikungunya notification
# nrow(y)
# Fazendo primeiro pelo numero da notifica��o
w <- w %>%
  left_join(wgal_matches %>%
              filter(match_type == "BY_NUM") %>%
              select(NUM_NOTIFICACAO, KEY, RESULTADO_FINAL),
            by = "NUM_NOTIFICACAO",
            suffix =c(".NOT",".MAT")) %>%
  rename(GAL_CHIK_RTPCR_RESULT = RESULTADO_FINAL)
# table(w$GAL_CHIK_RTPCR_RESULT)

# If any is left, binding by CNS and date combination
if(any(wgal_matches$match_type == "BY_DATE")) {
  w <- w %>%
    left_join(wgal_matches %>%
                filter(match_type == "BY_DATE") %>%
                select(CARTAO_SUS, DATA_NOTIFICACAO, KEY, RESULTADO_FINAL),
              by = c("CARTAO_SUS","DATA_NOTIFICACAO"),
              suffix =c(".NOT",".MAT"))%>%
    mutate(KEY = coalesce(KEY.NOT, KEY.MAT),
           GAL_CHIK_RTPCR_RESULT = coalesce(GAL_CHIK_RTPCR_RESULT, RESULTADO_FINAL)) %>%
    select(-KEY.NOT, -KEY.MAT, -RESULTADO_FINAL, -KEY)
}
# table(w$RESULTADO_FINAL)
# table(w$GAL_CHIK_RTPCR_RESULT)

# wgal_matches %>%
# filter(DATA_NOTIFICACAO == "2025-01-23") %>%
# filter(NUM_NOTIFICACAO == "64011659") %>%
# filter(CARTAO_SUS == "704503398826116") %>%
# select(CARTAO_SUS,NUM_NOTIFICACAO,DATA_NOTIFICACAO, KEY)
# 704503398826116 2025-01-23

# Zika and Oropouche ----
z <- zik
z_n <- nrow(z)
fp[[7]] <- list(paste0("Total Oropouche and Zika notifications \n extracted from SINAN database: ", format(z_n, big.mark = ",")))

##Filtering from march 2023 or later -----
z <-
  z %>%
  filter(DATA_DIAGNOSTICO > "2023-03-01")

fp[[8]] <- paste0("Case incidence before March 2023: ", format(z_n - nrow(z), big.mark = ",") )
z_n <- nrow(z)

## Filtering NA CNS -----
z <-
  z %>%
  filter(!is.na(CARTAO_SUS))

fp[[8]] <- paste0(fp[[8]], "\n Notifications without CNS number: ", format(z_n - nrow(z), big.mark = ",") )
z_n <- nrow(z)

##Filtering invalid CNS -----
z <-
  z %>%
  filter(CNS_valid == TRUE)

fp[[8]] <- paste0(fp[[8]], "\n Notifications with invalid CNS number: ", format(z_n - nrow(z), big.mark = ",") )
z_n <- nrow(z)

##Filtering absence outcome CNS -----
z <-
  z %>%
  filter(!is.na(ZIKA) | !is.na(OROPOUCHE))

fp[[8]] <- paste0(fp[[8]], "\n Notifications without investigation outcome: ", format(z_n - nrow(z), big.mark = ",") )
z_n <- nrow(z)

##  Removingn replicates ----
z <- replicates_dates(df = z,
                      id_col = "CARTAO_SUS",
                      date_col = "DATA_NOTIFICACAO")
# table(z$IS_REPLICATE)
replicated <- z %>%
  filter(CARTAO_SUS %in% z$CARTAO_SUS[duplicated(z$CARTAO_SUS) &
                                        z$CNS_valid == TRUE &
                                        z$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(ZIKA =
           if_else(any(ZIKA == "Yes"), "Yes", "No"),
         OROPOUCHE =
           if_else(any(OROPOUCHE == "Yes"), "Yes", "No")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)

z <-
  z %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
z <- bind_rows(z, replicated) %>%
  arrange(CARTAO_SUS, DATA_DIAGNOSTICO)
rm(replicated)

fp[[8]] <- paste0(fp[[8]], "\n Replicated notifications removed: ", format(z_n - nrow(z), big.mark = ",") )
fp[[9]] <- format(nrow(z), big.mark = ",")

# Oropouche GAL ----
# There is no positive test for Zika in GAL data
zg <- oro_gal
zg_n <- nrow(zg)
fp[[29]] <- list(
  paste0("Total Oropouche entries in \n Laboratory Environment Manager: ",
         format(zg_n, big.mark = ",")))

##Filtering from march 2023 or later -----
zg <-
  zg %>%
  filter(`Data da Solicita��o` > "2023-03-01")

fp[[30]] <- paste0("Oropouche test request before March 2023: ", format(zg_n - nrow(zg), big.mark = ",") )
zg_n <- nrow(zg)

## Filtering NA Notification number valid CNS -----
### h� muitos n�meros de notifica��o com valores insperados.
### pra Dngue o n�mero de notifica��o everia sempre ter 7 d�gitos
zg <-
  zg %>%
  filter((!is.na(NUM_NOTIFICACAO) & as.character(NUM_NOTIFICACAO) != 7) | (CNS_valid & !is.na(DATA_NOTIFICACAO)))

fp[[30]] <- paste0(fp[[30]], "\n Entries without or invalid notification ID, \n nor valid CNS plus notification date: ", format(zg_n - nrow(zg), big.mark = ",") )
zg_n <- nrow(zg)

##  Removingn replicates ----
# If any entry is replicated then positive results are kept
zg <- replicates_dates(zg,
                       id_col = "CARTAO_SUS",
                       date_col = "DATA_NOTIFICACAO")

replicated <- zg %>%
  filter(CARTAO_SUS %in% zg$CARTAO_SUS[duplicated(zg$CARTAO_SUS) &
                                         zg$CNS_valid == TRUE &
                                         zg$IS_REPLICATE == TRUE]) %>%
  group_by(CARTAO_SUS) %>%
  mutate(GAL_ORO_RTPCR_RESULT =
           case_when(
             any(GAL_ORO_RTPCR_RESULT == "Positive") ~ "Positive",
             .default = "Negative")) %>%
  ungroup() %>%
  filter(IS_REPLICATE != TRUE)
zg <-
  zg %>%
  filter(!(CARTAO_SUS %in% unique(replicated$CARTAO_SUS)))
zg <- bind_rows(zg, replicated) %>%
  arrange(CARTAO_SUS, DATA_NOTIFICACAO)
rm(replicated)
# names(zg)

fp[[30]] <- paste0(fp[[30]], "\n Replicated Oropouche laboratory entries removed: ", format(zg_n - nrow(zg), big.mark = ",") )
fp[[31]] <- format( nrow(zg), big.mark = ",")

# H� n�mero de notifica��es repetecos mas aparentemente s�o segundas, terceiras amostras (reteste?)
# Inclusive resultados positivos repetidos da mesma notifica��o.
# zg %>%
#   filter(NUM_NOTIFICACAO %in% unique(lab_clean_num$NUM_NOTIFICACAO[duplicated(lab_clean_num$NUM_NOTIFICACAO)])) %>%
#   arrange(NUM_NOTIFICACAO, GAL_DEN_RTPCR_RESULT, `Data da Solicita��o`) %>%
#   select(NUM_NOTIFICACAO, `Data da Solicita��o`, DATA_NOTIFICACAO, GAL_DEN_RTPCR_RESULT) %>%
#   print(n = 300)


# Matching Oropouche GAL + Oropouche SINAN ----
# table(nchar(w$NUM_NOTIFICACAO) == 7)
# nrow(w)
# table(nchar(zg$NUM_NOTIFICACAO) == 7)
# table(is.na(zg$NUM_NOTIFICACAO))
# table(zg$NUM_NOTIFICACAO == "")
# table(w$NUM_NOTIFICACAO %in% zg$NUM_NOTIFICACAO[nchar(zg$NUM_NOTIFICACAO) == 7])

## Oropouche with matches in GAL
### Create a unique key for the matches
zgal_matches <- tag_best_match_lab(df_notif = z, # Oropouche
                                   df_lab = zg, # GAL Oropouche
                                   id_cns = "CARTAO_SUS",
                                   id_num = "NUM_NOTIFICACAO",
                                   date_ref = "DATA_NOTIFICACAO",
                                   res_col = "GAL_ORO_RTPCR_RESULT",
                                   days_limit = 14)

fp[[32]] <- paste0("Matches between Oropouche notifications and \n the Oropouche laboratory datasets: ", format(nrow(zgal_matches), big.mark = ","))

# Binding the test result and the KEY by the best match in Oropouche notification
# nrow(y)
# Fazendo primeiro pelo numero da notifica��o
z <- z %>%
  left_join(zgal_matches %>%
              filter(match_type == "BY_NUM") %>%
              select(NUM_NOTIFICACAO, KEY, RESULTADO_FINAL),
            by = "NUM_NOTIFICACAO",
            suffix =c(".NOT",".MAT")) %>%
  rename(GAL_ORO_RTPCR_RESULT = RESULTADO_FINAL)
# table(z$GAL_ORO_RTPCR_RESULT)

# If any is left, binding by CNS and date combination
if(any(zgal_matches$match_type == "BY_DATE")) {
  z <- z %>%
    left_join(zgal_matches %>%
                filter(match_type == "BY_DATE") %>%
                select(CARTAO_SUS, DATA_NOTIFICACAO, KEY, RESULTADO_FINAL),
              by = c("CARTAO_SUS","DATA_NOTIFICACAO"),
              suffix =c(".NOT",".MAT"))%>%
    mutate(KEY = coalesce(KEY.NOT, KEY.MAT),
           GAL_ORO_RTPCR_RESULT = coalesce(GAL_ORO_RTPCR_RESULT, RESULTADO_FINAL)) %>%
    select(-KEY.NOT, -KEY.MAT, -RESULTADO_FINAL, -KEY)
}
# table(z$RESULTADO_FINAL)
# table(z$GAL_ORO_RTPCR_RESULT)

# Cheking matches ----

## Zika vs Chikungunya ----

## Zika and Oropouche in Dengue matches
# prop.table(table(z$CARTAO_SUS_C %in% y$CARTAO_SUS_C))
## Chikungunya in Dengue matches
# prop.table(table(w$CARTAO_SUS_C %in% y$CARTAO_SUS_C))
## Zika and Oropouche in Chikungunya matches
# prop.table(table(z$CARTAO_SUS_C %in% w$CARTAO_SUS_C))

## Zika and Oropouche in Dengue matches
# table(z$CARTAO_SUS %in% y$CARTAO_SUS)
## Chikungunya in Dengue matches
# table(w$CARTAO_SUS %in% y$CARTAO_SUS)
## Zika and Oropouche in Chikungunya matches
# table(z$CARTAO_SUS %in% w$CARTAO_SUS)

# Find matches ZIK (z) in CHIK (w)
zw_matches <- tag_best_match(df_a = z,
                             df_b = w,
                             suffix_a = "_ZIK",
                             suffix_b = "_CHIK",
                             id_col = "CARTAO_SUS",
                             date_col_a = "DATA_DIAGNOSTICO",
                             date_col_b = "DATA_DIAGNOSTICO",
                             days = 14)
# zw_matches
# names(z)
# z$KEY <- NULL

fp[[10]] <- paste0("Matches between Zika/Oropouche dataset \n with the Chikungunya dataset: ", format(nrow(zw_matches), big.mark = ","))

# Binding the KEY by the best match in ZIK
z <- z %>%
  left_join(zw_matches,
            by = c("CARTAO_SUS", "DATA_DIAGNOSTICO" = "DATA_DIAGNOSTICO_ZIK"),
            suffix =c(".ZIK",".MAT")) %>%
  mutate(KEY = if_else(is.na(KEY),paste(CARTAO_SUS, DATA_DIAGNOSTICO, sep = "_"),KEY),
         DATA_SINTOMAS = if_else(is.na(DATA_SINTOMAS), DATA_DIAGNOSTICO, DATA_SINTOMAS))

# z %>%
#   select(CARTAO_SUS, DATA_DIAGNOSTICO, DATA_SINTOMAS, KEY)

# Binding the KEY by the best match  in CHIK
# names(w)
# w$KEY <- NULL
w <- w %>%
  left_join(zw_matches,
            by = c("CARTAO_SUS", "DATA_DIAGNOSTICO" = "DATA_DIAGNOSTICO_CHIK"),
            suffix =c(".CHIK",".MAT")) %>%
  mutate(KEY = if_else(is.na(KEY),paste(CARTAO_SUS, DATA_DIAGNOSTICO, sep = "_"),KEY),
         DATA_SINTOMAS = if_else(is.na(DATA_SINTOMAS), DATA_DIAGNOSTICO, DATA_SINTOMAS))

# w %>%
#   select(CARTAO_SUS, DATA_DIAGNOSTICO, DATA_SINTOMAS, KEY)
# table(nchar(w$KEY))


# Binding ZIK (z) in CHIK (w)
zw <- w %>%
  full_join(z, by = "KEY",
            suffix =c(".CHIK",".ZIK")) %>%
  mutate(CARTAO_SUS =
           if_else(is.na(CARTAO_SUS.CHIK), CARTAO_SUS.ZIK, CARTAO_SUS.CHIK),
         DATA_DIAGNOSTICO =
           if_else(is.na(DATA_SINTOMAS.ZIK), DATA_SINTOMAS.CHIK, DATA_SINTOMAS.ZIK))

# zw %>%
#   select(ends_with(".CHIK"),ends_with(".ZIK"))
# zw %>%
#   select(CARTAO_SUS, DATA_DIAGNOSTICO, KEY)
# table(is.na(zw$CARTAO_SUS.CHIK),is.na(zw$CARTAO_SUS.ZIK), useNA = "always")
# table(is.na(zw$CARTAO_SUS), useNA = "always")
# table(is.na(zw$DATA_SINTOMAS.ZIK), is.na(zw$DATA_SINTOMAS.CHIK), useNA = "always")
# addmargins(table(nchar(zw$KEY)))

fp[[10]] <-  paste0(fp[[10]],"\n Total of Zika/Oropouche/Chikungunya \n notifications after binding datasets: ", format(nrow(zw), big.mark = ","))


## Zika + Chikungunya vs Dengue ----

# Find matches ZIK + CHIK (zw) in DEN (y)
# zw$CARTAO_SUS[1:10]
zwy_matches <- tag_best_match(df_a = zw,
                              df_b = y,
                              date_col_a = "DATA_DIAGNOSTICO",
                              date_col_b = "DATA_DIAGNOSTICO",
                              suffix_a = "_ZC",
                              suffix_b = "_DEN")
# zwy_matches

fp[[11]] <- paste0("Matches between Zika/Oropouche/Chikungunya \n dataset with the Dengue dataset: ", format(nrow(zwy_matches), big.mark = ","))

# Binding the KEY by the best match in (zw) Zika+Chik
zw <- zw %>%
  select(-KEY) %>%
  left_join(zwy_matches,
            by = c("CARTAO_SUS", "DATA_DIAGNOSTICO" = "DATA_DIAGNOSTICO_ZC")) %>%
  mutate(KEY = if_else(is.na(KEY),paste(CARTAO_SUS, DATA_DIAGNOSTICO, sep = "_"), KEY),
         DATA_SINTOMAS = if_else(is.na(DATA_SINTOMAS), DATA_DIAGNOSTICO, DATA_SINTOMAS)) %>%
  select(-DATA_DIAGNOSTICO) %>%
  rename(DATA_DIAGNOSTICO = DATA_SINTOMAS)

# zw %>%
#   select(str_which(names(.),"DL_S"))
# zw %>%
#   select(CARTAO_SUS, DATA_DIAGNOSTICO, KEY)
# table(is.na(zw$CARTAO_SUS.CHIK),is.na(zw$CARTAO_SUS.ZIK), useNA = "always")
# table(is.na(zw$CARTAO_SUS), useNA = "always")
# table(is.na(zw$DATA_SINTOMAS.ZIK), is.na(zw$DATA_SINTOMAS.CHIK), useNA = "always")
# addmargins(table(nchar(zw$KEY)))

# Binding the KEY by the best match in Dengue
# y$KEY <- NULL
y <- y %>%
  left_join(zwy_matches,
            by = c("CARTAO_SUS", "DATA_DIAGNOSTICO" = "DATA_DIAGNOSTICO_DEN")) %>%
  mutate(KEY = if_else(is.na(KEY),paste(CARTAO_SUS, DATA_DIAGNOSTICO, sep = "_"),KEY),
         DATA_SINTOMAS = if_else(is.na(DATA_SINTOMAS), DATA_DIAGNOSTICO, DATA_SINTOMAS)) %>%
  select(-DATA_DIAGNOSTICO) %>%
  rename(DATA_DIAGNOSTICO = DATA_SINTOMAS)

# y %>%
#   select(CARTAO_SUS, DATA_DIAGNOSTICO, KEY)
# table(is.na(y$CARTAO_SUS), useNA = "always")
# table(is.na(y$DATA_DIAGNOSTICO), useNA = "always")
# addmargins(table(nchar(y$KEY)))

# Binding ZIK + CHIK (zw) and Dengue (y)
a <- y %>%
  full_join(zw,
            by = "KEY",
            suffix = c(".DEN",".CZO")) %>%
  mutate(
    DENGUE = case_when(
      DENGUE.DEN == "Yes" ~ "Yes",
      DENGUE.CZO == "Yes" ~ "Yes",
      .default = "No",
      .ptype = factor(levels = c("No","Yes"))),
    CHIKUNGUNYA = case_when(
      CHIKUNGUNYA.CZO == "Yes" ~ "Yes",
      CHIKUNGUNYA.DEN == "Yes" ~ "Yes",
      .default = "No",
      .ptype = factor(levels = c("No","Yes"))),
    ZIKA = if_else(is.na(ZIKA), "No", ZIKA, ptype = factor(levels = c("No","Yes"))),
    OROPOUCHE = if_else(is.na(OROPOUCHE), "No", OROPOUCHE, ptype = factor(levels = c("No","Yes")))) %>%
  select(-DENGUE.DEN, -DENGUE.CZO, -CHIKUNGUNYA.CZO, -CHIKUNGUNYA.DEN)

# names(a)

fp[[11]] <-  paste0(fp[[11]],"\n Total of Zika/Oropouche/Chikungunya/Dengue \n notifications after binding datasets: ", format(nrow(a), big.mark = ","))


# Final diagnosis ----

# table(a$DENGUE.DEN, a$DENGUE.CZO, useNA = "always")
# table(a$CHIKUNGUNYA.CZO, a$CHIKUNGUNYA.DEN, useNA = "always")
# table(a$ZIKA, useNA = "always")
# table(a$OROPOUCHE, useNA = "always")

## Dengue ----
tab_temp <- table(a$C_CRIT_CONF_DESC.DEN[a$DENGUE == "Yes"], useNA = "always")
# table(a$C_CRIT_CONF_DESC.DEN[a$DENGUE == "No"], useNA = "always")

fp[[12]] <-  paste0("Dengue cases in dataset: \n",
                    format(table(a$DENGUE)["Yes"], big.mark = ","),
                    " (",round(prop.table(table(a$DENGUE))["Yes"]*100,2),"%) \n \n")

fp[[12]] <-  paste0(fp[[12]],
                    "Dengue cases confirmations: \n",
                    names(tab_temp[1]), ": ",
                    format(tab_temp[1], big.mark = ","),
                    " (",round(prop.table(tab_temp)[1]*100,2),"%) \n",
                    names(tab_temp[2]), ": ",
                    format(tab_temp[2], big.mark = ","),
                    " (",round(prop.table(tab_temp)[2]*100,2),"%) \n",
                    names(tab_temp[3]), ": ",
                    format(tab_temp[3], big.mark = ","),
                    " (",round(prop.table(tab_temp)[3]*100,2),"%) \n",
                    names(tab_temp[4]), ": ",
                    format(tab_temp[4], big.mark = ","),
                    " (",round(prop.table(tab_temp)[4]*100,2),"%) \n")

## Chikungunya ----
tab_temp <- table(a$C_CRIT_CONF_DESC.DEN[a$CHIKUNGUNYA == "Yes"], useNA = "always")
tab_clin <- table(a$C_APRESENTACAO_CLINICA.CZO[a$CHIKUNGUNYA == "Yes"], useNA = "always")


fp[[13]] <-  paste0("Chikungunya cases in dataset: \n",
                    format(table(a$CHIKUNGUNYA)["Yes"], big.mark = ","),
                    " (",round(prop.table(table(a$CHIKUNGUNYA))["Yes"]*100,2),"%) \n \n",

                    "Chikungunya clinical time : \n",
                    names(tab_clin[1]), ": ",
                    format(tab_clin[1], big.mark = ","),
                    " (",round(prop.table(tab_clin)[1]*100,2),"%) \n",
                    names(tab_clin[2]), ": ",
                    format(tab_clin[2], big.mark = ","),
                    " (",round(prop.table(tab_clin)[2]*100,2),"%) \n",
                    names(tab_clin[3]), ": ", format(tab_clin[3], big.mark = ","),
                    " (",round(prop.table(tab_clin)[2]*100,2),"%) \n \n")

fp[[13]] <-  paste0(fp[[13]],
                    "Cikungunya cases confirmations: \n",
                    names(tab_temp[1]), ": ",
                    format(tab_temp[1], big.mark = ","),
                    " (",round(prop.table(tab_temp)[1]*100,2),"%) \n",
                    names(tab_temp[2]), ": ",
                    format(tab_temp[2], big.mark = ","),
                    " (",round(prop.table(tab_temp)[2]*100,2),"%) \n",
                    names(tab_temp[3]), ": ",
                    format(tab_temp[3], big.mark = ","),
                    " (",round(prop.table(tab_temp)[3]*100,2),"%) \n",
                    names(tab_temp[4]), ": ",
                    format(tab_temp[4], big.mark = ","),
                    " (",round(prop.table(tab_temp)[4]*100,2),"%) \n")

## Zika ----
tab_temp <- table(a$C_CRIT_CONF_DESC.DEN[a$ZIKA == "Yes"], useNA = "always")

fp[[14]] <-  paste0("Zika cases in dataset: \n",
                    format(table(a$ZIKA)["Yes"], big.mark = ","),
                    " (",round(prop.table(table(a$ZIKA))["Yes"]*100,2),"%) \n \n")

fp[[14]] <-  paste0(fp[[14]],
                    "Zika cases confirmations: \n",
                    names(tab_temp[1]), ": ",
                    format(tab_temp[1], big.mark = ","),
                    " (",round(prop.table(tab_temp)[1]*100,2),"%) \n",
                    names(tab_temp[2]), ": ",
                    format(tab_temp[2], big.mark = ","),
                    " (",round(prop.table(tab_temp)[2]*100,2),"%) \n",
                    names(tab_temp[3]), ": ",
                    format(tab_temp[3], big.mark = ","),
                    " (",round(prop.table(tab_temp)[3]*100,2),"%) \n",
                    names(tab_temp[4]), ": ",
                    format(tab_temp[4], big.mark = ","),
                    " (",round(prop.table(tab_temp)[4]*100,2),"%) \n")

## Oropouche ----
tab_temp <- table(a$C_CRIT_CONF_DESC.DEN[a$OROPOUCHE == "Yes"], useNA = "always")

fp[[15]] <-  paste0("Oropouche cases in dataset: \n",
                    format(table(a$OROPOUCHE)["Yes"], big.mark = ","),
                    " (",round(prop.table(table(a$OROPOUCHE))["Yes"]*100,2),"%) \n \n")

fp[[15]] <-  paste0(fp[[15]],
                    "Oropouche cases confirmations: \n",
                    names(tab_temp[1]), ": ",
                    format(tab_temp[1], big.mark = ","),
                    " (",round(prop.table(tab_temp)[1]*100,2),"%) \n",
                    names(tab_temp[2]), ": ",
                    format(tab_temp[2], big.mark = ","),
                    " (",round(prop.table(tab_temp)[2]*100,2),"%) \n",
                    names(tab_temp[3]), ": ",
                    format(tab_temp[3], big.mark = ","),
                    " (",round(prop.table(tab_temp)[3]*100,2),"%) \n",
                    names(tab_temp[4]), ": ",
                    format(tab_temp[4], big.mark = ","),
                    " (",round(prop.table(tab_temp)[4]*100,2),"%) \n")

## Discarded cases ----
a_row <- nrow(a)
a_dis <-
  a %>%
  filter(DENGUE == "No" &
         CHIKUNGUNYA == "No" &
         ZIKA == "No" &
         OROPOUCHE == "No") %>%
  nrow()

fp[[16]] <-  paste0("Discarded cases in dataset: \n", format(a_dis, big.mark = ",") ," (",round( (a_dis / a_row) * 100, 2),"%)")

## Co-infected cases ----

a <- a %>%
  mutate(CO_INFECCAO =
           case_when(
             DENGUE == "Yes" & CHIKUNGUNYA == "Yes" & ZIKA == "No" & OROPOUCHE == "No" ~ "Dengue + Chikungunya",
             DENGUE == "Yes" & CHIKUNGUNYA == "No" & ZIKA == "Yes" & OROPOUCHE == "No"  ~ "Dengue + Zika",
             DENGUE == "Yes" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "Yes" ~ "Dengue + Oropouche",

             DENGUE == "No" & CHIKUNGUNYA == "Yes" & ZIKA == "Yes" & OROPOUCHE == "No" ~ "Chikungunya + Zika",
             DENGUE == "No" & CHIKUNGUNYA == "Yes" & ZIKA == "No" & OROPOUCHE == "Yes" ~ "Chikungunya + Oropouche",
             DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "Yes" & OROPOUCHE == "Yes" ~ "Zika + Oropouche",

             DENGUE == "Yes" & CHIKUNGUNYA == "Yes" & ZIKA == "Yes" & OROPOUCHE == "No" ~ "Dengue + Chikungunya + Zika",
             DENGUE == "Yes" & CHIKUNGUNYA == "Yes" & ZIKA == "No" & OROPOUCHE == "Yes" ~ "Dengue + Chikungunya + Oropouche",
             DENGUE == "Yes" & CHIKUNGUNYA == "No" & ZIKA == "Yes" & OROPOUCHE == "Yes" ~ "Dengue + Zika + Oropouche",

             DENGUE == "No" & CHIKUNGUNYA == "Yes" & ZIKA == "Yes" & OROPOUCHE == "Yes" ~ "Chikungunya + Zika + Oropouche",
             DENGUE == "Yes" & CHIKUNGUNYA == "Yes" & ZIKA == "Yes" & OROPOUCHE == "Yes" ~ "Dengue + Chikungunya + Zika + Oropouche",

             DENGUE == "Yes" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "No" ~ "Dengue", # Ok
             DENGUE == "No" & CHIKUNGUNYA == "Yes" & ZIKA == "No" & OROPOUCHE == "No" ~ "Chikungunya", # Ok
             DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "Yes" & OROPOUCHE == "No" ~ "Zika", # Ok
             DENGUE == "No" & CHIKUNGUNYA == "No" & ZIKA == "No" & OROPOUCHE == "Yes" ~ "Oropouche", # Ok
             .default = "Discarded"
           ),
         CO_INFECCAO = fct_relevel(
           CO_INFECCAO,
           "Discarded")
         )

# a %>%
#   filter(DENGUE == "Yes", CHIKUNGUNYA == "Yes" & ZIKA == "Yes" & OROPOUCHE == "Yes") %>%
#   nrow()
# table(a$CO_INFECCAO)

# fp[[17]] <-  paste0(" Simultaneous infections: \n",
#                     names(tab_co[1]) ,": ",format(tab_co[1], big.mark = ",")," (",round( (tab_co[1] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[2]) ,": ",format(tab_co[2], big.mark = ",")," (",round( (tab_co[2] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[3]) ,": ",format(tab_co[3], big.mark = ",")," (",round( (tab_co[3] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[4]) ,": ",format(tab_co[4], big.mark = ",")," (",round( (tab_co[4] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[5]) ,": ",format(tab_co[5], big.mark = ",")," (",round( (tab_co[5] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[6]) ,": ",format(tab_co[6], big.mark = ",")," (",round( (tab_co[6] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[7]) ,": ",format(tab_co[7], big.mark = ",")," (",round( (tab_co[7] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[8]) ,": ",format(tab_co[8], big.mark = ",")," (",round( (tab_co[8] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[9]) ,": ",format(tab_co[9], big.mark = ",")," (",round( (tab_co[9] / a_row) * 100, 2),"%)\n",
#                     names(tab_co[10]) ,": ",format(tab_co[10], big.mark = ",")," (",round( (tab_co[10] / a_row) * 100, 2),"%)"
# )

### Dengue cases ----
tab_co <- table(a$CO_INFECCAO[a$DENGUE == "Yes"], useNA = "always")
fp[[17]] <-  paste0("Dengue simultaneous infections: \n",
                    names(tab_co[1]) ,": ",format(tab_co[1], big.mark = ",")," (",round( (tab_co[1] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[2]) ,": ",format(tab_co[2], big.mark = ",")," (",round( (tab_co[2] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[3]) ,": ",format(tab_co[3], big.mark = ",")," (",round( (tab_co[3] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[4]) ,": ",format(tab_co[4], big.mark = ",")," (",round( (tab_co[4] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[5]) ,": ",format(tab_co[5], big.mark = ",")," (",round( (tab_co[5] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[6]) ,": ",format(tab_co[6], big.mark = ",")," (",round( (tab_co[6] / sum(tab_co)) * 100, 2),"%)\n"
                    )

### Chik cases ----
tab_co <- table(a$CO_INFECCAO[a$CHIKUNGUNYA == "Yes"], useNA = "always")
fp[[18]] <-  paste0("Chikungunya simultaneous infections: \n",
                    names(tab_co[1]) ,": ",format(tab_co[1], big.mark = ",")," (",round( (tab_co[1] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[2]) ,": ",format(tab_co[2], big.mark = ",")," (",round( (tab_co[2] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[3]) ,": ",format(tab_co[3], big.mark = ",")," (",round( (tab_co[3] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[4]) ,": ",format(tab_co[4], big.mark = ",")," (",round( (tab_co[4] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[5]) ,": ",format(tab_co[5], big.mark = ",")," (",round( (tab_co[5] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[6]) ,": ",format(tab_co[6], big.mark = ",")," (",round( (tab_co[6] / sum(tab_co)) * 100, 2),"%)\n"
)

### Zika cases ----
tab_co <- table(a$CO_INFECCAO[a$ZIKA == "Yes"], useNA = "always")
fp[[19]] <-  paste0("Zika simultaneous infections: \n",
                    names(tab_co[1]) ,": ",format(tab_co[1], big.mark = ",")," (",round( (tab_co[1] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[2]) ,": ",format(tab_co[2], big.mark = ",")," (",round( (tab_co[2] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[3]) ,": ",format(tab_co[3], big.mark = ",")," (",round( (tab_co[3] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[4]) ,": ",format(tab_co[4], big.mark = ",")," (",round( (tab_co[4] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[5]) ,": ",format(tab_co[5], big.mark = ",")," (",round( (tab_co[5] / sum(tab_co)) * 100, 2),"%)\n"
)

### Oropouche cases ----
tab_co <- table(a$CO_INFECCAO[a$OROPOUCHE == "Yes"], useNA = "always")
fp[[20]] <-  paste0("Oropouche simultaneous infections: \n",
                    names(tab_co[1]) ,": ",format(tab_co[1], big.mark = ",")," (",round( (tab_co[1] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[2]) ,": ",format(tab_co[2], big.mark = ",")," (",round( (tab_co[2] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[3]) ,": ",format(tab_co[3], big.mark = ",")," (",round( (tab_co[3] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[4]) ,": ",format(tab_co[4], big.mark = ",")," (",round( (tab_co[4] / sum(tab_co)) * 100, 2),"%)\n",
                    names(tab_co[5]) ,": ",format(tab_co[5], big.mark = ",")," (",round( (tab_co[5] / sum(tab_co)) * 100, 2),"%)\n"
)

# Creating plot ----

fluxp <- "
  digraph {
  # Type of graph and parameters
  graph [layout = dot, compound = true, ranksep = .25, nodesep = .95, rankdir = TD, splines = ortho]

  # Declaring standard knots
  node [fillcolor = 'white', shape = box, style = 'rounde, filled', fixedsize = false, fontsize = 14, fontname = 'Helvetica']

  node [fillcolor = 'white']
  '@@2'; '@@5'; '@@8'

  node [fillcolor = 'white',  fontsize = 20]
  '@@16'

  node [fillcolor = 'pink',  fontsize = 20]
  '@@10'; '@@11'

  # Declaring Dengue  knots
  node [fillcolor = '#D1E8FF',  fontsize = 20]
  '@@1'; '@@3'; '@@12'; '@@17'

  # Declaring Chik knots
  node [fillcolor = '#FFF3E0',  fontsize = 20]
  '@@4'; '@@6'; '@@13'; '@@18'

  # Declaring Oropouche and Zika knots
  node [fillcolor = '#E8F5E9', fontsize = 20]
  '@@8'; '@@9'; '@@14'; '@@19'

  # Declarnado as setas
  edge [color = '#555555', arrowhead = vee, arrowsize = 0.8, penwidth = 1.2]

  '@@1' -> '@@2' ; '@@1' -> '@@3'
  '@@4' -> '@@5' ; '@@4' -> '@@6'
  '@@7' -> '@@8' ; '@@7' -> '@@9'
  '@@6' -> '@@10' ; '@@9' -> '@@10'
  '@@3' -> '@@11' ; '@@10' -> '@@11'
  '@@11' -> {'@@12' '@@13' '@@14' '@@15' '@@16'}
  '@@12' -> '@@17' ;
  '@@13' -> '@@18' ;
  '@@14' -> '@@19' ;
  '@@15' -> '@@20'
  }
  [1]: fp[[1]]
  [2]: fp[[2]]
  [3]: fp[[3]]
  [4]: fp[[4]]
  [5]: fp[[5]]
  [6]: fp[[6]]
  [7]: fp[[7]]
  [8]: fp[[8]]
  [9]: fp[[9]]
  [10]: fp[[10]]
  [11]: fp[[11]]
  [12]: fp[[12]]
  [13]: fp[[13]]
  [14]: fp[[14]]
  [15]: fp[[15]]
  [16]: fp[[16]]
  [17]: fp[[17]]
  [18]: fp[[18]]
  [19]: fp[[19]]
  [20]: fp[[20]]
"
# DiagrammeR::grViz(fluxp)

# Exporting grViz
grViz(fluxp) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_pdf(paste0(result_path,"Flowdiagram_",Sys.Date(),".pdf"))

grViz(fluxp) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_png(width = 480 * 8.3, height = 480 * 3.8,
           file = paste0(result_path,"Flowdiagram_",Sys.Date(),".png"))


## PLot with Gal data ----
fluxp_gal <- "
  digraph {
  # Type of graph and parameters
  graph [layout = dot, compound = true, ranksep = .25, nodesep = .9, rankdir = TD]

  # Declaring  knots
  node [shape = rectangle, fixedsize = false, fontsize = 14, fontname = Arial]
  '@@2' '@@5' '@@8' '@@22' '@@26' '@@30'

  # Declaring  knots
  node [shape = rectangle, fixedsize = false, fontsize = 20, fontname = Arial]
  '@@1' '@@3' '@@4' '@@6' '@@7' '@@9' '@@10' '@@11' '@@12' '@@13' '@@14' '@@15' '@@16' '@@17' '@@18' '@@19' '@@20'

  # Declarnado as setas
  edge [arrowhead = vee]

  '@@1' -> '@@2' ; '@@1' -> '@@3'
  '@@4' -> '@@5' ; '@@4' -> '@@6'
  '@@7' -> '@@8' ; '@@7' -> '@@9'
  '@@6' -> '@@10' ; '@@9' -> '@@10'
  '@@3' -> '@@11' ; '@@10' -> '@@11'
  '@@11' -> '@@12' ; '@@11' -> '@@13'
  '@@11' -> '@@14' ; '@@11' -> '@@15' ; '@@11' -> '@@16'
  '@@12' -> '@@17' ;
  '@@13' -> '@@18' ;
  '@@14' -> '@@19' ;
  '@@15' -> '@@20';
  '@@21' -> '@@22' ; '@@21' -> '@@23' ; '@@23' -> '@@24'; '@@24' -> '@@3'
  '@@25' -> '@@26' ; '@@25' -> '@@27' ; '@@27' -> '@@28'; '@@28' -> '@@6'
  '@@29' -> '@@30' ; '@@29' -> '@@31' ; '@@31' -> '@@32'; '@@32' -> '@@9'
  }
  [1]: fp[[1]]
  [2]: fp[[2]]
  [3]: fp[[3]]
  [4]: fp[[4]]
  [5]: fp[[5]]
  [6]: fp[[6]]
  [7]: fp[[7]]
  [8]: fp[[8]]
  [9]: fp[[9]]
  [10]: fp[[10]]
  [11]: fp[[11]]
  [12]: fp[[12]]
  [13]: fp[[13]]
  [14]: fp[[14]]
  [15]: fp[[15]]
  [16]: fp[[16]]
  [17]: fp[[17]]
  [18]: fp[[18]]
  [19]: fp[[19]]
  [20]: fp[[20]]
  [21]: fp[[21]]
  [22]: fp[[22]]
  [23]: fp[[23]]
  [24]: fp[[24]]
  [25]: fp[[25]]
  [26]: fp[[26]]
  [27]: fp[[27]]
  [28]: fp[[28]]
  [29]: fp[[29]]
  [30]: fp[[30]]
  [31]: fp[[31]]
  [32]: fp[[32]]
"
# DiagrammeR::grViz(fluxp)

# Exporting grViz
grViz(fluxp_gal) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_pdf(paste0(result_path,"Flowdiagram_withGAL_",Sys.Date(),".pdf"))

grViz(fluxp_gal) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_png(width = 480 * 17, height = 480 * 8,,
           file = paste0(result_path,"Flowdiagram_withGAL_",Sys.Date(),".png"))

# fp2 <- fp
# fp <- fp2

fluxp_colored <- "
digraph {
  # Configura��es Gerais do Gr�fico
  graph [layout = dot, rankdir = TD, nodesep = 0.5, ranksep = 0.5, splines = ortho]

  # Estilo padr�o para os N�s (Caixas)
  node [fontname = 'Helvetica', shape = box, style = 'rounded, filled', fixedsize = false,
        fillcolor = '#F5F5F5', color = '#333333', fontsize = 14]

  # Estilo das Setas
  edge [color = '#555555', arrowhead = vee, arrowsize = 0.8, penwidth = 1.2]

  node [fillcolor = 'white']
  '@@2'; '@@5'; '@@8'; '@@22'; '@@26'; '@@30'

  # Estilo para as caixas match (Rosa Suave)
  node [fillcolor = '#FFF0F5', fontsize = 20]
  '@@10'; '@@11'

  node [fillcolor = '#F5F5F5',  fontsize = 20]
  '@@16'

  # Estilo espec�fico para Dengue (Azul Suave)
  node [fillcolor = '#D1E8FF']
  '@@1'; '@@3'; '@@12'; '@@17' '@@21'; '@@23'; '@@24'

  # Estilo espec�fico para Chik (Cinza/Aten��o)
  node [fillcolor = '#FFF3E0', fontsize = 20]
  '@@4'; '@@6'; '@@13'; '@@18'; '@@25'; '@@27'; '@@28'

  # Estilo para Zika e Oropouche (Verde Suave)
  node [fillcolor = '#E8F5E9', fontsize = 20]
  '@@8'; '@@9'; '@@14'; '@@19'; '@@29'; '@@31'; '@@32'


  # Conex�es (Mantendo a tua l�gica original)
  '@@1' -> '@@2' ; '@@1' -> '@@3'
  '@@4' -> '@@5' ; '@@4' -> '@@6'
  '@@7' -> '@@8' ; '@@7' -> '@@9'
  '@@6' -> '@@10' ; '@@9' -> '@@10'
  '@@3' -> '@@11' ; '@@10' -> '@@11'

  '@@11' -> {'@@12' '@@13' '@@14' '@@15' '@@16'}

  '@@12' -> '@@17' ;
  '@@13' -> '@@18' ;
  '@@14' -> '@@19' ;
  '@@15' -> '@@20';

  '@@21' -> '@@22' ; '@@21' -> '@@23' ; '@@23' -> '@@24'; '@@24' -> '@@3'
  '@@25' -> '@@26' ; '@@25' -> '@@27' ; '@@27' -> '@@28'; '@@28' -> '@@6'
  '@@29' -> '@@30' ; '@@29' -> '@@31' ; '@@31' -> '@@32'; '@@32' -> '@@9'

  # For�ar alinhamento horizontal dos grupos iniciais
  { rank = same; '@@1'; '@@4'; '@@7' }
}

[1]: fp[[1]]
[2]: fp[[2]]
[3]: fp[[3]]
[4]: fp[[4]]
[5]: fp[[5]]
[6]: fp[[6]]
[7]: fp[[7]]
[8]: fp[[8]]
[9]: fp[[9]]
[10]: fp[[10]]
[11]: fp[[11]]
[12]: fp[[12]]
[13]: fp[[13]]
[14]: fp[[14]]
[15]: fp[[15]]
[16]: fp[[16]]
[17]: fp[[17]]
[18]: fp[[18]]
[19]: fp[[19]]
[20]: fp[[20]]
[21]: fp[[21]]
[22]: fp[[22]]
[23]: fp[[23]]
[24]: fp[[24]]
[25]: fp[[25]]
[26]: fp[[26]]
[27]: fp[[27]]
[28]: fp[[28]]
[29]: fp[[29]]
[30]: fp[[30]]
[31]: fp[[31]]
[32]: fp[[32]]
"

# DiagrammeR::grViz(fluxp_colored)

# Exporting grViz
grViz(fluxp_colored) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_pdf(paste0(result_path,"Flowdiagram_withGAL_color_",Sys.Date(),".pdf"))

grViz(fluxp_colored) %>%
  export_svg %>%
  charToRaw %>%
  rsvg_png(width = 480 * 17, height = 480 * 8,
           file = paste0(result_path,"Flowdiagram_withGAL_color_",Sys.Date(),".png"))

suppressWarnings(
  rm(teste,teste2,zw_matches,chik_key,coposite_id,key_matches,w_n,y_n,z_n, wg_n,yg_n,zg_n, zw, w,y,z, wg, zg, yg, ygal_matches, wgal_matches, zgal_matches, a_row, a_dis, den_minor, zwy_matches, tab_temp, tab_co_den, tab_co_chik, tab_co, fp2)
)


while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") {detach(2)}

save.image(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))


