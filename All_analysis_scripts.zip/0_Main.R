library(callr)

# file.copy(from = "C:/Users/emman/OneDrive/Oropouche/Analise/",
#           to = "D:/Banco/Oropouche/",
#           overwrite = TRUE,
#           recursive = TRUE,
#           copy.mode = TRUE,
#           copy.date = TRUE)

# detaching allpackages, clearing grpah windows and enviroment
while(search()[2] != "tools:rstudio") detach(2)
rm(list = ls())
graphics.off()

# avoinding the midnigth problem
task_date <- Sys.Date()

# setting default paths
script_path <- "~/Projetos/Oropouche/scripts/"
data_path   <- "~/Projetos/Oropouche/dados/"
result_path <- "~/Projetos/Oropouche/resultados/"

# script_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/scripts/"
# data_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/dados/"
# result_path <- "C:/Users/emman/OneDrive/Oropouche/Analise/resultados/"

# script_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/scripts/"
# data_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/dados/"
# result_path <- "C:/Users/elry/OneDrive/Oropouche/Analise/resultados/"

# Scripts to execute
scripts_to_run <- c(
  "Functions.R",
  # "1_Import.R",
  # "2_Edit_Den.R",
  # "3_Edit_Chik.R",
  # "4_Edit_Zik.R",
  # "5_GAL_time_series_plots.R",
  # "6_Labels.R",
  # "7_Tables.R",
  # "8_Fluxogram_replicates_join.R",
  # "9_Edit_final.R",
  # "10_Labels_final.R",
  # "11_Time_series_plots.R",
  # "12_Tables2.R",
  # "13_Imputations.R",
  "15_RF_reg_Oropouche.R",
  "17_RF_reg_Chikungunya.R",
  "19_RF_reg_Dengue.R",
  "20_RF_reg_Zika.R",
  "21_Additional.R"
)

# Log file
log_file <- paste0(result_path, "Log_Oropouche_", Sys.Date(), ".txt")
cat("=== Starting project script files: ", as.character(Sys.time()), "===\n\n", file = log_file)

# Function with callR to execute scripts, Log e Treat Errors
clean_execution <- function(script_name, s_path, d_path, r_path, log_path, fixed_date) {

  start_time <- Sys.time()
  message("\n >>> [", format(start_time, "%H:%M:%S"), "] Running: ", script_name)
  full_script_path <- paste0(s_path, script_name)

  execution_result <- tryCatch({
    callr::r(function(sp, dp, rp, f_path, f_date) {

      # O PULO DO GATO: Sobrescrevemos a fun��o Sys.Date no sub-processo
      Sys.Date <- function() return(f_date)

      script_path <<- sp
      data_path   <<- dp
      result_path <<- rp

      source(f_path, encoding = "ISO-8859-1")
      return("Success")
    },
    args = list(
      sp = s_path,
      dp = d_path,
      rp = r_path,
      f_path = full_script_path,
      f_date = fixed_date # Passamos a data que capturamos no in�cio
    ),
    show = TRUE)

  }, error = function(e) {
    return(paste("ERROR:", e$message))
  })

  # Log e Verifica��o (como voc� j� tem no c�digo)
  cat(paste("Script:", format(script_name, width = 30), "| Status:", execution_result, "\n"),
      file = log_path, append = TRUE)

  if(grepl("ERROR", execution_result)) {
    stop("Interrupted.")
  }
}

# Main execution loop
for (s in scripts_to_run) {
  clean_execution(s, script_path, data_path, result_path, log_file, task_date)
}

cat("\n=== Processing finished: ", as.character(Sys.time()), "===\n", file = log_file, append = TRUE)
message("\n >>> Processing finished. Check log at: ", log_file)