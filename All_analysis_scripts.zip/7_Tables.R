# Table 1 version 1.5 was returning a bug at table header
# install.packages("devtools")
# remove.packages("table1")
# devtools::install_version(
#   package = "table1",
#   version = "1.4.0",
#   repos = "https://cloud.r-project.org/"
# )

suppressMessages(library(tidyverse))
suppressMessages(library(flextable))
# suppressMessages(install.packages("table1"))
# suppressMessages(library(table1, lib.loc = .libPaths()[1]))
suppressMessages(library(table1, lib.loc = "/usr/local/lib/R/site-library"))

load(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# Dengue ----
TableDen <-
  table1(~ CNS_valid +
           IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           DL_IGM_DENGUE_RESULT +
           DL_NS1_RESULTADO +
           DL_I_RESULT +
           DL_RTPCR_RESULT +
           DL_RTPCR_SOROTIPO +
           DL_HISTOPATOLOGIA +
           DL_IMUNOHISTOQUIMICA +
           C_CRIT_CONF_DESC +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO +
           AG_HIPOTENSAO +
           AG_PLAQUETAS +
           AG_VOMITOS_PERSISTENTES +
           AG_DOR_ABDOMINAL +
           AG_LETARGIA_IRR +
           AG_SANG_MUCOSA +
           AG_HEMATOCRITO +
           AG_HEPATOMEGALIA +
           AG_ACUMULO_LIQUIDOS +
           AG_PULSO +
           AG_PA_CONVERGENTE +
           AG_TEMPO_CAPILAR +
           AG_AC_LIQUIDOS +
           AG_TAQUICARDIA +
           AG_EXTREMIDADES_FRIAS +
           AG_HIPOTENSAO_ARTERIAL +
           AG_HEMATEMESE +
           AG_MELENA +
           AG_METRORAGIA_VOLUMOSA +
           AG_SANGRAMENTO_SNC +
           AG_AST_ALT +
           AG_MIOCARDITE +
           AG_ALTER_CONSCIENCIA +
           AG_OUTROS_ORGAOS | C_CLASSIFIC,
         data = den %>% filter(!is.na(C_CLASSIFIC) & C_CLASSIFIC != "Chikungunya"),
         render.categorical = bm_render_cat,
         render.missing = bm_render_na) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Dengue dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by case diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation; CNS number = cart�o nacional do SUS (used as notification ID); CNS = central nervous system; AST = aspartate aminotransferase; ALT = alanine aminotransferase; RT-PCR = reverse transcription polymerase chain reaction.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# TableDen

save_as_docx(
  values = list(TableDen) ,
  path = paste0(result_path,"Table_Dengue_crude_data_",Sys.Date(),".docx"),
)

# Chikungunya ----
TableChik <-
  table1(~ CNS_valid +
           IDADE_ANOS_DT_NOTIFIC +
           IDADE_CAT +
           SEXO +
           GESTANTE +
           RACA_COR +
           ETNIA +
           PCD +
           MORADOR_RUA +
           ESCOLARIDADE +
           ZONA +
           C_AUTOCTONE +
           DC_FEBRE +
           DC_CEFALEIA +
           DC_VOMITO +
           DC_DOR_COSTAS +
           DC_ARTRITE +
           DC_PETEQUIAS +
           DC_PROVA_LACO +
           DC_MIALGIA +
           DC_EXANTEMA +
           DC_NAUSEAS +
           DC_CONJUTIVITE +
           DC_ARTRALGIA_INTENSA +
           DC_LEUCOPENIA +
           DC_DOR_RETROORBITAL +
           DC_DIABETES +
           DC_HEPATOPATIAS +
           DC_HIPER_ARTERIAL +
           DC_AUTO_IMUNES +
           DC_HEMATOLOGICAS +
           DC_RENAL_CRONICA +
           DC_ACIDO_PEPTICA +
           DL_S1 +
           DL_S2 +
           DL_PRNT +
           DL_IGM_DENGUE_RESULT +
           DL_NS1_RESULTADO +
           DL_I_RESULT +
           DL_RTPCR_RESULT +
           # DL_RTPCR_SOROTIPO +
           DL_HISTOPATOLOGIA +
           DL_IMUNOHISTOQUIMICA +
           C_CRIT_CONF_DESC +
           C_EVOLUC_CASO +
           H_HOSPITALIZACAO +
           C_APRESENTACAO_CLINICA| C_CLASSIFIC,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na,
         data = chik %>%
           filter(!is.na(C_CLASSIFIC) &
                    str_detect(C_CLASSIFIC, "Dengue", negate = T))) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Chikungunya dataset variables (including epidemiological, clinical at presentations and disease progressions) counts and frequencies by case diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation; CNS number = cart�o nacional do SUS (used as notification ID); PRNT = plaque reduction neutralization test: RT-PCR = reverse transcription polymerase chain reaction.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# TableChik

save_as_docx(
  values = list(TableChik) ,
  path = paste0(result_path,"Table_Chik_crude_data_",Sys.Date(),".docx"),
)

# Oropouche and Zika ----
TableZik <-
  table1(~ CNS_valid +
         IDADE_ANOS_DT_NOTIFIC +
         IDADE_CAT +
         SEXO +
         GESTANTE +
         RACA_COR +
         ETNIA +
         PCD +
         MORADOR_RUA +
         ESCOLARIDADE +
         ZONA +
         AUTOCTONE +
         CRIT_CONF_DESC +
         EVOLUC_CASO | C_CLASSIFIC,
         render.categorical = bm_render_cat,
         render.missing = bm_render_na,
         data = zik %>%
           filter(!is.na(C_CLASSIFIC))) %>%
  t1flex() %>%
  autofit() %>%
  set_caption("Zika and Oropouche dataset variables (including epidemiological only) counts and frequencies by case diagnostic investigation outcome.") %>%
  add_footer_lines("IQR = interquartile range; SD = Standard deviation; CNS number = cart�o nacional do SUS (used as notification ID).") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
# TableZik

save_as_docx(
  values = list(TableZik) ,
  path = paste0(result_path,"Table_Zika_crude_data_",Sys.Date(),".docx"),
)


while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save.image(paste0(data_path,"Signs_symptoms_",Sys.Date(),".RData"))
