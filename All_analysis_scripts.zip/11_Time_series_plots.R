suppressMessages(library(tidyverse))
suppressMessages(library(tsibble))

load(paste0(data_path,"Final_data_signs_symptoms_",Sys.Date(),".RData"))

# Call load aditional functions
source(paste0(script_path,"Functions.R"), encoding = "ISO-8859-1")

# important to give context and select dates as limits
# for development and validation subsets
# back to script 8 to set limits

# table(is.na(a$SEMANA_DIAGNOSTICO))

ts_data <-
  a %>%
  # mutate(SEMANA_DIAGNOSTICO = yearweek(DATA_DIAGNOSTICO, week_start = 7)) %>%
  group_by(SEMANA_DIAGNOSTICO) %>%
  summarize(
    Dengue = sum(DENGUE_01),
    Chikungunya = sum(CHIKUNGUNYA_01),
    Zika = sum(ZIKA_01),
    Oropouche = sum(OROPOUCHE_01)) %>%
  tsibble(index = SEMANA_DIAGNOSTICO) %>%
  fill_gaps("Dengue" = 0,
            "Chikungunya" = 0,
            "Zika" = 0,
            "Oropouche" = 0,
            .full = TRUE)

ts_plot <-
  ggplot(ts_data, aes(x = SEMANA_DIAGNOSTICO)) +
  geom_area(aes(y = get("Dengue"), fill = "Dengue"),
            alpha = .15) +
  geom_area(aes(y = get("Chikungunya"),
                fill = "Chikungunya"),
            alpha = .25) +
  geom_area(aes(y = get("Zika"),
                fill = "Zika"),
            alpha = .35) +
  geom_area(aes(y = get("Oropouche"),
                fill = "Oropouche"),
            alpha = .35) +
  xlab("Epidemiological week calendar") +
  ylab(paste0("Case count")) +
  theme_light() +
  theme(legend.position = "top",
        legend.box = "horizontal",
        legend.title = element_blank(),
        legend.background = element_rect(colour = 'white', fill = 'white'),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8)) +
  guides(col = guide_legend(ncol = 4)) +
  scale_x_yearweek(date_minor_breaks = "1 week",
                   date_breaks = "8 week") # date_labels = "%W\n%Y"

png(paste0(result_path,"Time_series_original_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
print(ts_plot)
dev.off()

png(paste0(result_path,"Time_series_reduced_",Sys.Date(),".png"), width = 480*8, height = 480*4, res = 72 * 5)
print(ts_plot + coord_cartesian(ylim = c(0,1000)))
dev.off()

while(search()[2] != "tools:rstudio" & search()[2] != "package:stats") detach(2)

save(ts_data, ts_plot, file = paste0(data_path,"Time_series_data_",Sys.Date(),".RData"))

# rm(ts_data, ts_plot)
