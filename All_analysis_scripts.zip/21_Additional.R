suppressMessages(library(tidyverse))
suppressMessages(library(givitiR))
suppressMessages(library(flextable))

# script_path <- "~/Projetos/Oropouche/scripts/"
# data_path   <- "~/Projetos/Oropouche/dados/"
# result_path <- "~/Projetos/Oropouche/resultados/"

 # load("~/Projetos/Oropouche/dados/Dengue_rf_reg_calibration_2026-03-17.RData")
 # load("~/Projetos/Oropouche/dados/Oropouche_rf_reg_calibration_2026-03-17.RData")
 # load("~/Projetos/Oropouche/dados/Chikungunya_rf_reg_calibration_2026-03-17.RData")

# Binding all calibration belts ----
load(paste0(data_path,"Dengue_rf_reg_calibration_",Sys.Date(),".RData"))
load(paste0(data_path,"Chikungunya_rf_reg_calibration_",Sys.Date(),".RData"))
load(paste0(data_path,"Oropouche_rf_reg_calibration_",Sys.Date(),".RData"))

png(paste0(result_path,"All_rf_reg_belt_",Sys.Date(),".png"),
    width = 480*8, height = 480*12, res = 72 * 8)

par(mfrow = c(3,2))
plot(dengue.reg.model.train.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Dengue scaled predictions - train data", #Scaled - train dataset"
     )
# mtext("A", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

plot(dengue.reg.model.test.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Dengue scaled predictions - test data", # Scaled - test dataset"
     )
# mtext("B", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

plot(chikungunya.reg.model.train.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Chikungunya scaled predictions - train data",# Scaled - train dataset"
     )
# mtext("C", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

plot(chikungunya.reg.model.test.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Chikungunya scaled predictions - test data",# Scaled - test dataset"
     )
# mtext("D", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

plot(oropouche.reg.model.train.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Oropouche scaled predictions - train data", #Scaled - train dataset"
     )
# mtext("E", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

# mtext("A: Dengue scaled predictions - train data; B: Dengue scaled predictions - test data; C: Chikungunya scaled predictions - train data; D: Chikungunya scaled predictions - test data; E: oropouche scaled predictions - train data; F: Oropouche scaled predictions - test data",
#       side = 1,
#       adj = 0,
#       line = 4,
#       cex = .5,
#       font = 1,
#       xpd = NA)

plot(oropouche.reg.model.test.plat.cb,
     ylab = "Actual Probability",
     xlab = "Predicted Probability",
     main = "Oropouche scaled predictions - test data", #Scaled - test dataset"
     )
#mtext("F", side = 3, adj = 0, line = 1, cex = 1.2, font = 2)

dev.off()

# Binding all performances ----
load(file = paste0(data_path,"Oropouche_peformance_",Sys.Date(),".RData"))
load(file = paste0(data_path,"Chikungunya_peformance_",Sys.Date(),".RData"))
load(file = paste0(data_path,"Dengue_peformance_",Sys.Date(),".RData"))

performance.rf.reg.all <-
    bind_rows("Dengue"      = performance.rf.reg.den,
              "Chikungunya" = performance.rf.reg.chik,
              "Oropouche"   = performance.rf.reg.oro,
              .id = "Outcome") %>%
    flextable() %>%
    compose(
        i = ~ Statistics == "R2",
        j = "Statistics",
        value = as_paragraph("R", as_sup("2"))
    ) %>%
    bold(part = "header") %>%
    merge_v(j = "Outcome") %>%
    valign(j = "Outcome", valign = "top") %>% #
    hline(i = ~ Statistics == "Emax",
          border = officer::fp_border(color = "black", width = 1.5)) %>%
    hline_top(border = officer::fp_border(color = "black", width = 1.5),
                 part = "body") %>%
    hline_bottom(border = officer::fp_border(color = "black", width = 1.5),
                 part = "body") %>%
    colformat_double(digits = 3) %>%
    autofit() %>%
    set_caption("Random forest regression selected performance measures estimated from the predicted probabilities, scaled predicted probabilities of all outcomes on different datasets.") %>%
    add_footer_lines("C (ROC) = c statistic or area under the ROC curve; Eavg = average error; Train = dataset split used in development; Test = dataset split used in exterval validation; E90 = percentile 90 of prediction error; Emax = maximum prediction error. Scaled predictions were obtained from Plat (logistic) method") %>%
    font(fontname = "Times New Roman", part = "all") %>%
    fontsize(size = 10, part = "body") %>%
    fontsize(size = 8, part = "footer") %>%
    align(j = 2:5, align = "center", part = "all") %>%
    padding(padding = 1.2, part = "all") %>%
    set_table_properties(width = .99, layout = "autofit")
performance.rf.reg.all
save_as_docx(
    values = list(performance.rf.reg.all) ,
    path = paste0(result_path,"Performance_reg_All_",Sys.Date(),".docx"),
)
