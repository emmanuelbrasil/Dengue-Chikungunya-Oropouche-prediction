# Function to check if the unique ID is valid and good to be a join key
# cns is dataset column with the CNS number ID
is_cns <- function(cns) {

  # Remove all non number characters
  cns <- str_replace_all(cns, "[^0-9]", "")

  # Convert to vector integer d�gits
  digits <- lapply(str_split(cns, ""), as.numeric)

  # Weighted sum
  wighted_sum <- sapply(seq_along(digits), function(i) suppressWarnings(sum(digits[[i]] * 15:1)))

  # Validation (Module 11)
  remaining <- wighted_sum %% 11

  # # There was a prefix rule but they do not pass in external validation
  # prefix <- sapply(seq_along(digits), function(i) digits[[i]][1])
  #
  # # Setting true or false but could be simpler
  # output <- case_when(
  #   prefix %in% c(1, 2) & remaining == 0 ~ TRUE,
  #   prefix %in% c(7, 8, 9) & remaining == 0 ~ TRUE,
  #   .default = FALSE
  # )
  output <- case_when(
    cns == 0 ~ FALSE,
    cns == "0" ~ FALSE,
    remaining == 0 ~ TRUE,
    .default = FALSE)

  output
}
# x <- den %>%
#   mutate(CNS_TEXTO = as.character(CARTAO_SUS)) %>%
#   filter(stringr::str_detect(CNS_TEXTO, pattern = "^1|^2")) %>%
#   slice_sample(n = 10) %>%
#   pull(CNS_TEXTO)
# x <- den %>%
#   mutate(CNS_TEXTO = as.character(CARTAO_SUS)) %>%
#   filter(stringr::str_detect(CNS_TEXTO, pattern = "^7|^8|^9")) %>%
#   slice_sample(n = 10) %>%
#   pull(CNS_TEXTO)
# x <- c(206010794200003,1234567891011,201358568620009,1234567891011,207339053520004,1234567891011,165939515020002,16014950729,111111111111,1234567891011)
# is_cns(x)




# Functions to check replicates in dataset acording to CNS and first sympotoms date
# identifies replicates id same CNS and onset date are less than 14 days apart
# Returns the same dataset with a logical column IS_REPLICATE
# df = dataframe
# id_col = column unique ID
# date_col = column with date of first symptoms
replicates_dates <- function(df, id_col = "CARTAO_SUS", date_col = "DATA_DIAGNOSTICO") {

  df %>%
   # filter(CNS_valid) %>%
    # 1. Pr�-processamento
    mutate(
      !!sym(id_col) := as.character(!!sym(id_col))) %>%
    filter(!is.na(!!sym(id_col))) %>%

    # 2. Agrupamento e Ordena��o Temporal (CR�TICO)
    group_by(!!sym(id_col)) %>%
    arrange(!!sym(id_col), !!sym(date_col)) %>%

    # 3. C�lculo da Diferen�a de Tempo (em dias)
    mutate(
      DATA_DIAG_ANTERIOR = lag(!!sym(date_col)),
      DIF_DAYS = as.numeric(!!sym(date_col) - DATA_DIAG_ANTERIOR, units = "days"),
      IS_REPLICATE = ifelse(is.na(DIF_DAYS), FALSE, DIF_DAYS < 14)
    ) %>%

    # 4. C�lculo da Completude do Registro (Contagem de NA) - LINHA CORRIGIDA
    # O across() soma os NAs em todas as colunas, exceto nas colunas de identifica��o
    # e nas colunas tempor�rias criadas.
    # mutate(
    #   NA_COUNT = rowSums(
    #     is.na(
    #       select(
    #         .data, # Usa .data para referenciar o data frame completo (antes de criar as tempor�rias)
    #         -all_of(c(id_col, date_col)) # Exclui ID e Data
    #       )
    #     )
    #   )
    # ) %>%
    #
    # # 5. Identifica��o do Registro Mais Completo (Se for duplicata)
    # mutate(
    #   REGISTRO_PRINCIPAL = if_else(
    #     IS_DUPLICATA == TRUE,
    #     NA_COUNT == min(NA_COUNT[IS_DUPLICATA == TRUE], na.rm = TRUE),
    #     TRUE
    #   )
    # ) %>%

    ungroup() %>%
    # filter(IS_DUPLICATA == TRUE) %>%

    select(
      !!sym(id_col), !!sym(date_col), DATA_DIAG_ANTERIOR, DIF_DAYS,
      IS_REPLICATE,  everything() # NA_COUNT, REGISTRO_PRINCIPAL,
    ) %>%
    arrange(!!sym(id_col), !!sym(date_col))
}
# den_dup <- replicates_dates(den)
# den_dup %>%
#   filter(IS_REPLICATE) %>%
#   select(CARTAO_SUS, CNS_valid, DATA_DIAGNOSTICO, C_CLASSIFIC, IS_REPLICATE) %>%
#   arrange(CARTAO_SUS, DATA_DIAGNOSTICO)


# Function to check CNS matches in one dataset in another
# considering that initial symptoms 14 days apart in the diferent datasets
# is the same case
# df_a dataset to match
# df_b dataset to match against
# id_col unique ID
# date_col date of the first symptoms
# days tolerance to consider the same case
approx_date_match <- function(df_a,
                              df_b,
                              id_col = "CARTAO_SUS",
                              date_col = "DATA_DIAGNOSTICO",
                              days = 14) {


  # 2. Jun��o dos bancos apenas pelo CARTAO_SUS (inner_join)
  # Cria todos os pares poss�veis de (A_CNS, A_DATA) vs (B_CNS, B_DATA)
  partial_join <- df_a %>%
    inner_join(df_b,
               by = id_col,
               suffix = c("_A", "_B"),
               relationship = "many-to-many") %>%

    # 3. Filtro Condicional: Verifica se a diferen�a absoluta da data � <= 14 dias
    mutate(
      DIF_DATE = abs(!!sym(paste0(date_col, "_A")) - !!sym(paste0(date_col, "_B")))
    ) %>%
    filter(DIF_DATE <= days(days))

  # 4. Contagem dos Casos Correspondes (pelo menos uma correspond�ncia)
  # Usamos distinct() para contar apenas o registro original (df_a) que encontrou match.
  case_match <- partial_join %>%
    distinct(!!sym(id_col), !!sym(paste0(date_col, "_A"))) %>%
    nrow()

  # 5. C�lculo da Propor��o
  # total_a <- nrow(df_a)
  # prop <- case_match / total_a

  # Retorna uma tabela de propor��o similar � sua sa�da original
  # prop_table <- c(1 - prop, prop)
  # names(prop_table) <- c("FALSE", "TRUE")
  # prop_table
  case_match
}
## Zika and Oropouche in Dengue matches
# approx_date_match(z, y)
## Chikungunya in Dengue matches
# approx_date_match(w, y)
## Zika and Oropouche in Chikungunya matches
# approx_date_match(z, w)




# similar to approx_date_match
# Creates a dataset with matches of the id_col and approximate
# date_col considerng the dates
# Creates and additional KEY column to furtehr joinng the datasets of interest
# df_a dataset to match
# df_b dataset to match against
# id_col unique ID
# date_col date of the first symptoms
# days tolerance to consider the same case
# suffix_a suffix to mark date_col in df_a
# suffix_b suffix to mark date_col in df_b
tag_best_match <- function(df_a,
                           df_b,
                           suffix_a = "_A",
                           suffix_b = "_B",
                           id_col = "CARTAO_SUS",
                           date_col_a = "DATA_DIAGNOSTICO",
                           date_col_b = "DATA_DIAGNOSTICO",
                           days = 14) {
  # Nomes das colunas de data esperados
  date_col_a <- paste0(date_col_a, suffix_a)
  date_col_b <- paste0(date_col_b, suffix_b)


  # Prepara��o dos dados (assumindo que j� est�o no formato Date, mas repetindo para seguran�a)
  # df_a <-
  #   df_a %>%
  #   mutate(across(all_of(date_col), dmy), !!sym(id_col) := as.character(!!sym(id_col)))
  #
  # df_b <-
  #   df_b %>%
  #   mutate(across(all_of(date_col), dmy), !!sym(id_col) := as.character(!!sym(id_col)))

  # 1. Jun��o para criar todos os pares poss�veis (Many-to-Many)
  merged <-
    df_a %>%
    inner_join(df_b,
               by = id_col,
               suffix = c(suffix_a, suffix_b),
               relationship = "many-to-many") %>%

    # 2. C�lculo da Diferen�a de Tempo
    mutate(
      DATA_DIAG_A = !!sym(date_col_a),
      DATA_DIAG_B = !!sym(date_col_b),
      DIF_DIAS = as.numeric(abs(DATA_DIAG_A - DATA_DIAG_B), units = "days")
    ) %>%

    # 3. Filtro Temporal
    filter(DIF_DIAS <= days) %>%

    # 4. Agrupamento para encontrar o MELHOR match (Data mais pr�xima)
    group_by(!!sym(id_col), DATA_DIAG_A) %>% # Agrupa pelo registro de origem

    # Prioriza o match com a menor DIF_DIAS
    filter(DIF_DIAS == min(DIF_DIAS, na.rm = TRUE)) %>%

    # 5. Se houver empate (mesma DIF_DIAS), pega o primeiro (ou usa a l�gica de completude)
    slice(1) %>%
    ungroup() %>%

    # Seleciona as chaves do registro correspondente do banco B
    select(
      !!sym(id_col),
      DATA_DIAG_A,
      !!sym(id_col), # CNS do B (redundante, mas �til para verifica��o)
      DATA_DIAG_B # DATA_DIAGNOSTICO do B (a chave do DEN ou CHIK)
    ) %>%
    mutate(KEY = paste(!!sym(id_col),DATA_DIAG_A, DATA_DIAG_B, sep = "_"),
           DATA_SINTOMAS = pmin(DATA_DIAG_A, DATA_DIAG_B, na.rm = TRUE)) %>%
    select(
      !!sym(id_col),
      !!sym(date_col_a) := DATA_DIAG_A,
      !!sym(date_col_b) := DATA_DIAG_B,
      KEY,
      DATA_SINTOMAS
    )

  merged
}
# test <- tag_best_match(df_a = z, df_b = w, suffix_a = "_zik",suffix_b = "_chik")

# Version of the best_tag_match including a unique identifier in the first step and a combinatios of identifier plus date to match labt dataset with the notification dataset.
tag_best_match_lab <- function(df_notif,
                               df_lab,
                               id_cns = "CARTAO_SUS",
                               id_num = "NUM_NOTIFICACAO",
                               date_ref = "DATA_NOTIFICACAO",
                               res_col = "GAL_DEN_RTPCR_RESULT",
                               days_limit = 14) {
  # df_lab = wg
  # df_notif = w

  if(any(is.na(df_notif[[id_num]]))) {
    warning("There is at least one missing at the notification number at the notification data")
  }
  if(any(is.na(df_lab[[id_num]]))) {
    warning("There is at least one missing at the notification number at the lab data")
  }
  if(any(duplicated(df_lab[[id_num]]))) {
    warning(paste0("There is ",table(duplicated(df_lab[[id_num]]))["TRUE"]," replicated notification number at the lab data"))
  }
  # Editing the the notifications dataset
  notif_clean <-
    df_notif %>%
    mutate(across(all_of(c(id_cns, id_num)), as.character)) %>%
    select(all_of(c(id_cns, id_num, date_ref))) %>%
    select(CARTAO_SUS = !!sym(id_cns),
           NUM_NOTIFICACAO = !!sym(id_num),
           DATA_NOTIFICACAO = !!sym(date_ref))

  # Editing the the lab dataset by notification number
  lab_clean_num <-
    df_lab %>%
    mutate(across(all_of(c(id_cns, id_num)), as.character),
           res_priority = if_else(!!sym(res_col) == "Positive", 1, 2),
           match_type = "BY_NUM") %>%
    filter(!is.na(!!sym(id_num)) & !!sym(id_num) != "" & nchar(!!sym(id_num)) == 7) %>%
    select(all_of(c(id_cns, id_num, date_ref, res_col)), res_priority, match_type) %>%
    group_by(!!sym(id_num)) %>%
      arrange(!!sym(id_num), res_priority) %>%
      slice(1) %>%
    ungroup() %>%
        # Normalizar nomes para o bind_rows
    select(CARTAO_SUS = !!sym(id_cns),
           NUM_NOTIFICACAO = !!sym(id_num),
           DATA_NOTIFICACAO = !!sym(date_ref),
           RESULTADO_FINAL = !!sym(res_col),
           res_priority,
           match_type)

  # Editing the the lab dataset by notification date
  # lab_clean_date %>%
  #   filter(CARTAO_SUS %in%
  # (lab_clean_date %>%
  #   filter(duplicated(CARTAO_SUS)) %>%
  #   # print(n = 300) %>%
  #   pull(CARTAO_SUS))) %>%
  #   arrange(CARTAO_SUS, DATA_NOTIFICACAO)
  lab_clean_date <-
    df_lab %>%
    mutate(across(all_of(c(id_cns, id_num)), as.character),
           res_priority = if_else(!!sym(res_col) == "Positive", 1, 2),
           match_type = "BY_DATE") %>%
    filter((is.na(!!sym(id_num)) | !!sym(id_num) == "" | nchar(!!sym(id_num)) != 7) &
             (is_cns(!!sym(id_cns)) & !is.na(!!sym(date_ref)))) %>%
    select(all_of(c(id_cns, id_num, date_ref, res_col)), res_priority, match_type) %>%
    # if date is filled correctly this is redundant
    # if date is diverse then this picks either the date from the positive test
    # or the first date. Which I cant tell in advance which is present in the SINAN data
    # Ozzie's shot in the dark is playing Hahahahhaah
    arrange(!!sym(id_num), !!sym(date_ref)) %>%
    group_by(!!sym(id_cns)) %>%
    mutate(diff_days = as.numeric(!!sym(date_ref) - lag(!!sym(date_ref)), units = "days"),
           diff_days = replace_na(diff_days, 0),
           new_event = if_else(diff_days > 14, 1, 0),
           id_event = cumsum(new_event)) %>%
    group_by(!!sym(id_cns), id_event) %>%
    arrange(!!sym(id_num), id_event, res_priority) %>%
    slice(1) %>%
    ungroup() %>%
    # Normalizar nomes para o bind_rows
    select(CARTAO_SUS = !!sym(id_cns),
           NUM_NOTIFICACAO = !!sym(id_num),
           DATA_NOTIFICACAO = !!sym(date_ref),
           RESULTADO_FINAL = !!sym(res_col),
           res_priority,
           match_type)

  # Binding the tow data from lab data

  lab_clean <-
    bind_rows(
      lab_clean_num,
      lab_clean_date
    )

  # lab_clean %>%
  #   pull(NUM_NOTIFICACAO) %>%
  #   duplicated() %>%
  #   table()
  #
  # lab_clean %>%
  #   filter(match_type == "BY_NUM" &
  #            NUM_NOTIFICACAO %in%
  # (lab_clean %>%
  #   filter(duplicated(NUM_NOTIFICACAO)) %>%
  #   # print(n = 300) %>%
  #   pull(NUM_NOTIFICACAO))) %>%
  #   arrange(NUM_NOTIFICACAO, CARTAO_SUS, DATA_NOTIFICACAO)

  # Match por NUM_NOTIFICACAO ---
  all_matches_num <-
    notif_clean %>%
    inner_join(lab_clean %>%
                 filter(match_type == "BY_NUM"),
               by = "NUM_NOTIFICACAO",
               suffix = c("_not", "_lab")) %>%
    # nrow(all_matches)
    mutate(NUM_NOTIFICACAO = as.double(NUM_NOTIFICACAO),
           CARTAO_SUS = coalesce(CARTAO_SUS_not,CARTAO_SUS_lab),
           DATA_NOTIFICACAO = coalesce(DATA_NOTIFICACAO_not, DATA_NOTIFICACAO_lab)) %>%
    select(CARTAO_SUS,
           NUM_NOTIFICACAO,
           DATA_NOTIFICACAO,
           RESULTADO_FINAL,
           match_type,
           -CARTAO_SUS_not,
           -CARTAO_SUS_lab,
           # -DATA_NOTIFICACAO_not,
           # -DATA_NOTIFICACAO_lab,
           -res_priority)

  # Match por data mais cns ---
  all_matches_date <-
    notif_clean %>%
    inner_join(lab_clean %>%
                 filter(match_type == "BY_DATE"),
               by = c("CARTAO_SUS","DATA_NOTIFICACAO"),
               suffix = c("_not", "_lab")) %>%
    # nrow(all_matches)
    mutate(NUM_NOTIFICACAO = coalesce(NUM_NOTIFICACAO_lab, NUM_NOTIFICACAO_not),
           NUM_NOTIFICACAO = as.double(NUM_NOTIFICACAO)) %>%
    select(CARTAO_SUS,
           NUM_NOTIFICACAO,
           DATA_NOTIFICACAO,
           RESULTADO_FINAL,
           match_type,
           -NUM_NOTIFICACAO_not,
           -NUM_NOTIFICACAO_lab,
           -res_priority)

  # Found that there are some lines CNS and DATE combinations
  # that have
  all_matches <-
    bind_rows(
      all_matches_num,
      all_matches_date
    ) %>%
    mutate(KEY = paste(NUM_NOTIFICACAO,CARTAO_SUS,DATA_NOTIFICACAO, sep = "_")) %>%
    arrange(KEY, factor(match_type, levels = c("BY_NUM","BY_DATE"))) %>%
    distinct(CARTAO_SUS,DATA_NOTIFICACAO, .keep_all = TRUE)

  return(all_matches)
}
# rm(all_matches, all_matches_date, all_matches_num, lab_clean_date, lab_clean_num, df_lab, df_notif, lab_clean, match_num, notif_clean, teste_matches, date_ref, days_limit, id_cns, id_num, res_col)

# render categorical with big mark for table1::table1
bm_render_cat <- function(x){
  render.categorical.default(x, big.mark = ",", digits = 0, digits.pct = 1)
}

# render missing with big mark for table1::table1
bm_render_na <- function(x){
  render.missing.default(x, big.mark = ",", digits = 0, digits.pct = 1)
}

# Plot proximity of random forest model with 3D scatter plot
# model= random forest model
# xdata = predictors dataset
# y_data = outcome dataset
# Graphical parameters passed to scatterplot3d::scatterplot3d
plot_3d_mds <- function(model,
                        x_data,
                        y_data,
                        title,
                        pch = 20,
                        cex.symbols = 0.8,
                        grid = TRUE,
                        box = FALSE,
                        angle = 45,
                        highlight.3d = FALSE,
                        type = "p") {
  # Extrair proximidade e calcular MDS 3D
  prox <- predict(model,
                  newdata = x_data,
                  proximity = TRUE)$proximity
  mds <- cmdscale(1 - prox, k = 3)

  # Definir cores com transpar�ncia
  # Azul (No) e Vermelho (Yes)
  col <- if_else(y_data == "Yes", "#FF000066", "#0000FF22")

  # Criar o gr�fico 3D
  s3d <- scatterplot3d(x = mds[,1],
                       y = mds[,2],
                       z = mds[,3],
                       color = col,
                       pch = pch,       # Ponto s�lido
                       cex.symbols = cex.symbols,
                       main = title,
                       xlab = "Dimension 1", ylab = "Dimension 2", zlab = "Dimension 3",
                       grid = grid,
                       box = box,
                       angle = angle,
                       type = type,
                       highlight.3d = highlight.3d)     # �ngulo de vis�o (podes ajustar)
}

# model = a class random forest object or a ranger object
# the train or test dataset to make predictions woth the moedel
# ggplot grafical parameters passed to theme
## title
## title size -> plot.title element size
## axis size -> axis.title element size
## text size -> axis.text.y element size
# model = oropouche.class.model
plot_all_partial_effects <- function(model,
                                     data,
                                     title = "Partial dependence plots",
                                     title.size = 7,
                                     axis.size = 6,
                                     text.size = 6,
                                     legend.size = 0.2,
                                     caption.width = 110) {
  cl <- makePSOCKcluster(parallel::detectCores())
  registerDoParallel(cl)

  # 1. Identificar vari�veis do modelo
  if(any(class(model) == "ranger")) {
    vars_model <- model$forest$independent.variable.names
  }
  if(class(model) == "randomForest"){
    vars_model <- names(model$forest$xlevels)
  }
  data_df <- as.data.frame(data)

  # 2. Gerar Rodap� Global
  etiquetas_todas <- var_label(data_df[vars_model]) %>%
    map_chr(~ ifelse(is.null(.), "No label", as.character(.)))

  fixed_vals <- data_df %>%
    select(all_of(vars_model)) %>%
    summarise(across(everything(), function(x) {
      if(is.numeric(x)) return(round(mean(x, na.rm = TRUE), 2))
      return(names(sort(table(x), decreasing = TRUE))[1])
    }))

  rodape_txt <- map2_chr(etiquetas_todas, unlist(fixed_vals), ~ paste0(.x, " = ", .y)) %>%
    paste(collapse = " | ") %>%
    paste0("Fixed values (Mean/Mode): ", .) %>%
    str_wrap(width = caption.width)

  # 3. Fun��o interna para cada gr�fico
  make_single_plot <- function(v_name) {
    pd_data <- partial(model,
                       pred.var = v_name,
                       which.class = "Yes",
                       prob = TRUE,
                       train = data_df,
                       progress = FALSE, # parallel TRUE disables progress bar
                       parallel = TRUE,
                       paropts = list(.packages = c("ranger","randomForest"),
                                      .export = "data_df"))

    label_x <- etiquetas_todas[v_name]
    is_num <- is.numeric(data_df[[v_name]])

    p <- ggplot(pd_data, aes(x = .data[[v_name]], y = yhat))

    # Definimos o tema base primeiro!
    p <- p + theme_light()

    if(is_num) {
      p <- p +
        geom_line(color = "red", linewidth = 1) +
        geom_point(size = 0.5)
    } else {
      p <- p +
        geom_col(aes(fill = .data[[v_name]]), alpha = 0.8, color = "black") +
        scale_fill_brewer(palette = "Set1") +
        theme(
          axis.text.x = element_blank(), # Agora funciona!
          axis.ticks.x = element_blank(),
          legend.position = "right", # Ativado para substituir o texto do eixo
          legend.title = element_blank(),
          legend.text = element_text(size = text.size),
          legend.key.size = unit(legend.size, "cm")
        )
    }

    # Customiza��es finais de t�tulos e fontes
    p + labs(title = label_x, # Usando a etiqueta como t�tulo do mini-gr�fico
             y = "Prob.",
             x = NULL) + # X nulo j� que temos t�tulo e legenda
      theme(
        plot.title = element_text(size = title.size, face = "bold"),
        axis.title = element_text(size = axis.size),
        axis.text.y = element_text(size = text.size)
      )
  }

  # 4. Gerar lista e organizar
  plot_list <- map(vars_model, make_single_plot)

  final_layout <- wrap_plots(plot_list) +
    plot_annotation(
      title = title,
      caption = rodape_txt,
      theme = theme(
        plot.title = element_text(size = 12, face = "bold"),
        plot.caption = element_text(
          size = 7,
          hjust = 0,
          vjust = 1,
          color = "gray30",
          lineheight = 1.1)
      )
    )
  stopCluster(cl)
  registerDoSEQ()
  return(final_layout)
}


# Tabulate different permutation models significance
# model_list a names list of rf models
# data_x = either training or testng predictors dataset
# label = either training or testing cahracter to colum label
# n_perm =  number of permutations
perm_models <- function(model_list, data_x, label, n_perm = 100) {
  result_list <- list()

  for (model_name in names(model_list)) {
    cat("Processing permutation for:", model_name, "...\n")
    res <- rf.significance(model_list[[model_name]],
                           xdata = data_x,
                           nperm = n_perm,
                           do.trace = FALSE)

    if( model_list[[model_name]]$type == "classification" ) {

      result_list[[model_name]] <- c(`Number of permutations:` = res$nPerm,
                                     `Model signifiant at p:` = res$pValueThreshold,
                                     `p value:` = res$pValue,
                                     `Model OOB error:` = res$test.OOB,
                                     `Random OOB error:` = median(res$RandOOB),
                                     `min random global error:` = res$RandOOB[2],
                                     `max random global error:` = res$RandOOB[1],
                                     `min random within class error:` = res$RandMaxError[2],
                                     `max random within class error:` = res$RandMaxError[1])

    }
  }

  # Converte para data frame e adiciona a coluna de contexto (Training/Testing)
  output <- as.data.frame(do.call(cbind, result_list)) %>%
    rownames_to_column("Metrics") %>%
    mutate(Data = label) %>%
    select(Data, Metrics, everything())

  return(output)
}

plot_rf_importance <- function(rf_model,
                               original_data,
                               title = "Variable Importance") {
  # rf_model <- oropouche.class.model
  # 1. Prepara��o dos dados com tratamento de labels
  if(class(rf_model) == "ranger") {
    imp_df <- as.data.frame(rf_model$variable.importance) %>%
      rownames_to_column("var_name") %>%
      rename(imp = 2) %>%
      mutate(
        # Busca o label; se n�o existir, usa o nome da vari�vel
        label = map_chr(var_name, ~ as.character(labelled::var_label(original_data[[.x]]) %||% .x)),
        is_selected = TRUE,
        label = fct_reorder(label, imp) # Ordena��o autom�tica
      )
  } else{ # if not ranger should a rf.modelSel object
    imp_df <- as.data.frame(rf_model$importance) %>%
      rownames_to_column("var_name") %>%
      rename(imp = 2) %>%
      mutate(
        # Busca o label; se n�o existir, usa o nome da vari�vel
        label = map_chr(var_name, ~ as.character(labelled::var_label(original_data[[.x]]) %||% .x)),
        is_selected = var_name %in% rownames(rf_model$sel.importance),
        label = fct_reorder(label, imp) # Ordena��o autom�tica
      )
  }

  # 2. Constru��o do Gr�fico (Lollipop Plot)
  ggplot(imp_df, aes(x = imp, y = label, color = is_selected)) +
    # Substitu�do 'size' por 'linewidth' para evitar o warning
    geom_segment(aes(x = 0, xend = imp, yend = label),
                 linewidth = 0.6,
                 alpha = 0.4) +
    geom_point(size = 3.5) +
    scale_color_manual(
      values = c("TRUE" = "#2E8B57", "FALSE" = "#CD5C5C"), # Cores mais elegantes (SeaGreen e IndianRed)
      labels = c("TRUE" = "Selected", "FALSE" = "Dropped"),
      name = "Status"
    ) +
    labs(
      title = title,
      # subtitle = paste("Model type:", rf_model$rf.final$type),
      x = "Importance Score",
      y = NULL
    ) +
    theme_light(base_family = "sans") +
    theme(
      axis.text.y = element_text(size = 10, color = "black"),
      legend.position = "bottom",
      panel.grid.major.y = element_blank(), # Remove linhas horizontais para limpar o visual
      plot.title = element_text(face = "bold")
    )
}

# Execu��o
# plot_rf_importance(rf.class.oro, b_oro, "Oropouche Fever: all explored variables Importance")
#
# # Salvar de forma simples com ggsave (substitui o tiff() e dev.off())
# ggsave(
#   filename = paste0(result_path, "Importance_Oropouche_", Sys.Date(), ".tiff"),
#   plot = p,
#   width = 8, height = 10, units = "in", dpi = 300, compression = "lzw"
# )


# object is a TGROC output
# y ia a ui.nonpar ibject output
update.inconclusive.tgroc <- function(object, y) {
  object$np.inconclusive[,1] <- y[1:2]
  object$np.inconclusive[,1]

  row_replace <- c("Lower inconclusive","Upper inconclusive")
  col_replace <- c("Sensitivity", "Se.inf.cl", "Se.sup.cl", "Specificity", "Sp.inf.cl", "Sp.sup.cl","PLR", "PLR.inf.cl", "PLR.sup.cl")

  object$np.inconclusive[row_replace[1],col_replace] <- object$SS[which.min(abs(object$np.inconclusive[1,1] - object$SS$test.values)), col_replace]

  object$np.inconclusive[row_replace[2],col_replace] <- object$SS[which.min(abs(object$np.inconclusive[2,1] - object$SS$test.values)),col_replace]

  object
}



# To find automatically a reasonable minimum level of inconclusive limit
# x is the output from SS or BS or NS
inc.value <- function(x, min.desired = 0.8) {
  output <-
    case_when(
      Se.equals.Sp(x)$Sensitivity >= .95 ~ 0.99,
      Se.equals.Sp(x)$Sensitivity >= .90 ~ 0.95,
      Se.equals.Sp(x)$Sensitivity >= .85 ~ 0.90,
      Se.equals.Sp(x)$Sensitivity >= .80 ~ 0.85,
      Se.equals.Sp(x)$Sensitivity >= .75 ~ 0.80,
      Se.equals.Sp(x)$Sensitivity >= .70 ~ 0.75,
      Se.equals.Sp(x)$Sensitivity >= .65 ~ 0.70,
      Se.equals.Sp(x)$Sensitivity >= .60 ~ 0.65,
      Se.equals.Sp(x)$Sensitivity >= .55 ~ 0.60,
      Se.equals.Sp(x)$Sensitivity >= .50 ~ 0.55,
      Se.equals.Sp(x)$Sensitivity >= .45 ~ 0.50,
      Se.equals.Sp(x)$Sensitivity >= .40 ~ 0.45,
      Se.equals.Sp(x)$Sensitivity >= .35 ~ 0.40
    )
  output <- if_else(output < min.desired, min.desired, output)
  output
}
