# Estou pensando em manter a estrat�gia inicial de divis�o dos sets e em seguida fazer com que um delineamento caso controle pareado no tempo e colocar a semana como preditor.Mas talvez fazer uma amostragem totalmente aleat�ria resolva do mesmo jeito.

# install.packages(c("car","reshape2"))
# install.packages("~/AMORE_0.2-16.tar.gz", repos = NULL, type = "source")
# install.packages("~/DiagnosisMed_0.2.9.2.tar.gz", repos = NULL, type = "source")
# install.packages("~/UncertainInterval_0.7.0.tar.gz", repos = NULL, type = "source")

# install.packages("rfUtilities")
suppressMessages(library(tidyverse))
suppressMessages(library(labelled))
# suppressMessages(library(plotly))
# suppressMessages(library(scatterplot3d))
suppressMessages(library(randomForest))
suppressMessages(library(cluster))
suppressMessages(library(rfUtilities))
suppressMessages(library(pdp))
suppressMessages(library(rms))
suppressMessages(library(DiagnosisMed))
suppressMessages(library(UncertainInterval))
suppressMessages(library(flextable))
suppressMessages(library(patchwork))

load(paste0(data_path,"Imputed_data_",Sys.Date(),".RData"))
rm(fit_impute)


# Declaring predictors ----
predictors <- c(
  "SEMANA_NUM",
  "IDADE_ANOS_DT_NOTIFIC",
  "SEXO",
  "GESTANTE", #
  "RACA_COR",
  # "PCD", # this predictor has almost no variance
  # "MORADOR_RUA", # this predictor has almost no variance
  "ESCOLARIDADE",
  "ZONA",
  "DC_FEBRE",
  "DC_CEFALEIA",
  "DC_VOMITO",
  "DC_DOR_COSTAS",
  "DC_ARTRITE",
  "DC_PETEQUIAS",
  "DC_PROVA_LACO",
  "DC_MIALGIA",
  "DC_EXANTEMA",
  "DC_NAUSEAS",
  "DC_CONJUTIVITE",
  "DC_ARTRALGIA_INTENSA",
  "DC_LEUCOPENIA",
  "DC_DOR_RETROORBITAL",
  "DC_DIABETES",
  "DC_HEPATOPATIAS",
  "DC_HIPER_ARTERIAL",
  "DC_AUTO_IMUNES",
  "DC_HEMATOLOGICAS",
  "DC_RENAL_CRONICA",
  "DC_ACIDO_PEPTICA"
)
# length(predictors)

# bi <- bi %>% select(all_of(predictors))
# save(bi , file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))
# load(file = paste0(data_path,"Imputed_dataset_",Sys.Date(),".RData"))

# Preparing for balance the forests ----

# Oropouche ----
# n_cases <- floor((sum(bi %>%
#                      filter(VALIDATION_3 == "Train") %>%
#                      pull(OROPOUCHE_01))))
# size <- c("No" = n_cases , "Yes" = n_cases)



# table(bi %>%
#        filter(VALIDATION_3 == "Development") %>%
#        pull(OROPOUCHE_01))

x_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  select(all_of(predictors))
y_train <- bi %>%
  filter(VALIDATION_3 == "Train") %>%
  pull(OROPOUCHE)
#
x_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  select(all_of(predictors))
y_test <- bi %>%
  filter(VALIDATION_3 == "Test") %>%
  pull(OROPOUCHE)

rm(bi)
gc()

# Tuning mtry ----
set.seed(1753109393)
Sys.time(); time_ini <- Sys.time()
rf.oro.tuned <-
  tuneRF(x = x_train,
         y = y_train,
         # xtest = x_test,
         # ytest = y_test,
         proximity = FALSE,
         improve = 0.001,
         ntreeTry = 350,
         mtryStart = 15,
         stepFactor = 1.5,
         doBest = TRUE,
         plot = TRUE,
         corr.bias = TRUE,
         final.model = FALSE,
         parsimony = TRUE,
         keep.inbag = FALSE,
         localImp = FALSE,
         sampsize = size,
         replace = TRUE,
         strata = y_train,
         seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
# x <- plot(rf.oro.tuned)
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# the black is the overall error
# plot(rf.oro.tuned)
# rf.oro.tuned
# rf.oro.tuned$mtry

# CV Featured selection ----
# With rfcv there is no way to know which variables are being removed.
# set.seed(1753109393)
# oro_cv_feature <- rfcv(x_train,
#                        y_train,
#                        cv.fold = 10,
#                        scale = FALSE,
#                        step = -1, # If scale FALSE than step must be negative
#                        recursive = TRUE,
#                        corr.bias = TRUE,
#                        mtry = function(p) max(1, p))
# with(oro_cv_feature,
#      plot(n.var,
#           error.cv,
#           log = "x",
#           type = "o",
#           lwd = 2,
#           xlab="Number of variables",
#           ylab="CV Error"))
#      axis(1, at = 1:28, labels = FALSE, tcl = -.2)

# table(bi %>%
#   filter(VALIDATION_3 == "Train") %>%
#   pull(OROPOUCHE))
#
# table(bi %>%
#         filter(VALIDATION_3 == "Test") %>%
#         pull(OROPOUCHE))
#
# lapply(bi %>%
#   filter(VALIDATION_3 == "Train") %>%
#   select(all_of(predictors)), table)
#
# lapply(bi %>%
#          filter(VALIDATION_3 == "Test") %>%
#          select(all_of(predictors)), table)

# RF class model selection ----
 ##  First modelSel selection ----
size <- c("No" = 1000 , "Yes" = 1000)
set.seed(1753109393)
Sys.time() ; time_ini <- Sys.time()
rf.class.oro <- rf.modelSel(x = x_train[,setdiff(names(x_train),"SEMANA_NUM")],
                      y = y_train,
                      # xtest = x_test[,setdiff(names(x_test),"SEMANA_NUM")],
                      # ytest = y_test,
                      do.trace = 116,
                      proximity = FALSE,
                      plot = FALSE,
                      corr.bias = FALSE,
                      final.model = TRUE,
                      keep.inbag = FALSE,
                      ntree = 350,
                      mtry = rf.oro.tuned$mtry,
                      localImp = FALSE,
                      replace  = TRUE,
                      sampsize = size,
                      strata = y_train,
                      norm.votes = FALSE,
                      seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
# rf.class.oro
# simple plot standardized importance
# plot(rf.class.oro, imp = "sel")
# plot(rf.class.oro, imp = "all")
# nrow(rf.class.oro$sel.importance)
# nrow(rf.class.oro$importance)

oropouche.class.freq.model = rf.class.oro2$rf.final

# Plot Errors by tree generations
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# plot(oropouche.class.model)
# Mean squared error residuals?
# oropouche.class.model$err.rate[nrow(oropouche.class.model$err.rate),]
# 2x2 OOB table or confusion matrix
# oropouche.class.model$confusion
# Intercept e slopes corrigido:
# oropouche.class.model$votes

##  Week modelSel selection ----
set.seed(1753109393)
Sys.time() ; time_ini <- Sys.time()
rf.class.oro.week <- rf.modelSel(x = x_train,
                          y = y_train,
                          # xtest = x_test,
                          # ytest = y_test,
                          do.trace = 116,
                          proximity = FALSE,
                          plot = FALSE,
                          corr.bias = TRUE,
                          final.model = TRUE,
                          keep.inbag = FALSE,
                          ntree = 350,
                          mtry = rf.oro.tuned$mtry,
                          localImp = FALSE,
                          replace  = TRUE,
                          sampsize = size,
                          strata = y_train,
                          norm.votes = TRUE,
                          seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
oropouche.class.week.model = rf.class.oro.week$rf.final

# rf.class.oro.week
# simple plot standardized importance
# plot(rf.class.oro.week, imp = "sel")
# plot(rf.class.oro.week, imp = "all")
# nrow(rf.class.oro.week$sel.importance)
# nrow(rf.class.oro.week$importance)

# Plot Errors by tree generations
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# plot(oropouche.class.week.model)
# Mean squared error residuals?
# oropouche.class.week.model$err.rate[nrow(oropouche.class.week.model$err.rate),]
# 2x2 OOB table or confusion matrix
# oropouche.class.week.model$confusion
# Intercept e slopes corrigido:
# oropouche.class.week.model$votes

## Importance frequency selection----
oro_week_imp_freq <- rf.imp.freq(x = oropouche.class.week.model, p = 0.05, plot = FALSE)
predictors2 <- oro_week_imp_freq$frequency$vars[oro_week_imp_freq$frequency$var.freq != 0]
rm(oro_week_imp_freq)

set.seed(1753109393)
Sys.time() ; time_ini <- Sys.time()
rf.class.oro2 <- rf.modelSel(x = x_train[,predictors2],
                          y = y_train,
                          # xtest = x_test,
                          # ytest = y_test,
                          do.trace = 116,
                          proximity = FALSE,
                          plot = FALSE,
                          corr.bias = TRUE,
                          final.model = TRUE,
                          keep.inbag = FALSE,
                          ntree = 350,
                          mtry = rf.oro.tuned$mtry,
                          localImp = FALSE,
                          replace  = TRUE,
                          sampsize = size,
                          strata = y_train,
                          norm.votes = TRUE,
                          seed = 1753109393)
time_end1 <- Sys.time() ; difftime(time_end1, time_ini, units = "mins")
oropouche.class.freq.model = rf.class.oro2$rf.final
# rf.class.oro2
# simple plot standardized importance
# plot(rf.class.oro2, imp = "sel")
# plot(rf.class.oro2, imp = "all")
# nrow(rf.class.oro$sel.importance)
# nrow(rf.class.oro$importance)

# Plot Errors by tree generations
# the green is the Yes category (False positive - sensitivyt)
# and the red is the No category (False negative - specificty)
# plot(rf.class.oro2$rf.final)
# Mean squared error residuals?
# rf.class.oro2$rf.final$err.rate[nrow(rf.class.oro2$rf.final$err.rate),]
# 2x2 OOB table or confusion matrix
# rf.class.oro2$rf.final$confusion
# Intercept e slopes corrigido:
# rf.class.oro2$rf.final$votes

## Saving class models ----

save(oropouche.class.freq.model,
     oropouche.class.week.model,
     oropouche.class.model,
     file = paste0(data_path,"Oropouche_rf_class_models_",Sys.Date(),".RData"))

# load(file = paste0(data_path,"Oropouche_rf_reg_",Sys.Date(),".RData"))

## Perfomance comparison  ----
### Week model ----
####OOB confusion matrix (Train) ----
diag.rf.class.oro.week <-
  diagnosis(t(oropouche.class.week.model$confusion[,1:2]))$results %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever selected performance measures from the out of bag comnfusion matrix (epidemiological week in the initial predictors combination).") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")


#### Test dataset ----
diag.rf.class.oro.week.test <-
  diagnosis(ref = y_test,
            test = predict(oropouche.class.week.model,
                           newdata = x_test,
                           type = "class"))$result %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever selected performance measures with the test dataset (epidemiological week in the initial predictors combination).") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")

save_as_docx(
  values = list(diag.rf.class.oro.week,
                diag.rf.class.oro.week.test) ,
  path = paste0(result_path,"Table_SeSp_class_week_Oropouche_",Sys.Date(),".docx"),
)


### Selction model ----
#### OOB confusion matrix (Train) ----
diag.rf.class.oro <-
  diagnosis(t(oropouche.class.model$confusion[,1:2]))$result %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever selected performance measures from the out of bag comnfusion matrix (with importance frequency selected predictors).") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")

#### Test dataset ----
diag.rf.class.oro.test <-
  diagnosis(ref = y_test,
            test = predict(oropouche.class.model,
                           newdata = x_test,
                           type = "class"))$result %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever selected performance measures with the test dataset (epidemiological week in the initial predictors combination).") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")


save_as_docx(
  values = list(diag.rf.class.oro,
                diag.rf.class.oro.test) ,
  path = paste0(result_path,"Table_SeSp_class_Oropouche_",Sys.Date(),".docx"),
)

### Frequency selected model ----
### OOB confusion matrix (Train)----
diag.rf.class.oro2 <-
  diagnosis(t(oropouche.class.freq.model$confusion[,1:2]))$result %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class out of bag selected performance measures for the random forest Oropouche fever prediction from importance frequency selected predictors combination.") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")

#### Test dataset ----
diag.rf.class.oro2.test <-
  diagnosis(ref = y_test,
            test = predict(oropouche.class.freq.model,
                           newdata = x_test,
                           type = "class"))$result %>%
  rownames_to_column(var = "Statistics") %>%
  flextable() %>%
  set_header_labels(
    lower.cl = "95% lower cl",
    upper.cl = "95% upper cl"
  ) %>%
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Statistics == "Sample size:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever selected performance measures with the test dataset (epidemiological week in the initial predictors combination).") %>%
  add_footer_lines("cl = confidence limit") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")

save_as_docx(
  values = list(diag.rf.class.oro2,
                diag.rf.class.oro2.test) ,
  path = paste0(result_path,"Table_SeSp_class_freq_Oropouche_",Sys.Date(),".docx"),
)

### AUC R2 and mean error ----

#### Initial model
##### Train set
performance.rf.class.oro <-
val.prob(y = if_else(y_train == "Yes",1,0),
         p = pmin(pmax(predict(oropouche.class.model,
                     newdata = x_train,
                     type = "prob")[,"Yes"], 0.0000001),0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")]
##### Test set
performance.rf.class.oro <- bind_rows(performance.rf.class.oro,
val.prob(y = if_else(y_test == "Yes",1,0),
         p = pmin(pmax(predict(oropouche.class.model,
                     newdata = x_test,
                     type = "prob")[,"Yes"], 0.0000001),0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")])

#### Initial model with weeks
##### Train set
performance.rf.class.oro <-
  bind_rows(performance.rf.class.oro,
            val.prob(y = if_else(y_train == "Yes",1,0),
                     p = pmin(
                           pmax(
                             predict(oropouche.class.week.model,
                                 newdata = x_train,
                                 type = "prob")[,"Yes"],
                             0.0000001),
                           0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")])

##### Test set
performance.rf.class.oro <-
  bind_rows(performance.rf.class.oro,
            val.prob(y = if_else(y_test == "Yes",1,0),
                     p = pmin(
                           pmax(
                             predict(oropouche.class.week.model,
                                 newdata = x_test,
                                 type = "prob")[,"Yes"],
                             0.0000001),
                           0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")])

#### Frequency selected
##### Train set
performance.rf.class.oro <-
  bind_rows(performance.rf.class.oro,
            val.prob(y = if_else(y_train == "Yes",1,0),
                     p = pmin(
                          pmax(
                            predict(rf.class.oro2$rf.final,
                                 newdata = x_train,
                                 type = "prob")[,"Yes"],
                            0.0000001),
                          0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")])
##### Test set
performance.rf.class.oro <-
  bind_rows(performance.rf.class.oro,
            val.prob(y = if_else(y_test == "Yes",1,0),
                     p = pmin(
                           pmax(
                             predict(rf.class.oro2$rf.final,
                                 newdata = x_test,
                                 type = "prob")[,"Yes"],
                             0.0000001),
                           0.9999999))[c("C (ROC)","R2","Intercept","Slope","Eavg")])

performance.rf.class.oro <-
bind_cols(Model = c("Sel","Sel","Week","Week","Freq","Freq"),
          Sets = c("Train","Test","Train","Test","Train","Test"),
          performance.rf.class.oro) %>%
  flextable() %>%
  autofit() %>%
  set_caption("Random forest selected performance measures estimated from the predicted probabilities of the different alternative RF class models with the different datasets.") %>%
  add_footer_lines("Eavg = average error; Train = dataset split used in development; Test = dataset split used in exterval validation; Week = RF model with epidemiological week in the initail predictors combination; Sel = RF model without epidemiological week in the initail predictors combination; Freq = RF model with predictors combination selected from importance frequency.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")

  save_as_docx(
    values = list(performance.rf.class.oro) ,
    path = paste0(result_path,"Performance_class_Oropouche_",Sys.Date(),".docx"),
  )

## Proximity ----
# In the initial randam small dataset to test the scritps
# It was possible to see a separation in a 3D plot
# But with the full data proximity explodes the RAM memory

# MDSplot(oropouche.class.model, y_train, palette = c("#0000FF44", "#FF0000FF"))
# MDSplot(oropouche.class.freq.model, y_train, palette = c("#0000FF44", "#FF0000FF"))
# MDSplot(oropouche.class.week.model, y_train, palette = c("#0000FF44", "#FF0000FF"))

# Proximity with ggplot and 3D with plotly
# prox <- predict(oropouche.class.model,
#                newdata = x_test,
#                proximity = FALSE)$proximity
# mds <- cmdscale(1 - prox, k = 2)
#
# ggplot(
#        tibble(`Dimension 1` = mds[,1],
#               `Dimension 2` = mds[,2],
#               Class = y_test),
#        aes(x = `Dimension 1`,
#            y = `Dimension 2`,
#            color = Class)) +
#     geom_point(alpha = 0.25) +
#     scale_color_manual(values = c("blue", "red")) +
#     labs(title = "Orpouche class model - multi-dimensional scaling plot of proximity") +
#     theme_light()

# rm(p, prox, mds)

# prox <- predict(oropouche.class.model,
#                 newdata = x_test,
#                 proximity = FALSE)$proximity
# mds <- cmdscale(1 - prox, k = 3)
#
# plot_data <- tibble(
#   `Dimension 1` = mds[,1],
#   `Dimension 2` = mds[,2],
#   `Dimension 3` = mds[,3],
#   Class = y_test)
#
# p <- plot_ly(plot_data,
#              x = ~`Dimension 1`,
#              y = ~`Dimension 2`,
#              z = ~`Dimension 3`,
#              color = ~Class,
#              colors = c("blue", "red"),
#              type = "scatter3d",
#              mode = "markers",
#              marker = list(size = 3, opacity = 0.25)) %>%
#   layout(title = "MDS 3D - Orpouche Class Model",
#          scene = list(xaxis = list(title = 'Dimension 1'),
#                       yaxis = list(title = 'Dimension 2'),
#                       zaxis = list(title = 'Dimension 3')))
# p


# tiff(paste0(result_path,"Proximity_MDS_3D_Oropouche_RF_class_",Sys.Date(),".tiff"),
#      width = 480 * 12,
#      height = 480 * 18,
#      res = 72 * 6, compression = "lzw")
#
# opar <- par()
# par(mfrow = c(3, 2), mar = c(3, 3, 4, 1), oma = c(0, 0, 2, 0))
#
# plot_3d_mds(oropouche.class.model,
#             x_data = x_train,
#             y_data = y_train,
#             title = "M1: General (Train)",
#             angle = 45)
#
# plot_3d_mds(oropouche.class.model,
#             x_data = x_test,
#             y_data = y_test,
#             title = "M1: General (Test)",
#             angle = 45)
#
# plot_3d_mds(oropouche.class.freq.model,
#             x_data = x_train,
#             y_data = y_train,
#             title = "M2: Frequency selected (Train)",
#             angle = 45)
#
# plot_3d_mds(oropouche.class.freq.model,
#             x_data = x_test,
#             y_data = y_test,
#             title = "M2: Frequency selected (Test)",
#             angle = 45)
#
# plot_3d_mds(oropouche.class.week.model,
#             x_data = x_train,
#             y_data = y_train,
#             title = "M3: Model with week (Train)",
#             angle = 45)
#
# plot_3d_mds(oropouche.class.week.model,
#             x_data = x_test,
#             y_data = y_test,
#             title = "M3: Model with week (Test)",
#             angle = 45)
#
# legend("top",
#        legend = c("No", "Oropouche"),
#        col = c("blue", "red"),
#        pch = 20,
#        pt.cex = 2,
#        cex = 1.5,
#        bty = "n",
#        horiz = TRUE,
#        xpd = TRUE,
#        inset = c(0, -0.15))
#
# mtext("Proximity MDS 3D - Oropouche RF class models", outer = TRUE, cex = 1.5, font = 2)
#
# dev.off()
#
# supressMessages(par(opar)) ; rm(opar)

## Effect size ----
# for regression only
# rf.effectSize(x = oropouche.class.model,
#               y = x_train$SEMANA_NUM,
#               pred.data = x_train,
#               x.var = SEMANA_NUM,
#               rug = TRUE
#               )


## Partial dependency ----
### Selection model ----
#### Train data ----

set.seed(1753109393)
oropouche.class.dependence.train <-
  plot_all_partial_effects(model = oropouche.class.model,
                           data = x_train,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.train


ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_selected_train_",Sys.Date(),".tiff"),
       plot = oropouche.class.dependence.train,
       width = 16, height = 12, dpi = 600)

#### Test data ----

set.seed(1753109393)
oropouche.class.dependence.test <-
  plot_all_partial_effects(model = oropouche.class.model,
                           data = x_test,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.test
ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_selected_test_",Sys.Date(),".tiff"),
       plot = oropouche.class.dependence.test,
       width = 16, height = 12, dpi = 600)

### Frequency selected model ----
#### Train data ----

set.seed(1753109393)
oropouche.class.freq.dependence.train <-
  plot_all_partial_effects(model = oropouche.class.freq.model,
                           data = x_train,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.train


ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_freq_train_",Sys.Date(),".tiff"),
       plot = oropouche.class.freq.dependence.train,
       width = 16, height = 12, dpi = 600)

#### Test data ----

set.seed(1753109393)
oropouche.class.freq.dependence.test <-
  plot_all_partial_effects(model = oropouche.class.freq.model,
                           data = x_test,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.test
ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_selected_test_",Sys.Date(),".tiff"),
       plot = oropouche.class.freq.dependence.test,
       width = 16, height = 12, dpi = 600)

### Week model ----
#### Train data ----

set.seed(1753109393)
oropouche.class.week.dependence.train <-
  plot_all_partial_effects(model = oropouche.class.week.model,
                           data = x_train,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.train


ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_week_train_",Sys.Date(),".tiff"),
       plot = oropouche.class.week.dependence.train,
       width = 16, height = 12, dpi = 600)

#### Test data ----

set.seed(1753109393)
oropouche.class.week.dependence.test <-
  plot_all_partial_effects(model = oropouche.class.week.model,
                           data = x_test,
                           title.size = 9,
                           legend.size = 0.4,
                           caption.width = 250)
# oropouche.class.dependence.test
ggsave(filename = paste0(result_path,"Partial_dependence_Oropouche_class_week_test_",Sys.Date(),".tiff"),
       plot = oropouche.class.week.dependence.test,
       width = 16, height = 12, dpi = 600)



## Fit statisctics permutation ----
models <- list(
  "Selected model" = oropouche.class.model,
  "Frequency model" = oropouche.class.freq.model,
  "Week model" = oropouche.class.week.model
)
# perm_models calls the rfUtilities::rf.significance in a loop for the models in the list and makes a table
set.seed(1753109393)
perm.oropouche.class <- bind_rows(
     perm_models(model_list = models,
                 data_x = x_train,
                 label = "Training",
                 n_perm = 100),
     perm_models(model_list = models,
                 data_x = x_test,
                 label  = "Testing",
                 n_perm = 100)
)

perm.oropouche.class <-
  perm.oropouche.class %>%
  flextable() %>%
  # Agrupa as c�lulas repetidas na coluna 'Data'
  merge_v(j = "Data") %>%
  valign(j = "Data", valign = "top") %>%
  # Est�tica e Formata��o
  colformat_double(digits = 3) %>%
  colformat_double(i = ~ Metrics == "Number of permutations:", digits = 0) %>%
  bold(part = "header") %>%
  # Linha separadora entre Training e Testing
  hline(i = ~ Metrics == "max random within class error:" & Data == "Training") %>%
  fix_border_issues() %>%
  autofit() %>%
  colformat_double(i = ~ Metrics == "Number of permutations:", digits = 0) %>%
  autofit() %>%
  set_caption("Class random forest Oropouche fever significance test for permutations for the diferent adjusted models.") %>%
  add_footer_lines("min = minimum; max = maximum; OOB = out of bag; Week = RF model with epidemiological week in the initail predictors combination; Selected = RF model without epidemiological week in the initail predictors combination; Frequency = RF model with predictors combination selected from importance frequency.") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 10, part = "body") %>%
  fontsize(size = 8, part = "footer") %>%
  padding(padding = 1.2, part = "all") %>%
  set_table_properties(width = .99, layout = "autofit")
perm.oropouche.class

rm(models)

save_as_docx(
  values = list(perm.oropouche.class) ,
  path = paste0(result_path,"Table_permutations_Oropouche_class_",Sys.Date(),".docx"),
)


## Importance kept predictors ----
# rf.reg$sel.importance
# var_label(bi$IDADE_ANOS_DT_NOTIFIC) <- var_label(a$IDADE_ANOS_DT_NOTIFIC)
# var_label(bi$DC_FEBRE) <- var_label(a$DC_FEBRE)
x <- rf.class.oro$sel.importance %>%
  arrange(imp)
rownames(x) <- unname(unlist(var_label(bi[,rownames(x)])))

tiff(paste0(result_path,"Importance_final_reg_rf_",Sys.Date(),".tiff"), width = 480*5, height = 480*5, res = 72 * 5, compression = "lzw")
# png(paste0(result_path,"Oropouche_class_Importance_selected_kept_",Sys.Date(),".png"), width = 480*5, height = 480*5, res = 72 * 5)
plot(rf.class.oro,
     imp = "sel",
     labels = rownames(x),
     main = "Selected variables importance",
     cex.main = 1.2);grid()
axis(1, seq(0,1,0.05), F, lwd.ticks =.7, tcl = -.2)
dev.off()

## Importance all variables variaveis ----
# x <- rf.class.oro$importance %>% arrange(imp)
# x$selected <- rownames(x) %in% rownames(rf.class.oro$sel.importance)
# rownames(x) <- sapply(rownames(x), function(i) labelled::var_label(bi[,i]))
#
# tiff(paste0(result_path,"Oropouche_Importance_allVar_final_reg_rf_",Sys.Date(),".tiff"), width = 480*5, height = 480*8, res = 72 * 5, compression = "lzw")
# parmar <- par()$mar
# par(mar = c(5.1, 10.1, 4.1, 2.1))
# plot(x = x$imp, y = seq_along(rownames(x)), type = "n",
#      xlab = "Importance", ylab = NA, axes = F,
#      main = "All explored variables Importance", cex.main = 1.2); grid(); box()
# points(x = x$imp[x$selected == TRUE], y = which(x$selected == TRUE), pch = 19, cex = 1.2, col = "darkgreen")
# points(x = x$imp[x$selected == FALSE], y = which(x$selected == FALSE), pch = 19, cex = 1.2, col = "darkred")
# axis(1); axis(1, labels = F, at = seq(0,1,.05), lwd = .5, tcl = -.2)
# axis(2, labels = rownames(x), at = seq_along(rownames(x)), las = 2, tick = F,  cex.axis = .95)
# legend("bottomright", c("Selected variables","Droped variables"), pch = 19, col =c("darkgreen","darkred"), bty = "n")
# par(mar = c(parmar))
# dev.off()
#
# rm(x)
tiff(paste0(result_path,"Oropouche_class_selected_Importance_allVar_",Sys.Date(),".tiff"), width = 480*5, height = 480*8, res = 72 * 5, compression = "lzw")
print(
  plot_rf_importance(rf.class.oro, bi, "Oropouche Fever: all explored variables Importance")
)
dev.off()

## Importancia local ----
x <- oropouche.class.model
rownames(x$importance) <- sapply(rownames(x$importance), function(i) labelled::var_label(bi[,i]))

tiff(paste0(result_path,"Oropouche_class_selected_IncMSE_importance_",Sys.Date(),".tiff"), width = 480*5, height = 480*4, res = 72 * 5, compression = "lzw")
rfPermute::plotImportance(x, sig.only = FALSE, alpha = .9, n = nrow(x$importance), ranks = TRUE, plot.type = "heatmap")
dev.off()

x <- oropouche.class.freq.model
rownames(x$importance) <- sapply(rownames(x$importance), function(i) labelled::var_label(bi[,i]))

tiff(paste0(result_path,"Oropouche_class_freq_IncMSE_importance_",Sys.Date(),".tiff"), width = 480*5, height = 480*4, res = 72 * 5, compression = "lzw")
rfPermute::plotImportance(x, sig.only = FALSE, alpha = .9, n = nrow(x$importance), ranks = TRUE, plot.type = "heatmap")
dev.off()

x <- oropouche.class.week.model
rownames(x$importance) <- sapply(rownames(x$importance), function(i) labelled::var_label(bi[,i]))

tiff(paste0(result_path,"Oropouche_class_week_IncMSE_importance_",Sys.Date(),".tiff"), width = 480*5, height = 480*4, res = 72 * 5, compression = "lzw")
rfPermute::plotImportance(x, sig.only = FALSE, alpha = .9, n = nrow(x$importance), ranks = TRUE, plot.type = "heatmap")
dev.off()

rm(x)

# plot_local_importance(oropouche.class.model, bi, "Local Importance Heatmap")

while(search()[2] != "tools:rstudio") detach(2)

save.image(paste0(data_path,"Oropouche_RF_",Sys.Date(),".RData"))
